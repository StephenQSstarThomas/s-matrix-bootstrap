# SDPB reproduction of arXiv:2309.12402 — code package

This package contains the complete code of our reproduction of He & Kruczenski, *Bootstrapping gauge theories*
(arXiv:2309.12402 v3), from the derivation of the discretised operators to the claim-by-claim evaluation. It contains no
solver output: every number in the comparison document was produced by these files from the paper's inputs. Snapshot of
branch `sdpb-2309-regularised` (https://github.com/StephenQSstarThomas/s-matrix-bootstrap), 14 September 2026.

## 1. Pipeline

1. **Finite model** (`src/smatrix_bootstrap/sdp/spec.py`): one `ModelSpec` holds every declared choice — M, L, the
   chiral tolerance and its norm packaging, the UV parts (Gram, FESR, form-factor caps), the FESR packaging and the
   form-factor factor reading, the regulariser norm and scale.
2. **Operators** (`grid.py`, `hilbert.py`, `legendreq.py`, `projector.py`, `assembly.py`, `precision.py`): the
   conformal map and midpoint grid (3.58)–(3.62), the cot kernel (3.67) derived from the odd extension of Im G, the
   angular projections of the Mandelstam representation (2.7) via Neumann's formula and Legendre Q functions, the
   current kernels (3.66), (3.68)–(3.75); `precision.py` rebuilds all rows in Arb (python-flint) at 40 digits.
3. **PMP writer** (`pmp.py`, `precision_pmp.py`, `formfactor.py`, `constraints.py`): assembles the SDPB
   polynomial-matrix program: unitarity disks as 3×3 blocks, the chiral ball, the |rho_ij| ≤ Mreg blocks (or l2/l4
   auxiliary blocks), the Gram blocks in the exact congruence rho_hat = rho/k², the FESR boxes or balls, the (3.75) caps,
   the optional section f00(3) = x, and the diagnostics: a near-optimal slab and a node functional as objective.
4. **Solve** (`sdpb.py`, `cli.py`, `__main__.py`, `scripts/sdpb/sdpb.sh`): runs pmp2sdp and sdpb (SDPB 3.1.0 in
   Docker, 192 bits), reads y.txt back onto the model variables, and records everything in `report.json`. The `support`
   command reuses a finished PMP with a new objective (direction, section, or face diagnostic).
5. **Verification** (`arbaudit.py`, `precision_pmp.verify`, `verify.py`, `observables.py`): every accepted solution
   is re-evaluated against all original constraints in Arb interval arithmetic; phases and |S| are read from
   S = 1 + i kappa h at the nodes.
6. **Independent checks** (`scripts/mma/audit_2309.wls`, `mma.py`, `crosscheck.py`, `audit.py`): a Mathematica
   script recomputes the formulas; the (2.7) projections are reconstructed without the production kernels.
7. **Claims** (`claims.py`, `figures.py`, `scripts/sdp/c1_eval.py` … `c8_eval.py`, `face_eval.py`): the
   pre-registered comparison rules for Figs. 3–11, and the degenerate-face rules F1–F6.
8. **Documents** (`scripts/sdp/final_figures.py`, `authors_comparison_en.py`, `authors_comparison_tex.py`): the
   side-by-side figures and the comparison document.

## 2. How to run

```
pip install -e .                       # numpy, scipy, python-flint, mpmath, matplotlib
python -m pytest -q tests/sdp          # 282 tests, no solver needed
# one +x tip of the chiral model (needs Docker image bootstrapcollaboration/sdpb:3.1.0)
PYTHONPATH=src python -m smatrix_bootstrap.run sdp solve --workdir RUNS/tip --M 50 --L 10 \
  --chiral --chi chi-b --eps-chi 0.002 --reg-norm linf --reg-bound 1e2 --reduce-basis \
  --operator-dps 40 --digits 30 --precision 192 --nproc 8 --duality-gap 1e-6 --points tip --skip-mma-audit
# reuse its PMP for a vertical section, or for a face diagnostic
PYTHONPATH=src python -m smatrix_bootstrap.run sdp support --source-report RUNS/tip/tip/report.json \
  --direction 0 1 --fix-f00 0.07332139057293464 --out RUNS/section_hi
PYTHONPATH=src python -m smatrix_bootstrap.run sdp support --source-report RUNS/section_hi/report.json \
  --face-margin 2e-6 --functional ImKH P1 38 max --out RUNS/face_hi
```
`examples/` holds the exact launcher scripts and queue files used for the runs behind the comparison document
(paths refer to our machine). The Mathematica audit needs Wolfram Engine (`scripts/mma/wolfram.sh`); `--skip-mma-audit`
or `--mma-reference` bypass it.

## 3. Contents

| Path | Contents |
|---|---|
| `src/smatrix_bootstrap/sdp/` | the active code (English docstrings in every module; see DERIVATIONS.md for the equation map) |
| `scripts/sdp/` | evaluation and diagnostic scripts (claims, face diagnostic, omitted waves, figures, documents) |
| `scripts/sdpb/sdpb.sh`, `scripts/mma/` | SDPB Docker launcher; Mathematica audit scripts |
| `tests/sdp/` | unit tests (block layout, verification, CLI contracts, kernel identities) |
| `references/figure*.csv` | digitised curves of the paper's figures with extraction metadata, used by the evaluators |
| `derivations/` | English derivation notes on the PV/midpoint kernel construction, Cauchy transforms and rank properties |
| `examples/` | launcher scripts and queue files of the actual runs |

Not included: `legacy/` (a retired Newton-type solver), solver outputs, caches. `python -m smatrix_bootstrap.sdp
prereg` prints the pre-registered rules; the log of the runs is in the repository under `docs/reproduction_2309/receipts`.
