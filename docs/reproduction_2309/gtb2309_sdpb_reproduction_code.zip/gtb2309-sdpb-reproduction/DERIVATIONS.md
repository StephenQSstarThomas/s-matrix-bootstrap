# From the paper's equations to the code

Each row names the equation of arXiv:2309.12402 v3, what we derived from it, and where it is implemented. All
quantities are in units m_pi = 1.

| Paper | Derivation | Implementation |
|---|---|---|
| (2.5)–(2.10) Mandelstam representation A = T0 + C[sigma1](s) + C[sigma2](t) + C[sigma2](u) + D[rho1](s,t) + D[rho1](s,u) + D[rho2](t,u) | partial-wave projection of the Cauchy kernels: the angular integral of 1/(z − mu) against P_l gives 2 Q_l(z) (Neumann); Q_l by Miller's backward recursion in mpmath; the crossed-channel double integral reduces to products of Q_l | `projector.py`, `legendreq.py`; independent reconstruction in `audit.py`, `crosscheck.py` |
| (2.11) S = 1 + i kappa f, kappa = pi sqrt((s−4)/s) | unitarity |S| ≤ 1 written as the rotated cone |kappa f|² ≤ 2 Im(kappa f) | `grid.kappa`, `pmp._blocks` (3×3 disk blocks), `arbaudit.py` |
| (3.58)–(3.62) map z(nu), nodes phi_i = (i − 1/2) pi/M, nu(phi) = 8/(1 + cos phi) | midpoint rule in phi; ds/dphi = 8 sin phi/(1 + cos phi)² | `grid.py` |
| (3.66)–(3.67) Re F_i = 1 + K_ij Im F_j with the cot kernel | K derived from the odd extension of Im G on the unit circle (not quoted from the paper); the same K serves the double-density dispersion | `hilbert.py`, `precision.py` |
| (3.63)–(3.64) chiral ratios at s = 1/2, 1, 3/2, 2 | eight residuals f00 − R01 f11, f20 − R21 f11; packaging chi-a (box), chi-b (one L2 ball), chi-c (two balls) | `assembly.chi_rows`, `pmp._blocks`, `arbaudit.py` |
| (h24)–(h25) |script-F|² = k² |F|², k0² = 3 sqrt((s−4)/s)/(16 pi (2pi)^4), k1² = (s−4)^{3/2}/(24 pi (2pi)^4 sqrt s) | kinematic factors and the exact congruence rho_hat = rho/k² of the Gram block (3.68) | `formfactor.kinematic_factor`, `formfactor.gram_scale`, `pmp._blocks` |
| (3.72)–(3.73) FESR: (pi/M) sum_i (ds/dphi)_i s_i^n rho_i vs the QCD value, tolerance eps_SR | nodes with s_i ≤ s0; targets = printed (2.56) × s0^{n+2}; packagings SR-a (raw box), SR-b (relative), SR-d (per-wave L2) | `constraints.py`, `precision.uv_data`, `pmp._blocks`, `arbaudit._uv_audit` |
| (3.75) |script-F_0(s_i)|² ≤ 2 m_q² eps_FF, |script-F_1(s_i)|² ≤ eps_FF/2 for s_i > s0 | factor k(s_i) at each node (main) or frozen at s0 (control) | `constraints.ff_asymptotic_bounds`, `precision.uv_data` |
| 2103.11484 §3 (cited by 2309) M-regularisation | |rho_ij| ≤ Mreg as 1×1 blocks; l2/l4 via auxiliary 2×2 blocks; scale fixed by omitted-wave unitarity and L-stability | `pmp._regulariser_blocks`, `scripts/sdp/omitted_waves.py` |
| §3.1 support functional d·(f00(3), f11(3)); sections f00(3) = x | objective row and equality blocks | `pmp.objective`, `pmp._blocks` |
| diagnostics (ours) | near-optimal slab d·f ≥ v* − margin with node functionals 1 − Re S, Im S, Im F, rho_hat, FESR moments as objective; freed FESR boxes for the moment-range test | `pmp.face_row`, `pmp.functional_row`, `spec.sr_free`, `scripts/sdp/face_eval.py` |

Numerical settings: SDPB 3.1.0, 192-bit arithmetic, duality gap 1e-6, primal/dual error 1e-10, operator rows at 40
digits, PMP coefficients printed at 30 digits, SVD-reduced coordinate basis (tolerance 1e-12) whose completeness was
checked against the full-space solve (+0.02 %). Acceptance of a leaf requires SDPB's primal-dual optimal termination and
Arb feasibility of every original constraint (`precision_pmp.verify`).

The notes in `derivations/` (72–76) give the construction of the PV/midpoint kernel, the Cauchy angular projections and
rank properties of the finite family in full; 69–71 record the analytic-rank and boundedness decisions behind the basis
reduction.
