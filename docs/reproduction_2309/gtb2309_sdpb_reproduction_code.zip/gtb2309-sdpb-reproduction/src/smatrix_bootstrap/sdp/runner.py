"""Job runner: one solve -> one ``report.json`` from which every number recomputes.

Each record carries the argv, the input hashes, the full model spec, the solver
status/iterations/residuals, the objective, the a posteriori verification of the
*unmodified* constraints, and the solution hash.
"""
from __future__ import annotations

import hashlib
import gzip
import json
import os
import platform
import subprocess
import sys
import time
from dataclasses import asdict, replace

import numpy as np

from . import constraints as C
from .observables import resonance_report, subthreshold_curves
from .problem import Model, ModelSpec, Operators
from .verify import full_report

CODE_FILES = ("grid.py", "legendreq.py", "hilbert.py", "projector.py", "assembly.py",
              "formfactor.py", "constraints.py", "problem.py", "verify.py", "arbaudit.py",
              "runner.py", "observables.py", "audit.py", "__main__.py",
              "__init__.py", "../run.py", "../__init__.py")


def code_hash() -> dict:
    here = os.path.dirname(__file__)
    out = {}
    for f in CODE_FILES:
        p = os.path.join(here, f)
        if os.path.exists(p):
            out[f] = hashlib.sha256(open(p, "rb").read()).hexdigest()
    return out


def save_producer(outdir):
    """Authenticate the exact implementation, including uncommitted audit code."""
    here = os.path.dirname(__file__)
    files = {f: open(os.path.join(here, f), encoding="utf-8").read() for f in CODE_FILES}
    payload = json.dumps({"format": "non-executable source evidence", "files": files},
                         sort_keys=True).encode()
    packed = gzip.compress(payload, mtime=0)
    sha = hashlib.sha256(packed).hexdigest()
    name = f"producer_{sha[:16]}.json.gz"
    with open(os.path.join(outdir, name), "wb") as stream:
        stream.write(packed)
    return {"path": name, "sha256": sha, "code_sha256": code_hash()}


def provenance() -> dict:
    try:
        rev = subprocess.check_output(["git", "rev-parse", "HEAD"],
                                      cwd=os.path.dirname(__file__),
                                      stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        rev = None
    import clarabel, cvxpy, scipy
    return {"argv": sys.argv, "git_rev": rev, "python": sys.version.split()[0],
            "numpy": np.__version__, "scipy": scipy.__version__,
            "cvxpy": cvxpy.__version__, "clarabel": clarabel.__version__,
            "host": platform.node(), "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "code_sha256": code_hash()}


def run_job(spec: ModelSpec, jobs, outdir: str, solver: str = "CLARABEL",
            objective: str = "plane", generate: bool = False,
            arb_audit: bool = False, **kw) -> dict:
    """``jobs``: list of ``(name, direction, extra_constraint_builder)``.

    ``extra`` is called as ``extra(model, ctx)`` where ``ctx`` accumulates the
    results already obtained in this process, so the representative points can
    chain: ``tip`` is solved first and ``ref``/``mid`` read ``ctx["tip"]`` for
    the section they are constrained to.
    """
    os.makedirs(outdir, exist_ok=True)
    if generate:
        return _run_generated(spec, jobs, outdir, solver, objective, arb_audit, **kw)
    model = Model(spec)
    records, ctx = [], {}
    built_with_extra = None      # None = never built
    for name, direction, extra in jobs:
        # The objective direction is a cvxpy Parameter, so a pure direction
        # sweep canonicalises once and only re-solves.  A job that adds an extra
        # constraint has to rebuild, and so does the first plain job after one.
        if extra is not None or built_with_extra is not False:
            model.finalize(extra(model, ctx) if extra else (), objective=objective)
            built_with_extra = extra is not None
        t0 = time.time()
        res = model.solve(direction, solver=solver, **kw)
        rec = {"job": name, "spec": asdict(spec), "result": res,
               "wall_seconds": time.time() - t0}
        sol = model.solution()
        if sol.get("c") is not None:
            rec["verification"] = full_report(model, sol)
            rec["observables"] = resonance_report(model.ops, sol["c"])
            rec["subthreshold"] = subthreshold_curves(
                model.ops, sol["c"], np.linspace(0.05, 3.95, 40))
            np.savez_compressed(os.path.join(outdir, f"sol_{name}.npz"), **{
                k: v for k, v in sol.items() if v is not None})
        ctx[name] = res
        records.append(rec)
        _write(outdir, records)
    return {"records": records}


def _write(outdir, records):
    doc = {"provenance": provenance(), "records": records,
           "fesr_target_audit": C.fesr_target_audit(), "producer": save_producer(outdir)}
    with open(os.path.join(outdir, "report.json"), "w") as fh:
        json.dump(doc, fh, indent=1, default=float)


def _arb(spec, sol) -> dict:
    """Independent ball-arithmetic re-verification of one solution."""
    from .arbaudit import ArbAudit
    t0 = time.time()
    try:
        aa = ArbAudit(spec.M, spec.L, bits=384)
        out = aa.audit(sol["c"], sol.get("ImF"), sol.get("rho_hat"),
                       chi_caliber=spec.chi_caliber if spec.chiral else None,
                       eps_chi=spec.eps_chi, sr_caliber=spec.sr_caliber,
                       eps_ff=spec.eps_ff, m_q=spec.m_q,
                       ff_frozen_at_s0=spec.ff_frozen_at_s0)
    except Exception as exc:
        out = {"error": f"{exc!s:.200}"}
    out["seconds"] = time.time() - t0
    return out


def _run_generated(spec, jobs, outdir, solver, objective, arb_audit=False, **kw):
    """One report.json per job, each solved by constraint generation."""
    records, ctx = [], {}
    for name, direction, extra in jobs:
        t0 = time.time()
        try:
            res, model, rounds = solve_generated(spec, direction, extra=extra, ctx=ctx,
                                                 objective=objective, solver=solver, **kw)
        except Exception as exc:            # a chained job whose predecessor failed
            records.append({"job": name, "spec": asdict(spec),
                            "result": {"status": "Skipped", "message": str(exc)},
                            "wall_seconds": time.time() - t0})
            records[-1]["spec"].pop("disk_mask", None)
            _write(outdir, records)
            continue
        rec = {"job": name, "spec": asdict(spec), "result": res,
               "generation": rounds, "wall_seconds": time.time() - t0}
        rec["spec"].pop("disk_mask", None)
        sol = model.solution()
        if sol.get("c") is not None:
            rec["verification"] = full_report(model, sol)
            rec["observables"] = resonance_report(model.ops, sol["c"])
            rec["subthreshold"] = subthreshold_curves(
                model.ops, sol["c"], np.linspace(0.05, 3.95, 40))
            if arb_audit:
                rec["arb_audit"] = _arb(spec, sol)
            np.savez_compressed(os.path.join(outdir, f"sol_{name}.npz"),
                                **{k: v for k, v in sol.items() if v is not None})
        ctx[name] = res
        records.append(rec)
        _write(outdir, records)
    return {"records": records}


def solve_generated(spec: ModelSpec, direction, extra=None, ctx=None,
                    objective: str = "plane", solver: str = "CLARABEL",
                    start_tol: float = 1e-6, max_rounds: int = 24,
                    viol_tol: float = 1e-8, add_per_round: int = 60, **kw) -> tuple:
    """Constraint generation over the unitarity disks.

    Only about 100 of the 1500 disks of (3.61) carry an operator norm within a
    percent of the largest -- the rest are centrifugally suppressed by many
    orders of magnitude.  Imposing a subset is a *relaxation*, so its optimum is
    an upper bound on the true one; when the returned point then satisfies all
    1500 disks (checked on the unmodified operators), it is feasible for the
    full problem and therefore optimal for it.  That makes the answer certified
    rather than merely reported, and it shrinks the dense KKT system that
    dominates the cost at M = 50.

    Returns ``(result, model, rounds)``.
    """
    from .problem import Model
    ops = Operators(spec.M, spec.L)
    ops.set_cone_scaling(spec.cone_scaling, spec.sparsify)
    nu = ops.nu_measured
    mask = nu > start_tol * nu.max()
    rounds = []
    best = None                      # the solved round with the smallest violation
    for _ in range(max_rounds):
        sp = replace(spec, disk_mask=mask.copy())
        model = Model(sp)
        model.finalize(extra(model, ctx or {}) if extra else (), objective=objective)
        res = model.solve(direction, solver=solver, **kw)
        if res.get("f00_3") is None:
            rounds.append({"n_disks": int(mask.sum()), "status": res["status"]})
            if best is None:
                return res, model, rounds
            # A round can fail after several have succeeded; keep the last good
            # iterate and report it uncertified rather than losing the run.
            b_res, b_model, b_bad, b_viol = best
            b_res["certified"] = False
            b_res["generation_rounds"] = len(rounds)
            b_res["n_disks_violated_at_return"] = int(b_bad)
            b_res["max_violation_at_return"] = float(b_viol)
            b_res["stopped_because"] = f"solver failed at {int(mask.sum())} disks"
            return b_res, b_model, rounds
        c = model.solution()["c"]
        hre, him = ops.h_re @ c, ops.h_im @ c
        mag2 = hre ** 2 + him ** 2
        viol = (mag2 - 2.0 * him) / np.maximum(mag2, 1e-300)
        bad = viol > viol_tol
        rounds.append({"n_disks": int(mask.sum()), "status": res["status"],
                       "objective": res["objective"], "n_violated": int(bad.sum()),
                       "max_violation": float(viol.max())})
        if best is None or viol.max() < best[3]:
            best = (res, model, bad.sum(), viol.max())
        if not bad.any():
            res["certified"] = True
            res["generation_rounds"] = len(rounds)
            res["n_disks_imposed"] = int(mask.sum())
            return res, model, rounds
        # add only the worst violators, so the cone count grows gently; adding
        # every violated disk at once has been observed to destabilise the solve
        new = np.flatnonzero(bad & ~mask)
        if new.size > add_per_round:
            new = new[np.argsort(viol[new])[::-1][:add_per_round]]
        if new.size == 0:
            break
        mask[new] = True
    # out of rounds: return the round with the smallest violation, not the last
    b_res, b_model, b_bad, b_viol = best
    b_res["certified"] = False
    b_res["generation_rounds"] = len(rounds)
    b_res["n_disks_imposed"] = int(mask.sum())
    b_res["n_disks_violated_at_return"] = int(b_bad)
    b_res["max_violation_at_return"] = float(b_viol)
    b_res["stopped_because"] = f"max_rounds = {max_rounds} reached"
    return b_res, b_model, rounds


def sweep_directions(n: int, half: bool = False):
    """``n`` unit directions; ``half`` keeps only the upper half plane."""
    ang = np.linspace(0.0, np.pi if half else 2 * np.pi, n, endpoint=half)
    return [(float(np.cos(a)), float(np.sin(a))) for a in ang]
