#!/usr/bin/env bash
# Pure-unitarity (no chiral) solve.  Usage: launch_pure.sh NAME M L NORM BOUND [extra...]
set -euo pipefail
cd /home/shiqiu/s-matrix-bootstrap
export PYTHONPATH=src OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4
NAME=$1; M=$2; L=$3; NORM=$4; BOUND=$5; shift 5
exec /home/shiqiu/miniconda3/bin/python -m smatrix_bootstrap.run sdp solve --workdir /playpen1/shiqiu/sdpb_regularised_20260913/$NAME --M $M --L $L \
  --scattering-prescription mixed-pv --reduce-basis --reg-norm $NORM --reg-bound $BOUND \
  --operator-dps 40 --digits 30 --precision 192 --nproc 8 --duality-gap 1e-6 \
  --primal-error 1e-10 --dual-error 1e-10 --timeout 7200 "$@"
