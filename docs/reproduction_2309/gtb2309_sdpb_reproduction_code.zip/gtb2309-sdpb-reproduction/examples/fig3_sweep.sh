#!/usr/bin/env bash
# Append the 24-direction Fig.3 support sweep (15-degree steps, reusing the accepted pure tip PMP) to the queue
# and (re)start the queue runner.  Usage: fig3_sweep.sh ACCEPTED_TIP_LEAF_REPORT
set -euo pipefail
SRC=$1; ROOT=/playpen1/shiqiu/sdpb_regularised_20260913
for k in $(seq 0 23); do
  a=$(python3 -c "import math;print(math.cos(math.radians(15*$k)))"); b=$(python3 -c "import math;print(math.sin(math.radians(15*$k)))")
  name=$(printf "fig3_dir%02d" $k)
  echo "cd /home/shiqiu/s-matrix-bootstrap && PYTHONPATH=src OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4 /home/shiqiu/miniconda3/bin/python -m smatrix_bootstrap.run sdp support --source-report $SRC --direction $a $b --out $ROOT/$name" >> $ROOT/queue.txt
done
[ -f $ROOT/queue_runner.pid ] && kill -0 $(cat $ROOT/queue_runner.pid) 2>/dev/null || (setsid nohup $ROOT/queue_runner.sh > $ROOT/queue_runner.out 2>&1 < /dev/null &)
echo "queued 24 directions from $SRC"
