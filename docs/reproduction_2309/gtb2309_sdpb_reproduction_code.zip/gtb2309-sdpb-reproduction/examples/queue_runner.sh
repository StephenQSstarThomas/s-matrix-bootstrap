#!/usr/bin/env bash
# Launch queued solves whenever fewer than MAXJOBS SDP drivers are alive.  One line of queue.txt per job.
ROOT=/playpen1/shiqiu/sdpb_regularised_20260913; MAXJOBS=${MAXJOBS:-5}; echo $$ > $ROOT/queue_runner.pid
while true; do
  live=$(ps -eo args | grep -E "smatrix_bootstrap.run sdp (solve|support)" | grep -v grep | wc -l)
  if [ "$live" -lt "$MAXJOBS" ] && [ -s $ROOT/queue.txt ]; then
    cmd=$(head -n1 $ROOT/queue.txt); tail -n +2 $ROOT/queue.txt > $ROOT/queue.tmp && mv $ROOT/queue.tmp $ROOT/queue.txt
    name=$(echo "$cmd" | grep -oE "(--out|--workdir) [^ ]+" | awk '{print $2}' | xargs -n1 basename); name=${name:-job}
    name=$(echo "$cmd" | grep -oE "launch_(solve|pure|full).sh [^ ]+" | awk '{print $2}'); [ -z "$name" ] && name=$(echo "$cmd" | grep -oE "\-\-out [^ ]+" | awk '{print $2}' | xargs basename)
    echo "$(date -u +%FT%TZ) launching $name (live=$live)" >> $ROOT/queue.log
    setsid nohup bash -c "$cmd" > $ROOT/$name.driver.log 2>&1 < /dev/null &
    sleep 90
  else
    [ -s $ROOT/queue.txt ] || { echo "$(date -u +%FT%TZ) queue empty, exiting" >> $ROOT/queue.log; exit 0; }
    sleep 120
  fi
done
