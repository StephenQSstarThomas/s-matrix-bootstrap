#!/usr/bin/env bash
# Chiral solve WITHOUT basis reduction (full 3876 coordinates).  Usage: launch_full.sh NAME NORM BOUND [extra...]
set -euo pipefail
cd /home/shiqiu/s-matrix-bootstrap
export PYTHONPATH=src OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4
NAME=$1; NORM=$2; BOUND=$3; shift 3
exec /home/shiqiu/miniconda3/bin/python -m smatrix_bootstrap.run sdp solve --workdir /playpen1/shiqiu/sdpb_regularised_20260913/$NAME --M 50 --L 10 --chiral --chi chi-b --eps-chi 0.002 \
  --scattering-prescription mixed-pv --reg-norm $NORM --reg-bound $BOUND \
  --operator-dps 40 --digits 30 --precision 192 --nproc 8 --duality-gap 1e-6 \
  --primal-error 1e-10 --dual-error 1e-10 --timeout 14400 "$@"
