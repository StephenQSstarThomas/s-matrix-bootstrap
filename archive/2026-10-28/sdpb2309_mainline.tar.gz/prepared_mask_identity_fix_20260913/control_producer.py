"""Synthetic M2/L2 prepared-source mask checks; no optimizer and no real run reads."""
from dataclasses import asdict
import hashlib
import importlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
from unittest.mock import patch
import numpy as np
from smatrix_bootstrap.sdp.pmp import Pmp
from smatrix_bootstrap.sdp.spec import ModelSpec

HERE=Path(__file__).resolve().parent
SRC=Path(importlib.import_module('smatrix_bootstrap.sdp.precision_pmp').__file__).parent
CASES={
 'IR_all':(False,('gram','fesr','ff'),None),
 'IR_subset':(False,('gram','fesr','ff'),[True,False,True,False,False,True,False,True,True,False,True,False]),
 'UV_Gram_all':(True,('gram','fesr','ff'),None),
 'UV_Gram_subset':(True,('gram','fesr','ff'),[True,False,True,False,False,True,False,True,True,False,True,False]),
 'UV_no_Gram_all':(True,('fesr','ff'),None),
 'UV_no_Gram_subset':(True,('fesr','ff'),[True,False,True,False,False,True,False,True,True,False,True,False]),
}


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')


def fixture(name,uv,parts,mask):
    dest=HERE/'fixtures'/name
    if dest.exists():return dest
    dest.mkdir(parents=True)
    # Independent physical order: I0 l0/l2, I1 l1/l3, I2 l0/l2; two nodes each.
    expected=np.ones(12,dtype=bool) if mask is None else np.array(mask,dtype=bool)
    if uv and 'gram' in parts:expected[[0,1,4,5]]=False
    spec=asdict(ModelSpec(M=2,L=2,chiral=True,uv=uv,uv_parts=parts,chi_caliber='chi-c',
                         sr_caliber='SR-a',ff_frozen_at_s0=False,reduce_basis=True,
                         operator_dps=40,scattering_prescription='sine-cardinal',disk_mask=mask))
    basis=np.zeros((12,2));basis[0,0]=1.;basis[1,1]=1.
    np.save(dest/'basis.npy',basis);np.save(dest/'disk_mask.npy',expected)
    n=3+(8 if uv else 0)
    write(dest/'pmp.json',{'objective':['0']*n,'normalization':['1']+['0']*(n-1),
                         'PositiveMatrixWithPrefactorArray':[]})
    record={'solver':'SDPB','status':'numerically_accepted','accepted':True,'spec':spec,
            'source_sha256':{'src/smatrix_bootstrap/sdp/'+p.name:sha(p) for p in SRC.glob('*.py')},
            'pmp':{'sha256':sha(dest/'pmp.json'),'n_a':2,'n_vars':n,'digits':30,
                   'operator_precision':{'scattering_prescription':'sine-cardinal'}},
            'basis':{'sha256':sha(dest/'basis.npy')}}
    write(dest/'report.json',record)
    write(dest/'fixture_scope.json',{'synthetic_only':True,'physically_solved':False,
                                   'expected_mask':expected.tolist(),'basis_plane':'T0 and first sigma1 column'})
    return dest


FIXTURES={name:fixture(name,*args) for name,args in CASES.items()}
RESULT=[];OBJECTIVES={}


def check(name,fn):
    try:fn();RESULT.append({'name':name,'passed':True})
    except Exception as exc:RESULT.append({'name':name,'passed':False,'error':type(exc).__name__+': '+str(exc)})


def restored(path):return Pmp.from_saved(path/'report.json',(0.,1.),.07332139057293464)


def valid(name):
    root=FIXTURES[name];w=restored(root);expected=json.loads((root/'fixture_scope.json').read_text())['expected_mask']
    assert w.keep.tolist()==expected
    row={'f00':w._num_vec(w._row(a=w.f00)),'f11':w._num_vec(w._row(a=w.f11)),
         'objective':w._num_vec(w.objective())}
    assert row['f00'][1]=='2.50000000000000000000000000000' or float(row['f00'][1])==2.5
    assert abs(float(row['f11'][2]))>.001
    OBJECTIVES[name]=row


for name in CASES:check(name+' valid effective mask and nonzero P1 source row',lambda name=name:valid(name))
BASE=HERE/'PRE_FIX_OBJECTIVES.json'
if not BASE.exists():write(BASE,OBJECTIVES)
else:
    check('all valid objective/source-plane texts unchanged from pre-fix restore',
          lambda:None if OBJECTIVES==json.loads(BASE.read_text()) else (_ for _ in ()).throw(AssertionError('Source rows changed')))


def corrupted(name,mutate,early=False):
    with tempfile.TemporaryDirectory(dir=HERE,prefix='isolated_') as tmp:
        dest=Path(tmp);shutil.copytree(FIXTURES[name],dest,dirs_exist_ok=True)
        mask=np.load(dest/'disk_mask.npy');mutate(dest,mask)
        def attempt():
            try:restored(dest)
            except ValueError:return
            raise AssertionError('Tampered prepared mask was accepted')
        if early:
            with patch('smatrix_bootstrap.sdp.precision_pmp.arb_mat',side_effect=AssertionError('Expensive basis conversion occurred before rejection')):attempt()
        else:attempt()


def flip(index):
    def mutate(dest,mask):mask[index]=not mask[index];np.save(dest/'disk_mask.npy',mask)
    return mutate


for name in CASES:
    check(name+' non-Gram bit removal rejected',lambda name=name:corrupted(name,flip(2)))
    check(name+' explicit/addition bit change rejected',lambda name=name:corrupted(name,flip(3)))
for name in ('UV_Gram_all','UV_Gram_subset'):
    check(name+' Gram-primary disk bit forced false',lambda name=name:corrupted(name,flip(0)))
check('bad mask rejects before precise basis materialization',lambda:corrupted('UV_Gram_all',flip(2),True))
check('stored wrong shape still rejected',lambda:corrupted('IR_all',lambda d,m:np.save(d/'disk_mask.npy',m[:-1])))
check('stored wrong dtype still rejected',lambda:corrupted('IR_all',lambda d,m:np.save(d/'disk_mask.npy',m.astype(int))))
def wrong_spec_shape(dest,mask):
    r=json.loads((dest/'report.json').read_text());r['spec']['disk_mask']=[True]*11;write(dest/'report.json',r)
check('explicit ModelSpec mask wrong shape rejected',lambda:corrupted('IR_all',wrong_spec_shape))


def no_solver():
    with (patch('smatrix_bootstrap.sdp.sdpb.execute',side_effect=AssertionError('solver invoked')),
          patch('smatrix_bootstrap.sdp.sdpb.run_once',side_effect=AssertionError('new solve invoked'))):
        valid('UV_Gram_subset')
# Kept as a separate source-independent control; no scientific process is contacted.
check('restore does not invoke a solver',no_solver)

observed={}
for name,module in tuple(sys.modules.items()):
    if name.startswith('smatrix_bootstrap') and getattr(module,'__file__',None):
        path=Path(module.__file__)
        if path.suffix=='.py':observed[str(path.relative_to(SRC.parents[2]))]=sha(path)
record={'synthetic_only':True,'scientific_solves':0,'real_run_inputs_read':False,
        'passed':all(x['passed'] for x in RESULT),'controls':RESULT,
        'objective_reconstruction':OBJECTIVES,'observed_local_python_dependencies':observed,
        'producer_sha256':sha(__file__),'precision_pmp_sha256':sha(SRC/'precision_pmp.py')}
out=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'VALIDATION.json';write(out,record)
print(json.dumps({'passed':record['passed'],'controls':len(RESULT),'failed':[r for r in RESULT if not r['passed']]},indent=2))
raise SystemExit(0 if record['passed'] else 1)
