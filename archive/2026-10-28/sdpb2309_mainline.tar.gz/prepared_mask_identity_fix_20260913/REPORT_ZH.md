# Prepared mask 身份漏检：已复现并修复

`precision_pmp.restore` 之前只核 `disk_mask.npy` 的形状和 dtype；形状正确的非 Gram 位被翻转后仍可进入 prepared 对象，导致随后原式复验采用与保存 ModelSpec 不同的约束 mask。此次仅修复复用入口，没有改物理核、`Pmp.__init__` 的规则、求解器设置或任何运行目录。

原 `precision_pmp.py` 的完整字节及 SHA 已保存在 `precision_pmp.py.before.txt`、`BEFORE.json`。**修改前 RED 实际得到 16 项失败**：IR、UV/Gram、无 Gram UV、显式 subset 的位改变都未拒绝；Gram 主波位改回 true 同样被接受；错误显式 ModelSpec mask 的长度也漏检。坏 mask 还会先触发昂贵的 Arb basis 转换。`RED.json`、原始控制 producer 与隔离的小矩阵源均保留，未拿 live UV 文件制造反例。

## 最小修改

在原存储 shape/dtype 检查后，按 `Pmp.__init__` 的原规则重建 expected：

1. ModelSpec.disk_mask 为 None 时取全部 true；否则 `np.asarray(..., dtype=bool).copy()`，保持构造器的 bool 转换语义。
2. 仅在 `spec.uv` 且 `gram in spec.uv_parts` 时，将 `(I,ell)=(0,0),(1,1)` 两组原生行设为 false。
3. 核 expected 形状，并以 `np.array_equal` 比较保存 mask 的全部内容；不匹配立即拒绝。
4. 将原有 `precise_basis` 转换移到 mask 与 basis 形状检查之后。转换表达式、精度和后续投影运算没有改变。

`PATCH.diff` 给出全部差异。前后 AST 对比只有顶层 `restore` 函数改变；其它函数和模块级语句相同。最终文件 **257 行、14,591 bytes**，SHA256：

`725ace3308e473fc26e0d94316a90554dfdce042d40d06532ac9fe4cda8d316f`

## 已完成验证及其范围

独立控制采用 M2/L2、12×2 保存基底，包含常数和一个 sigma1 方向，使源 P1 投影非零；mask 预期索引按显式的 I0 l0/l2、I1 l1/l3、I2 l0/l2 顺序独立列出。它们是 helper 接口的合成源，不宣称已经过 SDPB 物理求解。

- **26 项独立控制通过**：IR/UV 与 all/subset 正常接受，非 Gram 位删除/添加、Gram 主行打开、存储 shape/dtype、ModelSpec mask shape 篡改均拒绝。
- 六种正常配置的 f00、f11 与目标系数十进制文本，和修改前保存的 `PRE_FIX_OBJECTIVES.json` **逐项相同**。
- 运行时 trap 确认坏 mask 在 `arb_mat` 转换前拒绝，restore 不调用 `execute` 或 `run_once`。
- **17 项现有定向测试通过**（70 deselected，0.30 秒），覆盖未知 producer 拒绝、已存 basis 转移与通用 saved-support 接口。没有修改三个活动测试文件；没有重复执行整套科学或精度计算。

相应终态见 `VALIDATION.json`、`TARGETED_TESTS.txt` 与 `FINAL_VALIDATION.json`。新 guard 会有意拒绝旧的合成 UV fixture 若其将 Gram 主波 mask 错写为全 true；历史控制材料保持原字节。真实 `Pmp.__init__` 输出的有效 mask 不需要改变。

## Live 与便携包范围

两项 live UV 的输入、checkpoint、日志及相位均未读取或修改。现有 fresh solve 的物理构造规则、PMP 系数和已装配输入不变；本次只改变未来 prepared 重放对错误 mask 的拒绝行为。当前六文件严格源核 hash 列表不包含 restore 所在文件，因此这个入口修复不改变源核身份。

但 **“未列入源核 hash guard”不等于“运行时不依赖此文件”**。`Pmp.from_saved` 必须能导入 `precision_pmp.py`；函数内部依赖 assembly、spec、projector、sine/PrecisionRows，模块还使用 numpy、python-flint 与标准库。`RESTORE_DEPENDENCIES.json` 记录直接导入、六个源核 guard 文件、必要的运行数据文件，以及全新 Python 进程恢复 sine 小源时实际加载的 14 个本地模块及哈希。便携包应包含入口文件、包初始化文件与这些依赖；该观测集合不冒充其它所有 CLI 路径的完整依赖闭包。
