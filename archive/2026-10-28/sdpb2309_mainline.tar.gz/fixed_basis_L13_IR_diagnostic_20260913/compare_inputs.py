"""Compare completed PMP emission only; never read a live solver's observables."""
from pathlib import Path
import hashlib,json,time
from smatrix_bootstrap.sdp.dual import _stream_pmp
B=Path(__file__).resolve().parent.parent;D=Path(__file__).resolve().parent
OLD=B/'IR_M50_L12_fpi_calibrated_eps00021_upper/ref';NEW=B/'IR_M50_L13_fixed_e541_eps00021_upper/ref'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def compact(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
def key(i,L):
 if i<3*L*50:
  I,rem=divmod(i,L*50);k,node=divmod(rem,50);return ('disk',I,2*k+(I==1),node)
 return ('chi_or_section',i-3*L*50)
started=time.monotonic();before=json.loads((OLD/'report.json').read_text());after=json.loads((NEW/'report.json').read_text())
assert after['status'] in ('pmp2sdp','solving','numerically_accepted','not_accepted','solver_failed','readback_failed')
assert after['pmp']['n_blocks']==1954 and before['pmp']['n_blocks']==1804
assert sha(OLD/'basis.npy')==sha(NEW/'basis.npy')==before['basis']['sha256']
assert before['pmp']['n_a']==after['pmp']['n_a']==1989
assert {k:v for k,v in before['spec'].items() if k!='L'}=={k:v for k,v in after['spec'].items() if k!='L'}
old=_stream_pmp(OLD/'pmp.json');new=_stream_pmp(NEW/'pmp.json');head_old=next(old);head_new=next(new);assert head_old==head_new
old_hashes={key(i,12):hashlib.sha256(compact(block).encode()).hexdigest() for i,block in enumerate(old)}
shared=[];added=[];changed=[]
for i,block in enumerate(new):
 k=key(i,13);digest=hashlib.sha256(compact(block).encode()).hexdigest()
 if k in old_hashes:
  shared.append(k)
  if digest!=old_hashes[k]:changed.append(k)
 else:added.append(k)
assert len(shared)==1804 and len(added)==150 and set(shared)==set(old_hashes)
assert {k[1:3] for k in added}=={(0,24),(1,25),(2,24)}
result={'passed':not changed,'baseline_PMP_sha256':sha(OLD/'pmp.json'),'new_PMP_sha256':sha(NEW/'pmp.json'),'basis_sha256':sha(NEW/'basis.npy'),'shared_blocks':len(shared),'changed_shared_keys':changed,'new_disk_count':len(added),'added_keys':added,'same_objective_normalization':True,'n_a':1989,'source_observables_read':False,'seconds':time.monotonic()-started,'scope':'ActualnormalizeddecimalPMP coefficients checked afterphysicalrowreindexing. Samefinitebasis,onlyL12→13 nativeconstraints when passed. No transferredfeasibility, supportoptimality orcontinuumclaim.'}
(D/'ACTUAL_INPUT_COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='added_keys'}))
