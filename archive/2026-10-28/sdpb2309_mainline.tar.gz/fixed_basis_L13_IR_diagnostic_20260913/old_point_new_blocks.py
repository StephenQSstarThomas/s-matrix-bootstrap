"""Exact-input PSD countercheck of the old accepted point on three new blocks."""
from pathlib import Path
from fractions import Fraction
import json,hashlib,time
from flint import arb,arb_mat,ctx
from smatrix_bootstrap.sdp.dual import _stream_pmp
D=Path(__file__).resolve().parent;B=D.parent;old=B/'IR_M50_L12_fpi_calibrated_eps00021_upper/ref';new=B/'IR_M50_L13_fixed_e541_eps00021_upper/ref';start=time.monotonic();ctx.prec=512
r=json.loads((old/'report.json').read_text());data=(old/'out/y.txt').read_bytes();assert hashlib.sha256(data).hexdigest()==r['y_sha256'];lines=data.decode().splitlines();assert lines[0].split()==['1989','1'];y=[arb(1)]+[arb(x) for x in lines[1:] if x.strip()];assert len(y)==1990
stream=_stream_pmp(new/'pmp.json');header=next(stream);assert [Fraction(x) for x in header['normalization']]==[1]+[0]*1989
wanted={642:(0,24,42),1288:(1,25,38),1942:(2,24,42)};out=[]
for i,block in enumerate(stream):
 if i not in wanted:continue
 pol=block['polynomials'];assert len(pol)==3 and all(len(row)==3 for row in pol)
 vals=[]
 for row in pol:
  vals.append([])
  for entry in row:
   assert len(entry)==len(y) and all(len(x)==1 for x in entry)
   vals[-1].append(sum((arb(x[0])*z for x,z in zip(entry,y)),arb(0)))
 matrix=arb_mat(vals);det=matrix.det();negative=bool(det.upper()<0)
 out.append({'new_block_index':i,'I_ell_node':list(wanted[i]),'matrix':[[x.str(40) for x in row] for row in vals],'determinant':det.str(50),'determinant_upper_negative':negative,'verdict':'certified_PMP_PSD_violation' if negative else 'no_negative_determinant_detected'})
assert len(out)==3 and all(x['determinant_upper_negative'] for x in out if x['I_ell_node'][0] in (0,2))
result={'passed':True,'scope':'Exactdecimal targetPMP evaluated atfullsaveddecimal sourcey,512bit Arb; proves thisspecificoldpoint violates twoaddedPSDblocks. Doesnotboundnewoptimum orcertifyoriginalphysicalfamily globally.','source_y_sha256':r['y_sha256'],'target_PMP_sha256':hashlib.sha256((new/'pmp.json').read_bytes()).hexdigest(),'new_solver_output_read':False,'rows':out,'seconds':time.monotonic()-start}
(D/'OLD_POINT_ON_NEW_BLOCKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':True,'rows':[{k:v for k,v in x.items() if k!='matrix'} for x in out],'seconds':result['seconds']}))
