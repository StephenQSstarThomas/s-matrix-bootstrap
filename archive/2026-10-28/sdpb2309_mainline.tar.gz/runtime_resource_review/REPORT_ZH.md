# 当前 SDPB 320-bit 运行：只读资源核验

观察时间：2026-09-13T03:38:56.708161+00:00。未启动优化或预处理，未修改源码、未向现有科学进程发送信号。

当前输入和求解都为320bit；日志明确为8 MPI进程、1节点。PMP为820,801,133bytes、1926块。已有pmp2sdp命令没有mpirun或-n，是单MPI rank；外部耗时570.678秒，程序内部只报告105.198秒。官方3.1.0支持并行预处理，且给出mpirun -n4示例，因此一次受控8rank测量合理，但不能先承诺8倍加速。[Usage](https://github.com/davidsd/sdpb/blob/3.1.0/docs/Usage.md)、[Docker](https://github.com/davidsd/sdpb/blob/3.1.0/docs/Docker.md)。

活动容器的8个rank各有42线程，共336线程；每socket的4个rank共享同一40逻辑CPU亲和集合。已加载OpenBLAS，线程变量均未设置。2.012秒观测中，每rank只有主线程增加CPU时间，其余线程没有CPU tick。因此存在过大的线程池和BLAS并发超配风险，但没有证据说336线程持续满载。官方要求每次BLAS调用单线程；root已在新launcher内及docker环境中固定OPENBLAS/OMP/MKL=1。现有容器环境和PID保持不变。[官方线程说明](https://github.com/davidsd/sdpb/blob/3.1.0/docs/Usage.md)。

只读变量打印的首次外层等待在60秒超时，不能据此宣称底层命令未执行或已通过；第二次保留CID和stdout并等待，未启动第三次。终态：第二次打印正常 exit 0，stdout 实测三个变量均为 1；SHA256 为 `507abfe33db74bb227a295b88e38d60e42bc5c4082e27a4be5a86e3390ad8221`。CID 于03:43:33.454Z才写入，stdout 于03:43:36.134Z写入。第一次外层超时留下的 created、未启动容器已按精确目录和命令确认后删除，证据在 first_probe_orphan.json。两次检查的时间范围和未记录的精确时间戳分别保存在 report.json；初始快照保存在 initial_report.json。

旧预处理CID在创建空文件约96.5秒后才写入ID，证明其启动生命周期有明显延迟。旧容器已--rm，无法恢复Created/StartedAt，历史events亦未返回。程序计时器位于初始化之后、退出清理之前；标准输出还可能缓冲，不能仅凭日志mtime将465.48秒差额全部分到启动或退出。现有科学solver不同：DockerCLI03:14:23.260Z，容器Created03:14:23.404Z、StartedAt03:14:38.506Z，首条SDPB日志03:14:40Z，启动约17秒。[3.1.0计时代码](https://github.com/davidsd/sdpb/blob/3.1.0/src/pmp2sdp/main.cxx)。

root拥有的8rank测量在03:35:22Z仍为CID空、日志空，已过约7分钟；该阶段尚无容器创建完成的证据，不能说MPI或矩阵计算慢。终态为 rc=124、外部 966.845 秒。CID 于03:43:33.786Z迟到写入，日志只有超时清理打印的容器 ID，没有 Processed 行，因此没有完成的转换性能结果。该精确测试目录无残留容器。新旧配置还同时改变了 BLAS 线程限制，不能据此外推 MPI 加速比。

本机确认80逻辑CPU、40物理核、双socket，宿主OpenMPI4.1.6可用；PATH未找到原生sdpb/pmp2sdp或Slurm/PBS/LSF命令，标准module入口和作业分配变量未发现，默认hostfile无活动条目。这些只支持当前单机容器路线，不能外推已有100节点。

最小改进是保留活动计算，下一次使用已固定线程的新launcher；待一次8rank预处理真正完成后再决定是否改变默认。不需要重新生成科学输入或扩大求解器参数扫描。

最终复核时间：2026-09-13T03:49:53.314058+00:00。科学容器 CID、主 PID、StartedAt 与初始观察相同且仍在运行；未向其发信号。两项只读/预处理检查的精确目录绑定均无残留容器。
