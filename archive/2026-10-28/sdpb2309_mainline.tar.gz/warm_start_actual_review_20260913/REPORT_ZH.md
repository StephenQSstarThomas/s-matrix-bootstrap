# 实际 warm start 的独立验收与复现范围

审查对象是 `UV_M50_L12_fpi_calibrated_eps00021_near_warm/report.json`；初始化源为已验收的 `UV_M50_L12_fpi_calibrated_eps00021_ref/ref/report.json`。本审查只读取终态输入、日志、完整 y 和验收记录，不读取相移，不启动计算，不修改 checkpoint。逐项结果与哈希见同目录 `report.json`。

## 结论

此次 near 运行确实请求并使用了独立复制的 ref checkpoint；同一物理 PMP 只改变了最后两条固定截面的常数。最终结果通过原有完整数值验收，没有把初始化源的可行性或最优性转移给目标解。主迭代数为 14，总时间 749.3667 秒，其中外部 solver 生命周期 520.3640 秒。

这验证了本机 SDPB 3.1.0、320 bits、8 ranks、单 host 的实际 warm-start 路径。它没有建立一般多节点重启保证，也不是同一目标问题的冷/热启动配对速度实验。

## 输入身份与真实加载

两份完整 PMP 均为 820801143 字节，含 2190 个齐次变量、1989 个幅度坐标、1926 个有序 block。逐字节流式比较仅发现 28 个不同字节，全部位于最后两个标量 block 的齐次常数：

- 源截面：`±0.0733213905729346400000000000000`。
- 目标截面：`±0.0740546044786639800000000000000`。

末端 block 的结构化检查确认其余项完全相同；前面的物理约束、目标、归一化及系数也字节相同。物理 spec 完全相同，包括 sine-cardinal、M50/L12、χ-c、εχ=0.00021、SR-a、逐节点 FF、全部 UV 约束、无 B、原算符精度与归一化。共享 basis SHA256 为：

`e541340318a1eb8c7deeb8c7c9725fae8c270998240a2371a5ff7808a03c8269`

源 PMP SHA256 为 `26451538b55e23d6e65853fb600bea1fa34de30d1f94b06d2f1274506d4ef06e`，目标为 `ec8ae1b4579f894fa38641b5e4e5e63e068dd2f54e1a5f29d6f81217ab756827`。

日志明确记录 SDPB 3.1.0、`MPI processes: 8, nodes: 1`、实际 320-bit 精度，以及 `initialCheckpointDir = "warm_start_input"` 和 `Loading binary checkpoint from : "warm_start_input"`，随后出现真实主迭代。输出 checkpoint 写入目标自己的 `sdp.ck`。

源 generation 11、backup 10 的 16 份 rank 文件，加 checkpoint.json 与 block_timings，共 18 份文件、579737787 字节。独立核对证明它们与目标 warm_start_input 的逐文件 SHA256 全部相符，且 inode 独立。目标转换 SDP 的 block_timings 也保持相同。源 report 的 SHA256 与启动 manifest 相符；本次审查没有发现源文件改变。

## 完整 y 与验收范围

原始 y 含 2189 个值，即 1989 个幅度坐标、100 个 ImF 和 100 个 rho_hat，完整读回与保存 NPZ 的哈希均匹配。最终停止原因是 `found primal-dual optimal solution`。重算目标与 solver 候选下界一致；数值上下候选之差为 `8.671822895184311e-11`，截面残差为 `3.506939183495206e-11`。原验收的 unitarity、chiral、rho 非负、Gram、FESR、FF 和 section 检查全部通过。

源公式 Arb 复核记录：1800 个 native unitarity slack 中，1697 项明确通过、0 项失败、103 项包络无法定号；χ 明确通过，700 个 Gram minors、4 个 FESR 和 14 个 FF 检查明确通过。因此这里的 accepted 是完整数值可行性加 SDPB 数值收敛；不是所有 Arb 圆盘严格为正，更不是严格对偶界或连续能量全局证书。`certified` 不应因此提升。

## 迭代和时间

只按主迭代表格正则 `^\d+\s+\d+\s+` 计数，得到 14 行；首行为第 1 步、表内 38 秒，末行为第 14 步、表内 510 秒。没有把 block timing 阶段计成额外主迭代。

| 项目 | 秒 |
| --- | ---: |
| 整个 run_once | 749.366709 |
| pmp2sdp 外部生命周期 | 121.613719 |
| solver 外部生命周期 | 520.364027 |
| checkpoint 核对与复制 | 5.946754 |
| 其余准备、复核、输出 | 101.442209 |

ref 和 near 的截面不同，不能据此量化同一目标 warm start 比 cold start 快多少。保留日志中的启动、退出和总时间差，不能将整个 749 秒全部解释为优化时间。

## 可复现性缺口及最小归档

[SDPB 3.1.0 Usage](https://github.com/davidsd/sdpb/blob/3.1.0/docs/Usage.md#L101-L113) 允许在 block 结构、精度、核心数与分布兼容时复用 checkpoint。要重放本次记录的初始化，必须保留 checkpoint 二进制；哈希和最终 y 无法重构它们。

数学初始化至少需要当前 generation 的全部 rank 文件、checkpoint.json、相同 block_timings、目标的相同 PMP/转换 SDP，以及兼容的 SDPB/MPI 运行环境。当前 helper 还检查并复制 backup generation，因此应完整保留 18 份文件。为使用现有统一 CLI，还需源 report、sdpb.log、PMP、basis、disk_mask，以及转换 SDP 的 control.json、pmp_info.json、normalization.json、objectives.json 和所有 block_info_*.json；源 block_data_*.bin 不在 helper 的读取依赖中。

可选 `inputs_05_warm_initialization.tar.gz` 已补齐已验收 ref 的初始化和已终态 lower 的续跑初始化；lower 自身不在 accepted 输入归档中，其 PMP、basis、mask、report、log 和终态 process 记录也必须随 05 保留。near 与续跑 lower 的输出 checkpoint 无须重复归档。

不安装可选 checkpoint 归档，仍可对字节相同的有限 PMP 冷启动求解，从而复现定义的科学优化问题；必须复用固定 basis，不能任意重新生成另一套 SVD 坐标。冷启动不保证回到同一个近简并幅度，也不保证相移、迭代数或时间相同。复核既有数值 witness 则需要最终完整 y、basis、物理 spec、源插值声明和匹配的 verifier。

当前 warm manifest 记录 Docker 版本 tag，未记录不可变镜像 digest；若声称运行环境精确重放，还应保留镜像 digest、平台和 rank 分布证据。该限制不改变相同 PMP 所定义的数学问题。

归档完成后已进行单向 gzip/tar 流式核验：3902 个 regular-file 成员全部 SHA256 与长度匹配，无 hardlink/symlink；归档大小 1296437190 字节，SHA256 为 `a1139651b109226b866937a25a615185042cc22143a13f0ab2fa2240ef983e95`。清单和逐成员验证分别保存在包目录 `INPUTS_05_MANIFEST.json` 与 `INPUTS_05_VALIDATION.json`。
