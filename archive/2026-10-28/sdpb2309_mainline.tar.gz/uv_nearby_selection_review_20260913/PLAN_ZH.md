# UV 三代表邻点规则：最小修复方案（草案，尚未冻结或执行）

**建议保留旧 tip/ref/mid 登记，沿用通用 `support`，只补一份事前计划和可复验的 UV 三点收据。** 不需要新增求解路径、源算子或通用选点框架。论文 §4.3 第 32–33 页先说明选上边界，再取 tip 与另外两个靠近黑点的点；没有规定两横坐标取平均或给出数值距离。[原文](https://arxiv.org/pdf/2309.12402v3#page=32)、[TeX L1148–1149](/home/shiqiu/s-matrix-bootstrap/references/2309.12402v3-source/prd_submission_2.tex:1148)

**现有断点。** [cli.py L84–90、104–107](/home/shiqiu/s-matrix-bootstrap/src/smatrix_bootstrap/sdp/cli.py:84)、[sdpb.py L289–295](/home/shiqiu/s-matrix-bootstrap/src/smatrix_bootstrap/sdp/sdpb.py:289)及 [delivery.py L24–32](/home/shiqiu/s-matrix-bootstrap/src/smatrix_bootstrap/sdp/delivery.py:24)一致使用 x_mid=(x_ref+x_tip)/2；前两处生成，后一处验收。按已提供的 x_tip≈0.606 作说明，x_mid≈0.339661，离 x_ref≈0.0733214 的横向距离约为 x_ref 的 363%，不能称黑点附近第二点。此处未读取该 tip 的相位。

**事前固定的新规则 `uv-near-ref-v1`：** tip 仍为无截面最大化 f00(3)；ref 为 x=x_ref 最大化 f11(3)；新点命名 **near**，在 x_near=(101/100)x_ref 最大化 f11(3)。采用当前 x_ref 文本 `0.07332139057293464`，精确十进制目标为 `0.0740546044786639864`，现 CLI 实际接收的 binary64 文本为 `0.07405460447866398`；两者随计划同时保存。1% 是独立声明的数值选择，不是作者坐标或从发表曲线恢复的参数。要求 x_ref<x_near<同合同已验收 tip 的可行候选 x，留出保存误差包络；不满足时中止，不夹到区间、不改成另一侧、不自动缩小偏移。

**默认只固定横坐标邻点并报告完整几何距离，不新增二维资格门槛。** 完成后先仅用 (x,y) 计算两点到 p_W=(x_ref,−x_ref/15) 的未加权距离及距离/x_ref，再读取相位。此规则只能保证横坐标邻近，不能自动证明两个完整点靠近黑点；若距离很大，须保留结果并明确近点 workflow 仍未闭合，不按相位或论文坐标重新挑点。若后续另采用二维半径，应先独立冻结，超出或误差包络相交时只标不合格/ambiguous、不自动换点；这是可选诊断，不是论文要求或本方案先决条件。

**最小接口。** [通用支持已具备所需能力](/home/shiqiu/s-matrix-bootstrap/src/smatrix_bootstrap/sdp/sdpb.py:270)：将同一已验收 UV tip 作为 `--source-report`，分别调用 `sdp support --direction 0 1 --fix-f00 X --out FRESH`，X 取 ref/near 的冻结文本。其 [保存 PMP 复用](/home/shiqiu/s-matrix-bootstrap/src/smatrix_bootstrap/sdp/precision_pmp.py:72)保留所有物理块及 normalization，仅替换目标与经验证的末尾两条截面块。无需改 cli.py 的旧 `--points`，也不把新点写成旧 midpoint。

新增一个专用 `uv-select` 收据验证入口及 `contrast --uv-selection-report` 即足够：计划须在 ref/near 新求解前归档哈希，绑定完整 spec（包括 χ 范数/ε）、解析族、实际 basis、tip 来源与预定两目标；求解后收据绑定三叶相对路径、报告/PMP/basis/完整 y 哈希，重新检查完成态、全部 UV/source 验收、去除**已核实**截面块后的物理块与 normalization 同一性、目标/截面、范围及完整几何距离。不得借用不同 χ 或 L 的旧 tip；相位、η、阈下线性及论文 CSV 均不进入选择器。计划还须记录既有输出的知情范围，不追认盲预登记；事后文件的 `frozen_before_solving=true` 本身不能证明事前冻结。

**交付兼容与控制。** 新分支绕开旧 `load_chain` 的 midpoint 检查，复用 [合同/basis/目标检查](/home/shiqiu/s-matrix-bootstrap/src/smatrix_bootstrap/sdp/delivery.py:186)。内部若为沿用 C6/C7 用 `mid` 槽承载 near，必须显式保存 `mid→near` 映射并在图例显示 near；禁止静默改名。新 `paper_state_comparison_complete/pass` 与旧登记完成状态分开，旧 `main_contrast_pass` 不因新规则冒充旧链通过；C4_source/C6/C7_source 数值预算不变。单个已选 IR 对 tip/near 通常目标或截面不匹配，全链因果标志仍为 false，单独报告 ref 的匹配情况。

验证只需小合成控制：新 near 接受而旧分支拒绝；错 spec/basis/物理块/normalization/目标/截面/哈希、重复或非终态叶均拒绝；窄 tip 范围拒绝且不自动改点，默认大二维距离只披露、不改选点；删去或污染全部观测数组不改变选择结果；搬移后相对路径再验证；新增 receipt 不完成旧 midpoint 登记。原代码与预登记不变，当前 χ=.00021 两端相位未读取，没有启动求解。本目录 `REVIEW.json` 保存源文件哈希、精确行定位及示例算术；本方案不声称已经找到作者精确代表。
