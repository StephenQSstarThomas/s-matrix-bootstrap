# 小范围checkpoint warm start接口

已实现support_from_saved(..., warm_start=False, timeout=None)。CLI由root接线。timeout只覆盖新运行的cfg，不修改source；warm只取同一accepted source的sdp.ck。

核验SDPB3.1.0、precision/current actual precision、rank数量、单host源日志、procGranularity=1、变量数和有序block/sampling结构、PMP/basis身份、section有无一致及当前/backup全部rank文件。复制到新workdir/warm_start_input，使用独立inode和复制前后SHA256；同一block_timings复制到目标sdp。SDPB仅添加-i warm_start_input -c sdp.ck；输入/输出checkpoint分离。

15项小控制通过；现有SDP套件217项通过。TDD失败阶段、文件SHA和行数见validation.json；控制代码以非活动测试材料test_control.py.txt保留。没有启动真实SDPB/pmp2sdp，没有修改原checkpoint或活动测试文件。

这是初值复用，不转移可行性或最优性。只声明当前单host Docker路线；checkpoint二进制内容最终仍由SDPB解码验证。root可将首次warm timeout设1200秒；失败后由root另建目录对同PMP冷启动，不自动改变物理参数。
