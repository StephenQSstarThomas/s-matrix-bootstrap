"""Display completed saved observations only; no solve or amplitude selection."""
from pathlib import Path
import json,csv,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from smatrix_bootstrap.sdp.figures import load_csv,phase_comparison
ROOT=Path(__file__).resolve().parent;RUN=ROOT.parent
sources={'tip':RUN/'UV_M50_L10_source_tip_20260913/tip/report.json','ref':RUN/'UV_M50_source_ref_persistent/ref/report.json'}
records={k:json.loads(p.read_text()) for k,p in sources.items()}
assert all(a['accepted'] and a['sdpb']['returncode']==0 for a in records.values())
identity=json.loads((RUN/'NOMINAL_L10_OLD_REF_NEW_TIP_INPUT_COMPARISON.json').read_text())
assert all(identity[k] for k in ('same_physical_blocks','same_normalization','same_basis'))
colors={'tip':'#b2182b','ref':'#b35886'};groups={'tip':'red','ref':'light_pink'}
reference={'S0':'figure10_s0_phases.csv','S2':'figure10_s2_phases.csv','P1':'figure9_p1_phases.csv'}
rows=[];metrics=[];fig,axes=plt.subplots(2,3,figsize=(12,6),sharex=True)
for j,wave in enumerate(('S0','S2','P1')):
 ref=load_csv(reference[wave])
 for name,record in records.items():
  obs=record['observables'][wave];E=np.array(obs['E_GeV']);d=np.array(obs['delta_deg']);eta=np.array(obs['eta']);m=E<=1.2
  axes[0,j].plot(E[m],d[m],color=colors[name],label='SDPB '+name)
  axes[1,j].plot(E[m],eta[m],color=colors[name])
  mref=ref['group']==groups[name]
  axes[0,j].plot(ref['energy_gev'][mref],ref['phase_deg'][mref],':',color=colors[name],label='paper '+groups[name])
  metrics.append({'point':name,'wave':wave,**phase_comparison(obs,reference[wave],groups[name])})
  for e,phase,mod in zip(E,d,eta):rows.append([name,wave,repr(float(e)),repr(float(phase)),repr(float(mod))])
 axes[0,j].set(title=wave,ylabel='phase shift (degrees)')
 axes[1,j].set(xlabel='energy (GeV)',ylabel='|S|',xlim=(.28,1.2));axes[1,j].axhline(1,color='.6',lw=.7)
 axes[1,j].ticklabel_format(axis='y',style='plain',useOffset=False)
 for ax in axes[:,j]:ax.grid(alpha=.15)
axes[0,0].legend(frameon=False,fontsize=8)
fig.suptitle('Nominal M50/L10 UV: completed tip and ref; mid not computed',fontsize=11)
fig.tight_layout();fig.savefig(ROOT/'comparison.pdf');fig.savefig(ROOT/'comparison.png',dpi=180);plt.close(fig)
with (ROOT/'saved_observations.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['point','wave','energy_GeV','phase_deg','eta']);w.writerows(rows)
report={'kind':'saved_nominal_UV_comparison','complete_three_point_claim':False,'available_points':['tip','ref'],'missing_points':['mid'],'same_physical_PMP_blocks':True,'same_basis':True,'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources.values()},'phase_metrics':metrics,'source_graph_energy_axis':'139.57MeV as digitized; native calculation140MeV; no fitted axis shift','scope':'Literal native-node phase lifts and eta from completed accepted records; no new selection, no solver, no C6/C7 completion. Old ref lacks solve-time full-y hash; this metadata gap is not retroactively repaired.'}
(ROOT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('saved figures, CSV and six phase comparisons')
