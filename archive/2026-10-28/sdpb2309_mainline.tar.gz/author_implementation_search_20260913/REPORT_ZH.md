# 2309 作者实现与缺失参数：有界公开检索结果

本轮从 2026-09-13 05:02:38 UTC 开始，约15分钟完成公开来源调查。没有启动优化、修改仓库源码或联系作者。先读取既有 deepresearch 报告与 SOURCE_INVENTORY，再补查作者仓库完整可见历史、原始 arXiv v1/v2、同期报告和可认证后续线索。

**结论：没有恢复到2309专属求解代码、原始矩阵或隐藏参数表。** 能确定的是作者自己对代码发布范围的声明，以及哪些参数已在2309明文给出。未知项不能以2403/2505/2511的值直接填上。

## 发布范围与排除证据

作者仓库 README 明确写2309 “No public code was provided at the time.”，而将2403列作首次公开版本。当前远端 main 是 `801684d9ece3de2918a20145178f569459081098`，与本地认证副本一致；仅有 `arxiv-2403.10772` 和 `arxiv-2505.19332` 两个 tag，没有2309 tag。[作者声明 L85–94](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/README.md#L85)

该声明首次进入 README 的 commit 为 `d0fe5aadd1a2d44c1342e1dc4360073175d401a6`（2025-09-30）。仓库初始 commit `8b05ac91bbc58cb0480cf2315979ac4f1746ff73`（2025-06-30）仅有README。2403代码首次明确上传于 `e6b0f343561c170850ec63e22261617438efd61e`（2025-07-01）。API实际返回 hyfysics 仅一个公开仓库、零公开 gist；本地副本不是浅克隆，可见历史路径中没有2309专属文件。记录见 `remote_refs.txt`、`author_repo_history.tsv`、`author_repo_historical_paths.txt` 和API原文。

本轮重新下载并列举了[2309 v1源包](https://arxiv.org/src/2309.12402v1)、[v2源包](https://arxiv.org/src/2309.12402v2)，与已认证[v3源包](https://arxiv.org/src/2309.12402v3)比较。三个版本均只有TeX、参考文献和图，没有 .m/.nb/.py 求解程序或 .mat 原始矩阵。源包SHA和全部成员名保存在 `early_versions.json`、`report.json`。

v1 的 εFF数量级说明为 O(10⁻⁴)；v2/v3改为 O(10⁻⁵)，且v2/v3明确给出实际出图设置 εSR=0.002、εFF=6×10⁻⁵。数量级文字不是一次已确认的 εFF=10⁻⁴运行。v2/v3的P1、S0、S2相移PDF字节完全相同；v1字节不同，但不能由此推断具体参数如何改变。纯区域、手征区域、UV区域PDF在三个版本字节相同。只比较了哈希，没有用曲线反推输入。

APS的PRD与配套PRL公开页面未发现Supplemental链接；Purdue作者主页主要是课程与旧报告，ENS目录没有新代码入口。这不是对所有未索引附件或私人资料不存在的证明。[PRD](https://journals.aps.org/prd/abstract/10.1103/PhysRevD.110.096001)、[PRL](https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.133.191601)、[Purdue](https://web.ics.purdue.edu/~markru/)、[ENS](https://www.phys.ens.fr/en/annuaire/214/yifei-he)。

## 能恢复什么，仍不知道什么

证据A表示2309原文；B表示同期作者说明；C表示明确后续代码。A不等于已经找到作者运行文件。

| 项目 | 可恢复内容 | 仍未知 |
|---|---|---|
| 散射离散与尾部 | A：ν0=0的映射；M50半格节点；单/双谱Mandelstam表示；每同位旋10波；附录指定M/L配置 | 节点间密度插值、端点完成、高模式截断和尾部实现；没有已恢复的B或隐藏截断值 |
| χ | A：s=.5,1,1.5,2；两条残差不等式；主ε=.002；六个ε为.006,.004,.002,.001,.0006,.0002 | “some norm”的具体范数、组内权重及代码缩放 |
| FESR | A：S0的n=0,1及P1的n=−1,0；s0=(1.2GeV)²；raw目标=打印归一化目标×s0^(n+2)；出图εSR=.002 | 实际求解器中是否另有残差缩放/打包，没有专属代码佐证；不能自动等同10%相对盒 |
| FF | A：F(0)=1、ReF=1+K ImF；Gram因子逐s_i；高节点平方界的电荷因子及εFF=6e−5 | 作者mq平均方式的精确实施与所有舍入约定；未找到额外尾部等式 |
| 代表点 | A：IR选择靠近物理fπ点的最近边界；UV取tip及附近两个上边界点 | 距离度量、搜索网格、精确坐标、退化解的打破规则；当前xref上端点不等于已恢复该选择 |
| 稳定化 | A：仅给分辨率比较；未找到2309求解器精度/版本、逐行缩放或隐式正则化值 | 不能将后续100位、Lambda或B直接称作2309运行设置 |

准确原文定位：`references/2309.12402v3-source/prd_submission_2.tex` L907–931（离散）、L944–951（χ）、L970–984（K和逐节点因子）、L1020–1052（FESR/FF）、L1083（εχ网格）、L1111（IR最近边界）、L1141–1148（实际UV容差及选点）、L1204–1208（分辨率附录）。

## 2023年同期作者讲演：补充程序性约定

[2023-10-24 CERN讲演](https://indico.cern.ch/event/1331655/?view=lecture)自署基于2309与当时未发表工作；[CERN视频元数据](https://videos.cern.ch/record/3001564)确认讲者、日期和论文号。[85页幻灯PDF](https://indico.cern.ch/event/1331655/attachments/2739524/4765108/bootstrapQCD_CERN.pdf)已下载，SHA256为 `011402d7c06a60b4a2ae5a08524eaf69470b6f431eb13a1630b3c7f83b4a51ee`。以下页码从1计；截图保存在本目录。

- 第60页：χ部分标作 “linear constraints with some tolerance”，并写 “use fπ = 92MeV to select appropriate tolerance”。这是按物理邻域保留情况选择容差的证据；“linear”可能只是对线性残差的口头简称，不足以证明使用L∞。
- 第71页：FESR写 “numerically: tune down before bootstrap becomes infeasible”。它支持按可行性收紧的程序，但没有给出隐藏归一化、范数或步长。
- 第74页：直接显示逐s_i的ℱ平方界和εFF数量级估算，没有冻结k(s0)代替所有节点的代码处方。

没有完整转写视频及Q&A，也没有联系作者；所以不能声称口头报告已排除所有未记录细节。

## 后续代码：可定位，但不能移植身份

2403快照中，MATLAB L38设εχ=.002；L102将S0/P1与S2/P1残差合成一个L2向量；L39/L91为三个通道、各三个矩采用不同容差；L60有四范数密度界；L44–45取ni=44/46/48并固定F0；L106–109的F0/F1含D0/F1分波，已不是2309的(f00,f11)。L114起还有Watson型额外步骤。[固定commit代码](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/theories/qcd/papers/arxiv-2403.10772/GTB_numerics.m#L38)

其Mathematica快照可精确定位ν0=−20、100位计算和Lambda锥缩放；本轮机器记录给出实际行号。代码中的L=20意指ell<20、每同位旋10个波。它还使用2GeV和额外谱参数化。这些只能作C级实现线索，不能把ν0、B、ni或100位直接宣布为2309参数。[固定commit notebook](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/theories/qcd/papers/arxiv-2403.10772/GTB_numerics.nb)

2511明确将collocation M与谱级数nmax分开，数值例采用M49、nmax37、ellmax11，并加入2GeV、D0和正则化。其“不同parameterization”不是函数族不等价的证明：当nmax=M且端点/截断规则相同时，有限sine系数和M个密度样本可经可逆DST换坐标。当前sine-cardinal仍不能称为作者2309插值；可保留的后续线索是**插值阶数与约束节点数可以独立检查**，不是导入其物理输入。[2511 §3–6](https://arxiv.org/html/2511.11513v1#S3)

该第三方脚本分别比较上下截面到物理点的距离（本地 `references/cordoba-discrete-gtb-2511.11513/f_00f_11ExperimentsSVZcircle.m` L572、L835附近）。它为当前先核对两侧几何提供旁证；不是2309精确选点坐标。没有找到它持有原2309 producer的来源桥接。

## 最少的候选试算范围

1. **先完成同一输入、同一基底的xref两侧支持并按几何距离选点，再看新相位。** 这是最直接的2309最近边界原则检查，不需要猜容差。
2. 如几何仍无法解释差异，χ只保留 `{两组L2, 八个逐点L∞}`、ε=.002 的一个受控对照。两者都是需声明的读法；L∞更弱，不能排除已满足两组L2的过大支持见证，不能期望它凭空修复该允许区域问题。2403的合并L2保留历史身份。
3. 如确需测试χ容差，只用论文已给出的相邻 `{.001,.002,.004}`，每次一个变化，以是否保留fπ邻域及原式可行为判据；不是按相移误差选最优值。
4. SR与FF先固定实际出图值 `{.002,6e−5}`。本轮没有恢复到新的隐藏尺度。若完整UV被可靠排除可行，才按作者所述可行性程序对一个容差作有记录的括界；新的括界点必须标“本次选定实验”，不能标“恢复作者参数”。v1的O(1e−4)只是一条数量级线索，不证明实际epsilon=1e−4。
5. 不用本次检索作为复制B、ν0=−20、2GeV、0.163108坐标或额外Watson目标的理由。后续分离nmax/M若做，只是带后续来源标签的插值分辨率诊断，须保留原节点约束和新的模型身份。

本轮已排查公开GitHub仓库/gist/refs和路径历史、arXiv三版源包、APS两篇页面、作者主页/机构目录、同期CERN幻灯及后续代码归属。不能排除私人代码、删除且不可达的对象、未索引附件或视频问答中的细节。全部新下载、原始成员表、commit和哈希见本目录JSON/TXT；未进行任何优化或参数扫描。
