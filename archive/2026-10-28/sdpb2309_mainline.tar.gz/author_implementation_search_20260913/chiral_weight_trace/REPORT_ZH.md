# 2403作者快照的χ权重追踪

**结论：该快照MATLAB L102中的fchi是论文规范化的裸 f_l^I。χ残差没有乘κ、除Λ、额外π/2、逐s权重或1/√N平均因子。** 可见的非平凡选择是一条合并八分量的未加权L2约束，以及另行限制D0/D2/F1的约束。此结论只属于认证2403快照，不能追认为2309的作者设置。

核对commit：`801684d9ece3de2918a20145178f569459081098`。完整文件SHA、逐段原始字节摘录和48个独立积分控制见 `report.json`、`source_excerpts.txt`；没有运行Mathematica、MATLAB或任何优化。

## 实际数据流

| 环节 | 源位置 | 实际操作 |
|---|---|---|
| MATLAB读入 | `.m` L25–26 | χ点=.5,1,1.5,2；读入fsigmachi/frhochi |
| 生成χ数组 | `.m` L97–100 | 矩阵乘sig/rho，切取S0、S2、P1的四点行 |
| 范数 | `.m` L101–102 | 将两组线性残差首尾拼接成8×1向量，再取默认Euclidean norm |
| Mathematica导出 | `.nb` L5107–5117 | fsigmachi/frhochi原样Export，没有新缩放 |
| χ点选择 | `.nb` L4118–4144 | 从每波五点中取前四点；第5点s=3留给目标 |
| 奇偶/同位旋选择 | `.nb` L3937–4018 | 仅取行并按I=0、2、1组织，无权重 |
| 原始单/双谱行 | `.nb` L3410–3878 | 由1/4角投影后的核组成；常数列可直接核实 |

[MATLAB L97–103](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/theories/qcd/papers/arxiv-2403.10772/GTB_numerics.m#L97)、[Notebook χ选择](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/theories/qcd/papers/arxiv-2403.10772/GTB_numerics.nb#L4118)、[原样导出](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/theories/qcd/papers/arxiv-2403.10772/GTB_numerics.nb#L5105)。

## 不是根据变量名判断：核的实际因子

令a_j=Δφ x′(φ_j)/π，b_j=a_j/(x_j−ν0)，该快照ν0=−20。`Kunphys`（NB L1668–1692）为

K_j(s)=a_j[1/(x_j−s)−1/(x_j−ν0)]。

`Ap1unphys`（L1922–1953）为 J_lj(s)=a_j Q_l(1+2x_j/(s−4))/(s−4)；`Am1unphys`加上(−1)^l。由Neumann积分，J_lj正是(1/4)∫P_l(μ)a_j/(x_j−t(μ))dμ。

随后L3410–3463给出：

f_s=(1/2)δ_l0 K(s)，f_t=J_l−(1/2)δ_l0 b，f_u=(−1)^l J_l−(1/2)δ_l0 b。

这些就是对同一减去ν0常数的单谱核做1/4角积分。Δφ x′是**谱积分列**的Jacobian，不是χ四个观测点的误差权重。L3497–3546的双谱核同样由K、J、W0/W00的乘积组成；L3693–3736的2与对角1/2是对称rho2的打包操作，不是给S0/S2/P1加权。

物理区则不同：NB L2408明确乘vΩ=π√((s−4)/s)，常数物理行L3069也乘vΩ；随后L4332–4346只将a,b,A,B缩放成A1/B1/A2/B2以及Bhat。该链没有回写fsigma、frho、fsigmachi或frhochi。因此κ和Λ确实存在于作者代码，但位于物理幺正锥链路，而非χ范数链路。[物理κ行](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/theories/qcd/papers/arxiv-2403.10772/GTB_numerics.nb#L2393)、[Λ缩放](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/theories/qcd/papers/arxiv-2403.10772/GTB_numerics.nb#L4330)。

## 两个独立归一化控制

取A(s,t,u)=T0，所有谱密度为0。NB L3849–3865直接构造f0=(1/2)δ_l0，再由NN=3的同位旋组合L3868–3878得到，在每个χ点：

f00=5T0/2，f20=T0，f11=0。

这与(1/4)∫T^I完全一致。实际重建其奇偶行索引及χ索引后，四个S0条目全为5/2，四个S2条目全为1，四个P1条目全为0。L102的范数因而为√29 |T0|。隐藏的κ(s)、Λ(s)、π/2或逐s权重会改变这个常数列；本快照没有这种变化。

再取代数Weinberg振幅A=g(s−1)，g=1/(8π²fπ²)。独立角积分得到f00=g(2s−1)/2、f20=g(2−s)/2、f11=g(s−4)/6，两类χ残差恒为0。这是规范化代数控制，不声称该多项式在当前有限密度基中构成可行优化见证。

为覆盖常数列之外的实现，本轮按作者M50、ν0=−20网格，取第17/31个谱节点，分别检查sigma1、sigma2、rho1以及rho2非对角列，在四个χ点与S0/S2/P1共48项。对照一边是从上述Notebook公式转录的闭式核，另一边直接对同一单/双谱A构造同位旋振幅并做mpmath角积分。70位运算的最大绝对差为 **3.3958797×10⁻⁷²**（门槛10⁻⁶⁰）。这不是完整作者Notebook执行，也不是区间证书；它是独立的数值/代数因子核验。

## 对当前参数恢复的含义

2403提供不了一个可移植到2309的“自然κ/Λ隐藏χ权重”。若继续使用加权χ范数，必须另有2309来源或明确声明为新实验，不能根据这里的物理锥缩放推断。当前该线索能排除的是**认证2403快照中**的上述隐藏乘子；2309未公开的范数仍未被唯一恢复。

快照使用减去ν0常数的谱坐标、不同网格及其它后续约束。即使输出f的规范化一致，也不能直接复用其密度系数、B、FESR或选点数值。无需为此次追踪改变正在进行的IR下截面计算。
