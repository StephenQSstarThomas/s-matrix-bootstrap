"""Saved support matrix/CLI controls. Synthetic reports; solver stages are blocked."""
import copy,hashlib,json
from dataclasses import asdict
from fractions import Fraction
from pathlib import Path
from unittest.mock import patch
import numpy as np
from flint import arb
from smatrix_bootstrap.sdp import __main__ as cli,assembly,sdpb
from smatrix_bootstrap.sdp.pmp import Pmp
from smatrix_bootstrap.sdp.spec import ModelSpec
from smatrix_bootstrap.sdp.constraints import chiral_reference_point

BASE=Path(__file__).resolve().parent;index=1
while (BASE/f'run_{index:02d}').exists():index+=1
ROOT=BASE/f'run_{index:02d}';ROOT.mkdir()
spec=ModelSpec(M=4,L=2,chiral=True,chi_caliber='chi-c',uv=True,sr_caliber='SR-a',
               ff_frozen_at_s0=False,reduce_basis=True,operator_dps=40,scattering_prescription='sine-cardinal')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def source(name,fixed):
    folder=ROOT/name;folder.mkdir();w=Pmp(spec,direction=(1,0),fix_f00=fixed,digits=30)
    info=w.write(str(folder/'pmp.json'));info['sha256']=sha(folder/'pmp.json')
    np.save(folder/'basis.npy',w.basis);np.save(folder/'disk_mask.npy',w.keep)
    record={'solver':'SDPB','status':'numerically_accepted','accepted':True,'spec':asdict(spec),
            'direction':[1.,0.],'fix_f00':fixed,'settings':asdict(sdpb.Settings(digits=30)),
            'verification':{'primal_feasible':True,'f00_3':.2},'convergence':{'solver_optimal':True},
            'pmp':info,'basis':{'sha256':sha(folder/'basis.npy'),'tolerance':spec.basis_tol,
                'normalized_projection_error':w.ops.basis_projection_error},
            'source_sha256':{'src/smatrix_bootstrap/sdp/'+p.name:sha(p) for p in Path(sdpb.__file__).parent.glob('*.py')}}
    path=folder/'report.json';path.write_text(json.dumps(record,indent=2));return path,w

section,w=source('source_with_section',.02);tip,tw=source('source_tip',None)
old=json.loads((section.parent/'pmp.json').read_text());xr=chiral_reference_point()[0]
def forbidden(*args,**kwargs):raise AssertionError('A new SVD/full assembly must not occur')
stage_calls=[]
def block_stage(*args,**kwargs):
    stage_calls.append({'stage':args[1],'args':args[2]});assert args[1]=='pmp2sdp'
    return {'returncode':99,'scope':'synthetic control stopped before any SDPB executable'}
cases=[('custom_fixed',section,['--direction','0','-1','--fix-f00',str(xr)],(0.,-1.),xr),
       ('custom_free',section,['--direction','2','1'],(2.,1.),None),
       ('default_ref',section,[],(0.,1.),xr),('named_tip',section,['--point','tip'],(1.,0.),None),
       ('named_ref',section,['--point','ref'],(0.,1.),xr),
       ('named_mid',tip,['--point','mid'],(0.,1.),(.2+xr)/2)]
results=[]
with patch.object(sdpb,'execute',block_stage),patch.object(Pmp,'__init__',forbidden),patch.object(assembly.Operators,'build_basis',forbidden):
    for name,path,options,d,fixed in cases:
        folder=ROOT/name
        assert cli.main(['support','--source-report',str(path),'--out',str(folder)]+options)==1
        record=json.loads((folder/'report.json').read_text());doc=json.loads((folder/'pmp.json').read_text())
        source_doc=json.loads((path.parent/'pmp.json').read_text());source_record=json.loads(path.read_text())
        base=source_doc['PositiveMatrixWithPrefactorArray'][:-2] if source_record['fix_f00'] is not None else source_doc['PositiveMatrixWithPrefactorArray']
        newbase=doc['PositiveMatrixWithPrefactorArray'][:-2] if fixed is not None else doc['PositiveMatrixWithPrefactorArray']
        assert newbase==base and doc['normalization']==source_doc['normalization']
        assert sha(folder/'basis.npy')==sha(path.parent/'basis.npy')
        original=w if path==section else tw
        expected=[arb(0)]*(original.n_vars);expected[1:1+original.n_a]=d[0]*original.f00+d[1]*original.f11
        differences=[abs(arb(v)-e).abs_upper() for v,e in zip(doc['objective'],expected)]
        assert all(error<max(arb('1e-38'),abs(e)*arb('1e-28')) for error,e in zip(differences,expected))
        if fixed is not None:
            blocks=doc['PositiveMatrixWithPrefactorArray'];plus=blocks[-2]['polynomials'][0][0];minus=blocks[-1]['polynomials'][0][0]
            assert Fraction(plus[0][0])==Fraction(str(fixed)) and all(Fraction(a[0])+Fraction(b[0])==0 for a,b in zip(plus,minus))
        assert record['direction']==list(d) and record['fix_f00']==fixed
        assert record['spec']==source_record['spec'] and record['settings']==source_record['settings']
        results.append({'case':name,'base_blocks_identical':True,'basis_bytes_identical':True,
                        'new_objective_checked':True,'direction':list(d),'fix_f00':fixed,
                        'objective_max_difference_upper':str(max(differences))})
    rejected=[]
    bad_options=[['--direction','0','0'],['--direction','nan','1'],['--direction','inf','0'],
        ['--direction','0','-1','--fix-f00','nan'],['--point','ref','--direction','0','-1'],
        ['--point','ref','--fix-f00',str(xr)],['--fix-f00',str(xr)],['--point','mid']]
    for index,options in enumerate(bad_options):
        before=len(stage_calls)
        try:cli.main(['support','--source-report',str(section),'--out',str(ROOT/f'reject_{index}')]+options)
        except (ValueError,SystemExit) as exc:rejected.append({'options':options,'error':str(exc)})
        else:raise AssertionError('Invalid selection accepted')
        assert len(stage_calls)==before
    for index,options in enumerate([['--direction','0','-1'],['--fix-f00',str(xr)]]):
        before=len(stage_calls)
        try:cli.main(['refine','--source-report',str(section),'--precision','320','--out',str(ROOT/f'reject_refine_{index}')]+options)
        except SystemExit as exc:rejected.append({'command':'refine','options':options,'error':str(exc)})
        else:raise AssertionError('Non-support command silently accepted selection options')
        assert len(stage_calls)==before
    bad=copy.deepcopy(json.loads(section.read_text()));bad['accepted']=False
    path=ROOT/'unaccepted.json';path.write_text(json.dumps(bad))
    try:sdpb.support_from_saved(path,ROOT/'reject_source',direction=(0,-1),fix_f00=xr)
    except ValueError as exc:rejected.append({'source_unaccepted':True,'error':str(exc)})
    else:raise AssertionError('Unaccepted source reused')
result={'synthetic_only':True,'optimizations_launched':0,'stage_calls_blocked':stage_calls,'cases':results,
        'rejected':rejected,'no_new_SVD_or_full_assembly':True,'source_fields_and_options_unchanged':True,
        'producer_sha256':sha(__file__),'source_sha256':{n:sha(Path(sdpb.__file__).with_name(n)) for n in ['sdpb.py','__main__.py','precision_pmp.py','pmp.py']}}
(ROOT/'matrix_validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'positive_cases':len(results),'rejected_cases':len(rejected),'optimizations_launched':0}))
