已保存 PMP 的通用支持接口

```bash
python -m smatrix_bootstrap.run sdp support \
  --source-report /已验收leaf/report.json \
  --direction 0 -1 --fix-f00 0.07332139057293464 \
  --out /新的section_lo目录
```

该例在给定 f00(3) 截面最大化 −f11(3)。`--direction DX DY` 接受任意非零、有限的二维方向，不自动归一化；省略 `--fix-f00` 会移除源 PMP 的旧截面，只保留共同物理约束。提供 `--fix-f00` 时值必须有限，而且必须同时提供 `--direction`。

未提供通用方向时仍默认执行注册的 ref；`--point tip/ref/mid` 保持兼容，mid 仍要求源为同模型已验收 tip。显式 `--point` 不能和新方向/截面选项同时使用；新选项在非 support 命令（包括 refine）中被拒绝。

源必须是数值验收通过的 SDPB leaf。仍经过原有源核、PMP、basis 身份检查；不重新调用完整算子装配或 SVD。只替换目标及可选截面的两个标量块，原物理块、normalization、变量打包和 basis 保留。新报告已有 `direction`、`fix_f00`、`reused_source_report`、输入 PMP/basis 哈希；未更改冻结预登记。

验证使用合成 M4 输入，所有求解阶段均被阻断：6 个 CLI/矩阵正例、11 个拒绝控制通过。比较确认物理矩阵块逐项相同、basis 字节相同，并以独立线性组合验证新目标；截面常数及正负块以精确 Fraction 检查。统一 selfcheck 209 项通过。原始失败控制和修改前源码均保留，本任务没有执行科学 SDPB、选择真实新代表或创建提交。
