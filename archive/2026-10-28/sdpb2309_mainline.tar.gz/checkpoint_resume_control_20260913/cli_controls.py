from pathlib import Path
from dataclasses import asdict
from unittest.mock import patch
import tempfile,json,contextlib,io
from smatrix_bootstrap.sdp.__main__ import main
from smatrix_bootstrap.sdp.sdpb import Settings
from smatrix_bootstrap.sdp.spec import ModelSpec
ROOT=Path(__file__).resolve().parent
cases=[]
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)/'report.json';src={'settings':asdict(Settings(precision=320,nproc=8,timeout=1200)), 'spec':asdict(ModelSpec(M=2,L=1)), 'status':'not_accepted','pmp':{'sha256':'synthetic'},'direction':[0.,-1.],'fix_f00':.07332139057293464}
 def invoke(args,state=None):
  p.write_text(json.dumps(src if state is None else state));calls=[]
  def fake(*a,**kw):calls.append((a,kw));return ({'accepted':True},None,None)
  stderr=io.StringIO()
  with patch('smatrix_bootstrap.sdp.sdpb.run_once',side_effect=fake),contextlib.redirect_stderr(stderr),contextlib.redirect_stdout(io.StringIO()):
   try:rc=main(args)
   except SystemExit as e:rc=e.code
  return rc,calls,stderr.getvalue()
 base=['refine','--source-report',str(p),'--precision','320','--out',str(Path(tmp)/'output')]
 for name,args,expect,timeout in [('resume_override',base+['--resume','--timeout','7200'],0,7200),('resume_saved_budget',base+['--resume'],0,1200),('cold_override',base+['--timeout','7200'],0,7200),('cold_saved_budget',base,0,1200)]:
  rc,calls,error=invoke(args);passed=rc==expect and len(calls)==1
  if passed:
   a,kw=calls[0];passed=a[4].timeout==timeout and kw['exact_input'] is True and bool(kw.get('resume'))==('--resume' in args)
  cases.append({'name':name,'passed':passed,'rc':rc,'error':error[:180]})
 for name,args,state in [('wrong_command',['support','--resume','--out',tmp],None),('zero_timeout',base+['--resume','--timeout','0'],None),('fractional_timeout',base+['--resume','--timeout','1.5'],None),('live_source',base+['--resume'],dict(src,status='solving')),('precision_change',[*base[:base.index('--precision')],'--precision','384','--out',str(Path(tmp)/'new'),'--resume'],None)]:
  rc,calls,error=invoke(args,state);cases.append({'name':name,'passed':rc==2 and not calls,'rc':rc,'error':error[:180]})
print(json.dumps({'passed':all(x['passed'] for x in cases),'cases':cases},indent=2))
