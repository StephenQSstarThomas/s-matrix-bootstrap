同输入 checkpoint 续跑已实现并验证。仅允许已终止、未验收的 SDPB leaf；PMP、basis、模型、目标、截面、精度、MPI ranks 和全部设置必须保持一致，只有正整数 timeout 可覆盖。跨输入 warm start 仍严格要求 accepted 源。

先观察 14 个新增控制因缺少 resume 参数失败；实现后 30 控制通过，既有 SDP 回归 217 项通过。控制脚本保留为非活动 .txt；原两份源码字节保存在 before/。实际 lower 的只读终态预检通过，未启动 solver、未读相位、未改变源 checkpoint。

输入 checkpoint 独立复制，输出仍写新运行的 sdp.ck；current 和 backup 全部 ranks 与 block_timings 保留并逐文件核对 SHA256。checkpoint_loaded 仅记录 SDPB 日志出现加载声明；数值验收仍须重新通过全部检查，不由此字段推导可行或最优。
