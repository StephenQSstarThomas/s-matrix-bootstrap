# C3参考域补全与保存振幅的求解后评价

已修复C3在参考点超出求值域时的静默端点钳位。正常生产与保存振幅重评共用 `observables.subthreshold_grid`：旧40点（s=.05至3.95）∪ Fig.5全部90个独立横坐标 ∪ s=3，共131点；三波各求131点。参考CSV的完整SHA256、实际网格与旧点列表记入每份输出的 `subthreshold.grid_provenance`。只读取参考表的s列，不使用其f列设置求值点。

这些点仅用于求解后的显示与参考比较，没有进入PMP系数、物理输入、χ/SR/FF约束、目标或选点。原精确验收仍先在原网格执行，之后才计算此补全显示。精度按原精确生产器的 `max(256, source_bits)` 继承，没有改变SDPB精度或源算子dps。

修改文件：

- `claims.py`：仅C3增加数组/覆盖检查，并澄清8%是同ε论文彩色曲线的RMS比较，不是理论线性预算；参考点越域时返回 `not run` 与覆盖原因。
- `observables.py`：共同的完整参考网格、覆盖检查，以及保留Arb区间的三波阈下求值；普通求解后显示也使用同网格。
- `precision_pmp.py`：仅替换末尾显示求值循环，调用共同评价函数；约束组装、优化和原式验收没有变化。
- `evaluation.py`：新增保存完整振幅的精确重评与显式内存overlay验证，以及按既有同源目标归组的C3表。
- `figures.py`：`load_reports(root, subthreshold_reports=())` 与 `build_all(root, subthreshold_reports=())` 接收显式补求报告；`tables.json`增加 `C3_by_source_objective`。

本子任务未修改 `__main__.py`；root负责合并统一CLI胶水：

```text
python -m smatrix_bootstrap.run sdp subthreshold \
  --source-report LEAF/report.json --out FRESH

python -m smatrix_bootstrap.run sdp figures \
  --out RUNROOT --subthreshold-replay FRESH/report.json
```

后一个选项可重复，传给 `build_all(..., subthreshold_reports=paths)`。实现入口为 `evaluation.evaluate_subthreshold(source_report, outdir, timeout=600)`。已有C3调用者也可直接使用 `load_reports` 返回的、已经校验的内存数据；原leaf报告不改写。

重评先检查完成态、变量维数、完整y文本的行列数与有限性、NPZ数组形状和y拷贝，然后通过 `Pmp.from_saved` 校验原PMP、basis与源算子身份，`read_solution`读取原完整y文本。振幅在Arb中以原文本乘保存basis重建，NPZ中四舍五入的c不参与求值。此接口要求源报告已有 `y_sha256`；缺少求解时完整文本哈希的旧历史报告不会被当作可精确认证的输入。

输出另写新目录，保存源报告/PMP/basis/y/NPZ/disk-mask/参考CSV哈希、生产代码哈希、每点严格区间端点、旧点一致性和作用域。运行预算默认600秒，在各点之间检查；单次角积分可运行至结束。没有优化、全分波复验或昂贵的对偶重放，也不把此报告当作新的可行性或最优性证书。

显式overlay要求唯一匹配原leaf绝对路径；逐一重新验证输入哈希、核身份、数据内容哈希、参考CSV哈希和完整网格。匹配后只替换内存记录的 `subthreshold`，另保留补求报告哈希与来源。重复补求候选不会自动择优。C3汇总按既有共同源模型、basis、方向和截面归组；同ε有多个幅度时要求明确选择，缺少其他ε时仍然 `not run`。

## 已执行的验证

`CONTROLS.json`记录17项合成控制：

- 实际C3调用的3.95对约3.99钳位反例，修改前继续插值，修改后明确拒绝覆盖不足。
- 全部270条参考记录的90个独立横坐标与旧40点均保留；闭区间端点可用，向外移动一个binary64 ulp则拒绝。
- 独立常量振幅A=2y给出S0=5y、S2=2y、P1=0的已知阈下值，所有输出区间与它们相容；故意污染NPZ c仍不影响结果。
- 对完整y文本作低于binary64分辨率的改动，仍被求解时SHA拒绝；PMP、basis、核、布局、列数、截断、非有限值与非终态均拒绝。
- overlay数据篡改、重复源候选和既有输出目录均拒绝。
- 通过运行时trap确保重评没有调用solver执行、`run_once`、完整`verify`、PMP写出或dual replay。

只实际重评了获准公开旧上点：`IR_M50_L12_shared_basis/ref/report.json`。没有读取新IR下截面的phase/subthreshold。结果在 [IR_M50_L12_ref/report.json](IR_M50_L12_ref/report.json)：M50/L12、原源算子40 dps、原验收Arb精度256 bits，393次三波阈下求值耗时16.58秒。三波的旧40个采样值均逐项完全一致，最大binary64读数差均为0；直接求值f00(3)=0.07332139057293464。

`ACTUAL_REPLAY_VALIDATION.json`还检查了真实旧上点经 `figures.load_reports/build_all` 的overlay往返：得到131点评价数据、完整来源信息，以及因为只有ε=.002而继续为 `not run` 的C3表。原source report哈希未变。为这一接口控制临时创建的源目录符号链接已移除，避免被后续扫描重复发现。

全套现有测试：**213 passed in 72.38s**。三个活动测试文件未增加或修改；新增行为的完整控制producer原字节保存于 `control_producer.txt`，避免突破测试文件数量/行数限制。`BEFORE.json`及`*.before.txt`保留旧字节；`evaluation_at_actual_replay.txt`保存实际重评时的精确producer字节（后续只追加了C3汇总函数）。

这些验证只说明评价网格、来源身份与接口已闭合，不说明C3三组物理幅度已完成。8%比较、零点目标及原预登记均保持原值。
