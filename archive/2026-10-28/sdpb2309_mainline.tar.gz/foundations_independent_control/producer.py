"""Six independent original-angle controls; evidence producer, not production code.

Reference: independently coded finite sine series and mpmath integration in mu.
No SineFamily.cardinal/quadrature/wave or assemble_rows is used by the reference.
The production side uses SineFamily.rows. mpmath's numerical error is not enclosed.
"""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import time

from mpmath import mp
from flint import arb
from smatrix_bootstrap.sdp.sine import SineFamily


ROOT = Path('/home/shiqiu/s-matrix-bootstrap')
DEST = Path(__file__).resolve().parent
M = 4
REFERENCE_DPS = 55
SOURCE_DPS = 40
CASES = [
    ('rho2_offdiag', 0, 0, 2, None),
    ('rho2_offdiag', 1, 1, 2, None),
    ('rho2_diag', 2, 0, None, '1.5'),
    ('rho1_nonsym', 1, 3, 3, None),
    ('rho1_nonsym', 0, 2, None, '.5'),
    ('sigma2', 2, 0, None, '1.5'),
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run():
    started = time.monotonic()
    mp.dps = REFERENCE_DPS
    source = SineFamily(M, 2, SOURCE_DPS)
    lay = source.lay
    phi = [mp.pi * (2*j+1) / (2*M) for j in range(M)]
    D = [[mp.mpf(1 if n == M else 2) / M * mp.sin(n*phi[j])
          for j in range(M)] for n in range(1, M+1)]

    def g(j, v):
        if v > 4:
            z = (2+mp.j*mp.sqrt(v-4)) / (2-mp.j*mp.sqrt(v-4))
        else:
            z = (2-mp.sqrt(4-v)) / (2+mp.sqrt(4-v))
        return sum(D[n-1][j] * (z**n-(-1)**n) for n in range(1, M+1))

    def amplitude(kind, x, y, z):
        if kind == 'rho2_offdiag':
            return g(0,y)*g(3,z) + g(3,y)*g(0,z)
        if kind == 'rho2_diag':
            return g(1,y)*g(1,z)
        if kind == 'rho1_nonsym':
            return g(1,x)*(g(3,y)+g(3,z))
        if kind == 'sigma2':
            return g(2,y)+g(2,z)
        raise ValueError(kind)

    def coefficient_index(kind):
        if kind == 'rho1_nonsym':
            return lay.r1.start+M+3
        if kind == 'sigma2':
            return lay.s2.start+2
        pair = (0,3) if kind == 'rho2_offdiag' else (1,1)
        return lay.r2.start + list(zip(*lay.triu)).index(pair)

    results = []
    for kind, I, ell, node, point in CASES:
        start = time.monotonic()
        s = 8/(1+mp.cos(phi[node])) if node is not None else mp.mpf(point)

        def integrand(mu):
            t = -(s-4)*(1-mu)/2
            u = 4-s-t
            A = amplitude(kind,s,t,u)
            B = amplitude(kind,t,s,u)
            C = amplitude(kind,u,t,s)
            return mp.legendre(ell,mu)*{0:3*A+B+C,1:B-C,2:B+C}[I]/4

        reference = mp.quad(integrand, [-1,0,1])
        rows = source.rows(I,ell,point=point,node=node)
        j = coefficient_index(kind)
        real_difference = abs(rows[0,j]-arb(str(reference.real))).abs_upper()
        imag_difference = abs(rows[1,j]-arb(str(reference.imag))).abs_upper()
        maximum = max(real_difference,imag_difference)
        results.append({
            'case':kind, 'isospin':I, 'ell':ell, 'node_zero_based':node,
            'subthreshold_point_decimal':point, 's_reference':mp.nstr(s,REFERENCE_DPS),
            'production_coefficient_index_zero_based':j,
            'coefficient_value':'1', 'other_coefficients':'0',
            'reference_real':mp.nstr(reference.real,REFERENCE_DPS),
            'reference_imag':mp.nstr(reference.imag,REFERENCE_DPS),
            'production_real_ball':rows[0,j].str(55),
            'production_imag_ball':rows[1,j].str(55),
            'real_difference_upper_dyadic':str(real_difference.upper().fmpq()),
            'imag_difference_upper_dyadic':str(imag_difference.upper().fmpq()),
            'max_absolute_difference_upper':maximum.str(55),
            'max_absolute_difference_upper_dyadic':str(maximum.upper().fmpq()),
            'below_1e-34':bool(maximum < arb('1e-34')),
            'seconds':time.monotonic()-start,
        })
    paths = ['src/smatrix_bootstrap/sdp/'+name for name in
             ('sine.py','precision.py','projector.py','grid.py','assembly.py',
              'pmp.py','precision_pmp.py','arbaudit.py','formfactor.py','constraints.py')]
    report = {
        'M':M, 'L_source_constructor':2, 'reference_mpmath_dps':REFERENCE_DPS,
        'source_dps':SOURCE_DPS, 'cases':results,
        'all_below_1e-34':all(r['below_1e-34'] for r in results),
        'reference_integral':{
            'method':'mpmath.mp.quad default tanh-sinh', 'breakpoints':['-1','0','1'],
            'variable':'original mu; no production x/tanh angular transformation',
            'formula':'f=(1/4) integral P_ell(mu) T^I(s,t,u) dmu; t=-(s-4)(1-mu)/2; u=4-s-t',
            'isospin':'T0=3A(s,t,u)+A(t,s,u)+A(u,t,s); T1=A(t,s,u)-A(u,t,s); T2=A(t,s,u)+A(u,t,s)',
            'cardinal':'g_j=sum_n D_nj (z^n-(-1)^n); D_nj=2 sin(n phi_j)/M except D_Mj=sin(M phi_j)/M',
            'physical_boundary':'upper lip, z=(2+i sqrt(s-4))/(2-i sqrt(s-4))',
            'rho2_offdiag':'rho2[0,3]=rho2[3,0]=1; one packed variable',
            'rho2_diag':'rho2[1,1]=1',
            'rho1_nonsym':'rho1[1,3]=1; rho1[3,1]=0',
            'sigma2':'sigma2[2]=1',
        },
        'scope':{
            'independent_reference':'Original-angle integration, separate mpmath geometry and sine-series implementation.',
            'production_path':'SineFamily.rows uses production geometry, transformed quadrature and assemble_rows.',
            'limitations':'Numerical comparison only. Arb bounds enclose production uncertainty plus difference to the printed mpmath value; mpmath quadrature/truncation error is not rigorously enclosed. Six cases do not prove the complete pipeline, M50 convergence, continuum unitarity, or optimizer correctness.',
            'optimization_performed':False, 'production_code_modified':False,
            'origin':'Rerun of the same six controls performed during the read-only foundations audit.',
        },
        'source_sha256':{path:sha(ROOT/path) for path in paths},
        'producer_sha256':sha(__file__), 'producer_path':str(Path(__file__).resolve()),
        'versions':{name:importlib.metadata.version(name) for name in ('mpmath','python-flint','numpy')},
        'python_version':platform.python_version(), 'seconds':time.monotonic()-started,
    }
    output = DEST/'report.json'
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'report':str(output),'report_sha256':sha(output),
                      'all_below_1e-34':report['all_below_1e-34'],
                      'seconds':report['seconds']}))


if __name__ == '__main__':
    run()
