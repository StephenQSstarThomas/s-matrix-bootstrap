"""Regression evidence for independent original-angle polynomial contraction."""
import hashlib,json
from pathlib import Path
from mpmath import mp
from smatrix_bootstrap.sdp import crosscheck

assert hasattr(crosscheck, 'OriginalAngle'), 'Independent original-angle audit is missing'
mp.dps = 70
reference = json.loads(Path(__file__).with_name('report.json').read_text())
cases = []
for row in reference['cases']:
    c = [0]*35
    c[row['production_coefficient_index_zero_based']] = 1
    model = crosscheck.OriginalAngle(4,c,70)
    s = mp.mpf(row['s_reference'])
    value = model.integrate(row['isospin'],row['ell'],s,6)
    expected = mp.mpc(row['reference_real'],row['reference_imag'])
    error = abs(value-expected)
    assert error < mp.mpf('1e-34'), (row['case'],error)
    cases.append({'case':row['case'],'I':row['isospin'],'ell':row['ell'],
                  'error':str(error),'passed':True})
result={'cases':cases,'all_passed':all(row['passed'] for row in cases),
        'reference_dps':70,'gauss_order':96,
        'test_producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'crosscheck_sha256':hashlib.sha256(Path(crosscheck.__file__).read_bytes()).hexdigest()}
Path(__file__).with_name('angle_reference_validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
