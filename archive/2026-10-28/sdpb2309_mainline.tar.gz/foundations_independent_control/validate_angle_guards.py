"""Reject malformed frozen witnesses without performing an angular calculation."""
import copy,hashlib,json,tempfile
from pathlib import Path
import numpy as np
from smatrix_bootstrap.sdp.crosscheck import audit_angles

DEST=Path(__file__).resolve().parent
SOURCE=Path('/playpen1/shiqiu/sdpb_mainline_20260912/UV_M50_sine_d40_p30/support')
SNAPSHOT=Path('/home/shiqiu/s-matrix-bootstrap/results/runs/sdpb_mainline_20260912/source_at_sine_UV_launch.json.gz')
original=json.loads((SOURCE/'report.json').read_text())
controls=[('live status','completed'),('missing verification','completed'),('unreduced','reduced'),
          ('zero timeout','positive finite'),('nan timeout','positive finite'),
          ('infinite timeout','positive finite'),('bad y header','header'),
          ('nonfinite y','Nonfinite'),('y hash','hash'),('bad basis','finite binary64')]
results=[]
for name,expected in controls:
    with tempfile.TemporaryDirectory(prefix='guard_',dir=DEST) as temp:
        folder=Path(temp);(folder/'out').mkdir();rec=copy.deepcopy(original);timeout=600
        for f in ('basis.npy','solution.npz','pmp.json'):(folder/f).symlink_to(SOURCE/f)
        (folder/'out/y.txt').symlink_to(SOURCE/'out/y.txt')
        if name=='live status':rec['status']='solving'
        if name=='missing verification':rec.pop('verification')
        if name=='unreduced':rec['spec']['reduce_basis']=False
        if name=='zero timeout':timeout=0
        if name=='nan timeout':timeout=float('nan')
        if name=='infinite timeout':timeout=float('inf')
        if name in ('bad y header','nonfinite y'):
            rows=(SOURCE/'out/y.txt').read_text().splitlines()
            if name=='bad y header':rows[0]=rows[0].split()[0]+' 2'
            else:rows[1]='nan'
            (folder/'out/y.txt').unlink();(folder/'out/y.txt').write_text('\n'.join(rows)+'\n')
        if name=='y hash':rec['y_sha256']='0'*64
        if name=='bad basis':
            (folder/'basis.npy').unlink();np.save(folder/'basis.npy',np.array([[float('nan')]],dtype=np.float32))
            rec['basis']['sha256']=hashlib.sha256((folder/'basis.npy').read_bytes()).hexdigest()
        (folder/'report.json').write_text(json.dumps(rec))
        try:audit_angles(folder/'report.json',folder/'audit',timeout=timeout,snapshot=SNAPSHOT)
        except ValueError as exc:
            assert expected in str(exc),(name,str(exc));results.append({'control':name,'rejected':str(exc)})
        else:raise AssertionError('Malformed source accepted: '+name)
result={'all_rejected':True,'controls':results,
        'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(DEST/'angle_guard_validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
