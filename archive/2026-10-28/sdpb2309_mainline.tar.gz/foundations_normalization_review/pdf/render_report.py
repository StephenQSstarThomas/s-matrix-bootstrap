from pathlib import Path
import sys,re,html,io
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root.parents[1]/'deepresearch/report-tools'))
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,Image,Preformatted,KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
pdfmetrics.registerFont(TTFont('CN','/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf'))
pdfmetrics.registerFont(TTFont('Latin','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
style=ParagraphStyle('Body',fontName='CN',fontSize=10.0,leading=14.9,spaceAfter=6,wordWrap='CJK')
heading=ParagraphStyle('Heading',parent=style,fontSize=15,leading=21,spaceAfter=13)
title=ParagraphStyle('Title',parent=style,fontSize=20,leading=26,spaceAfter=17)
cell=ParagraphStyle('Cell',parent=style,fontSize=8.6,leading=12,spaceAfter=1)
code=ParagraphStyle('Code',fontName='CN',fontSize=8,leading=12,wordWrap='CJK',spaceAfter=7)
W=468

def rich(s):
 s=html.escape(s)
 s=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<link href="\2" color="#333333"><u>\1</u></link>',s)
 s=re.sub(r'\*\*(.+?)\*\*',r'\1',s)
 s=re.sub(r'`([^`]+)`',r'\1',s)
 s=re.sub(r'\[(\d+)\]',r'<super>[\1]</super>',s)
 parts=re.split(r'(<[^>]+>)',s)
 for i,part in enumerate(parts):
  if part.startswith('<'):continue
  raw=html.unescape(part);runs=[];start=0;last=None
  for j,c in enumerate(raw):
   font='CN' if ord(c)>=0x2e80 else 'Latin'
   if font!=last:
    if last is not None:runs.append('<font name="'+last+'">'+html.escape(raw[start:j])+'</font>')
    start=j;last=font
  if last is not None:runs.append('<font name="'+last+'">'+html.escape(raw[start:])+'</font>')
  parts[i]=''.join(runs)
 return ''.join(parts)

def equation(expr,i):
 expr=expr.replace(r'\frac14',r'\frac{1}{4}').replace(r'\frac1M',r'\frac{1}{M}')
 if r'\begin{pmatrix}' in expr:
  expr=r'\widehat G=[(1,S,F);\ (S^*,1,F^*);\ (F^*,F,\widehat\rho)]\succeq0'
 fig=plt.figure(figsize=(9,.7));fig.patch.set_facecolor('white')
 fig.text(.01,.5,'$'+expr+'$',fontsize=13,va='center')
 path=root/f'equation_{i}.png';fig.savefig(path,dpi=210,bbox_inches='tight',pad_inches=.05);plt.close(fig)
 from PIL import Image as PI
 im=PI.open(path);w,h=im.size;scale=min(W/w,1/2)
 return Image(str(path),width=w*scale,height=h*scale)

text=(root/'REPORT_ZH.md').read_text();lines=text.splitlines();story=[];i=0;ei=0
while i<len(lines):
 line=lines[i].strip()
 if not line:i+=1;continue
 if line=='<!-- pagebreak -->':story.append(PageBreak());i+=1;continue
 if line.startswith('## '):story.append(Paragraph(rich(line[3:]),heading));i+=1;continue
 if line.startswith('# '):story.append(Paragraph(rich(line[2:]),title));i+=1;continue
 if line.startswith('$$'):
  expr=line.strip('$');story.append(equation(expr,ei));story.append(Spacer(1,10));ei+=1;i+=1;continue
 if line.startswith('```'):
  block=[];i+=1
  while i<len(lines) and not lines[i].startswith('```'):block.append(lines[i]);i+=1
  story.append(Paragraph('<br/>'.join(rich(x) for x in block),code));i+=1;continue
 if line.startswith('|'):
  rows=[]
  while i<len(lines) and lines[i].strip().startswith('|'):
   row=lines[i].strip().strip('|').split('|')
   if not all(re.fullmatch(r'[-: ]+',x) for x in row):rows.append([Paragraph(rich(x.strip()),cell) for x in row])
   i+=1
  widths=[W/len(rows[0])]*len(rows[0]);t=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
  t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#eeeeee')),('LINEBELOW',(0,0),(-1,0),.6,colors.black),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#dddddd')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),5)]))
  story.extend([t,Spacer(1,10)]);continue
 block=[line];i+=1
 while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','$$','```','<!--')):block.append(lines[i].strip());i+=1
 story.append(Paragraph(rich(' '.join(block)),style))
SimpleDocTemplate(str(root/'REPORT_ZH.pdf'),pagesize=(595.28,841.89),rightMargin=63,leftMargin=64,topMargin=49,bottomMargin=46,title='SDPB主线的底层归一化与工作流核验').build(story)
print(root/'REPORT_ZH.pdf')
