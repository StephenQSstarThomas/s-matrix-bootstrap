# 同 M 跨 L 基底坐标运输：最小实现与验证

**已实现，仅改变 `assembly.load_saved_basis` 的坐标兼容性。** M、解析族、packing、源接受、实际 basis SHA、float64 有限性及原变量布局 guard 均保留；只移除 L 相等条件。保存矩阵和 n_a 不变，返回元数据增加 `source_L`、`target_L`、`cross_L`，继续明确 `target_svd_tolerance_applied=False`、`feasibility_transferred=False`、`constraints_reassembled=True`。

该能力用于同一原密度坐标空间内的受控 L 比较；正式 C8 仍对应论文 L8/L10/L12。下一项 L13 诊断由主线程独立冻结、生成和验收，本子任务未启动 SDPB，也未进行全量 M50 装配。冻结的 17-case 包没有改动。

## TDD 与实际小 PMP 控制

修改前保存了 assembly.py 与三个活动测试文件的原字节、行数和 SHA（`BEFORE_SOURCE.json.gz`、`BEFORE.json`）。先扩展一个既有测试函数的参数：L12→10、L12→13、L10→12 正例实际被旧 guard 拒绝；同 L 的新元数据检查也失败。`RED_TESTS.txt` 记录 **4 failed、9 passed**，失败原因分别为 `Basis source differs in L` 与缺少 `source_L`，未以其它错误冒充红阶段。

仅两处源码改动后，13 个定向测试全部通过。负例保留或增加了 M、family、hash、layout、packing 标签、producer、非有限 basis、未接受来源及未要求 reduce-basis 的拒绝。目标 `basis_tol=.5` 仍不会重截断来源矩阵；其来源容差与实际字节保留。

独立 `control_producer.py` 使用 **实际 M4 源算子和 fresh PMP 写出**，仅其“accepted source”前提是合成元数据，不冒称完成过物理求解。检查全部目标 mask 的 `(I,ell,node)` 身份，而不是复制随 L 移位的旧数组；块数由散射盘、两组 χ、Gram、ρ 非负、四矩上下界、FF 与两条截面约束独立计数：

| 运输 | 目标 IR 块数 | 目标完整 UV/Gram 块数 |
|---|---:|---:|
| L12→10 | 124 | 142 |
| L12→13 | 160 | 178 |
| L10→12 | 148 | 166 |
| L12→13，显式目标 subset | 10 | 34 |

八组全部通过：目标 `keep` 长度为 3ML_target，Gram 主波只在目标索引的 I0/ell0 与 I1/ell1 处替换；来源 report/PMP/basis/mask 文件哈希不变。运行时 trap 确认目标没有调用 SVD、重新构建 basis 或 solver。旧长度 mask 直接传入目标被拒绝。

**Prepared PMP 跨 L 仍禁止。** 使用 `run_once(..., prepared=旧源)` 与不同 L 的目标 spec，八组均触发既有 `Prepared constraints do not match the requested model`，且拒绝时尚未写目标 PMP。没有修改 prepared、mask、目标或原式验收规则。

最后只执行了一次完整公共 `sdp selfcheck`，单线程 BLAS/OMP/MKL：**222 passed in 77.18s**。较原 217 项增加 5 项参数化用例（3 个跨 L 正例，以及 family/producer 负例；packing 标签和 producer 检查分别保留）。三个活动测试文件仍分别为 347、346、350 行，没有新活动测试文件。

## 精度与科学范围

预实现审查中，所选 M50 共享行的 dyadic 中点、30 位文本与 binary64 字节相同；一个 L10/L12 的近阈值高波行有 431 个 Arb 半径不同。本次**不声称所有 Arb 球或新旧完整 PMP 的共享块逐字节相同**。真实 M50 目标仍须按 `(I,ell,node)` 对齐检查共同块、解释可能的末位差异，并对目标约束重新验收。

基底坐标运输不转移可行性或最优性；增加 L 施加新分波，减小 L 也不证明旧目标已是新问题的最优点。原始密度空间维数只依赖 M，保持同一 U 使新的比较可以将“改变施加波集合”与“重新选择 SVD 子空间”分开；它不证明完整空间等价、截断收敛或 C8 已完成。

## 最终文件身份

- `assembly.py`：270 行、15,087 bytes；SHA256 `7299efa62bc2e68f7818be216c83f4de01524f4c49bfe56e6bb962d8181379f9`。
- 唯一改动活动测试：`tests/sdp/test_sdp_crosscheck.py`，346 行、20,711 bytes。
- `FOCUSED_TESTS.txt`、`PMP_CONTROLS.json`、`FULL_TESTS.txt` 保存各层结果；`PATCH.diff`、`AFTER_SOURCE.json.gz`、`FINAL_VALIDATION.json` 保存差异、最终原字节与哈希。

依据与精度范围见此前 [同 M 跨 L 预实现审查](../same_M_cross_L_basis_review_20260913/REPORT_ZH.md)。论文对 M 维谱坐标与 L 分波截断的区分见 [第 21 页式 (3.62)](https://arxiv.org/pdf/2309.12402v3#page=21)及[第 36 页附录 A](https://arxiv.org/pdf/2309.12402v3#page=36)。
