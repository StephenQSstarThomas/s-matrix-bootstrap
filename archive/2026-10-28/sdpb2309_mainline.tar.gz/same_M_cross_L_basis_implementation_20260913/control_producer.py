"""Small actual PMP construction controls; no SDPB or M50 assembly."""
from dataclasses import asdict,replace
import hashlib
import json
import math
from pathlib import Path
from unittest.mock import patch
import numpy as np
from smatrix_bootstrap.sdp.pmp import Pmp
from smatrix_bootstrap.sdp.spec import ModelSpec
from smatrix_bootstrap.sdp.assembly import Operators
from smatrix_bootstrap.sdp.sdpb import run_once,Settings

HERE=Path(__file__).resolve().parent
REPO=Path('/home/shiqiu/s-matrix-bootstrap')
SRC=REPO/'src/smatrix_bootstrap/sdp'
M=4
XR=.07332139057293464
RESULT=[];SOURCES={}


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,record):path.write_text(json.dumps(record,indent=2)+'\n')
def forbidden(*args,**kwargs):raise AssertionError('Unexpected SVD or solver execution')


def source(L,uv):
    key=(L,uv)
    if key in SOURCES:return SOURCES[key]
    dest=HERE/f'synthetic_source_L{L}_UV{int(uv)}'
    if dest.exists():raise FileExistsError('Preserve source fixture bytes')
    dest.mkdir()
    spec=ModelSpec(M=M,L=L,chiral=True,chi_caliber='chi-c',uv=uv,sr_caliber='SR-a',
                   ff_frozen_at_s0=False,reduce_basis=True,operator_dps=40,scattering_prescription='sine-cardinal')
    w=Pmp(spec,digits=30);info=w.write(str(dest/'pmp.json'));info['sha256']=sha(dest/'pmp.json')
    np.save(dest/'basis.npy',w.basis);np.save(dest/'disk_mask.npy',w.keep)
    record={'solver':'SDPB','status':'numerically_accepted','accepted':True,'spec':asdict(spec),
            'verification':{'primal_feasible':True,'source_audit':{'scattering_prescription':'sine-cardinal'}},
            'convergence':{'solver_optimal':True},'pmp':info,
            'basis':{'sha256':sha(dest/'basis.npy'),'tolerance':spec.basis_tol},
            'source_sha256':{'src/smatrix_bootstrap/sdp/'+p.name:sha(p) for p in SRC.glob('*.py')},
            'fixture_scope':'Actual small source operator/PMP, synthetic acceptance metadata only; no scientific solution.'}
    write(dest/'report.json',record)
    hashes={p.name:sha(p) for p in dest.iterdir() if p.is_file()}
    SOURCES[key]=(dest,spec,w.basis.copy(),hashes)
    return SOURCES[key]


def check(Ls,Lt,uv,subset=False):
    dest,spec,basis,hashes=source(Ls,uv)
    keys=[(I,ell,node) for I in (0,1,2) for ell in range(I%2,2*Lt,2) for node in range(M)]
    selected={(0,0,0),(0,2,1),(1,1,2),(1,3,0),(2,0,1),(2,2,3)}
    mask=[key in selected for key in keys] if subset else None
    expected=[(key in selected if subset else True) and not (uv and (key[0],key[1]) in ((0,0),(1,1))) for key in keys]
    target=replace(spec,L=Lt,basis_tol=.5,disk_mask=mask)
    out=HERE/f'target_{Ls}_{Lt}_UV{int(uv)}_subset{int(subset)}'
    if out.exists():raise FileExistsError('Preserve target fixture bytes')
    out.mkdir()
    with (patch.object(Operators,'build_basis',side_effect=forbidden),
          patch('numpy.linalg.svd',side_effect=forbidden),
          patch('smatrix_bootstrap.sdp.sdpb.execute',side_effect=forbidden)):
        w=Pmp(target,direction=(0.,1.),fix_f00=XR,digits=30,basis_source_report=dest/'report.json')
        info=w.write(str(out/'pmp.json'))
    assert w.basis.tobytes()==basis.tobytes() and w.basis.shape==basis.shape
    assert w.keep.tolist()==expected and len(w.keep)==3*M*Lt
    assert w.ops.index==[(I,ell) for I in (0,1,2) for ell in range(I%2,2*Lt,2)]
    assert w.basis_source['cross_L'] and w.basis_source['source_L']==Ls and w.basis_source['target_L']==Lt
    assert not w.basis_source['feasibility_transferred'] and not w.basis_source['target_svd_tolerance_applied']
    hi=sum(8/(1+math.cos(math.pi*(j+.5)/M))>(1.2/.14)**2 for j in range(M))
    counts={'disks':sum(expected),'chiral':2,'section':2,'gram':2*M if uv else 0,
            'rho_nonnegative':2*M if uv else 0,'FESR':8 if uv else 0,'FF':2*hi if uv else 0}
    assert info['n_blocks']==sum(counts.values())
    actual=json.loads((out/'pmp.json').read_text())
    assert len(actual['PositiveMatrixWithPrefactorArray'])==sum(counts.values())
    assert actual['objective']==w._num_vec(w.objective())
    assert {p.name:sha(p) for p in dest.iterdir() if p.is_file()}==hashes
    # Old-length masks and prepared PMPs must never cross L with the basis.
    try:Pmp(replace(target,disk_mask=np.load(dest/'disk_mask.npy').tolist()),digits=30,basis_source_report=dest/'report.json')
    except ValueError as exc:assert 'mask' in str(exc).lower()
    else:raise AssertionError('Old source mask was accepted at target L')
    with patch('smatrix_bootstrap.sdp.sdpb.execute',side_effect=forbidden):
        try:run_once(target,out/'prepared_forbidden',direction=(1.,0.),settings=Settings(digits=30),prepared=dest/'report.json')
        except ValueError as exc:assert 'Prepared constraints do not match' in str(exc)
        else:raise AssertionError('Prepared PMP was transported across L')
    assert not (out/'prepared_forbidden/pmp.json').exists()
    assert {p.name:sha(p) for p in dest.iterdir() if p.is_file()}==hashes
    RESULT.append({'source_L':Ls,'target_L':Lt,'UV_Gram':uv,'target_subset':subset,
                   'basis_shape':list(basis.shape),'basis_bytes_unchanged':True,'source_files_unchanged':True,
                   'block_counts':counts,'total_blocks':info['n_blocks'],'target_mask_length':len(w.keep),
                   'false_mask_keys':[key for key,keep in zip(keys,expected) if not keep],
                   'no_target_SVD':True,'old_length_mask_rejected':True,'prepared_cross_L_rejected_before_PMP_write':True})


for Ls,Lt in ((12,10),(12,13),(10,12)):
    for uv in (False,True):check(Ls,Lt,uv)
for uv in (False,True):check(12,13,uv,True)
write(HERE/'PMP_CONTROLS.json',{'passed':True,'synthetic_only':True,'source_acceptance_is_fixture_metadata':True,
                              'scientific_solves':0,'M50_assembly':False,'cases':RESULT,
                              'source_hashes':{str(k):v[3] for k,v in SOURCES.items()},'producer_sha256':sha(__file__),
                              'scope':'Fresh target PMP block/mask/layout and goal construction only. No feasibility or all-Arb-ball identity claim.'})
print(json.dumps({'passed':True,'cases':len(RESULT),'target_block_counts':[x['total_blocks'] for x in RESULT]}))
