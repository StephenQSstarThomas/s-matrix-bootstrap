"""Synthetic retained-space identity controls; no optimization or feasibility transfer."""
import copy,hashlib,json
from pathlib import Path
import numpy as np
from smatrix_bootstrap.sdp import assembly,delivery,figures

ROOT=Path(__file__).resolve().parent/'delivery_controls';ROOT.mkdir(exist_ok=True)
fixtures=Path('/playpen1/shiqiu/sdpb_mainline_20260912/reference_contrast_validation/run_02')
def leaf(uv,column):
    name='UV' if uv else 'IR';path=ROOT/name;path.mkdir(exist_ok=True)
    r=json.loads((fixtures/f'synthetic_{name}_ref.json').read_text())
    r['spec']['tag']='synthetic basis identity control'
    V=np.zeros((3876,1));V[column,0]=1;np.save(path/'basis.npy',V)
    r['basis']={'sha256':hashlib.sha256((path/'basis.npy').read_bytes()).hexdigest(),'packing':assembly.BASIS_PACKING}
    r['pmp']={'path':str(path/'pmp.json'),'n_a':1}
    r['source_sha256']={'src/smatrix_bootstrap/sdp/'+n:hashlib.sha256(Path(assembly.__file__).with_name(n).read_bytes()).hexdigest() for n in ('projector.py','grid.py')}
    (path/'report.json').write_text(json.dumps(r));return path/'report.json',r
ip,ir=leaf(False,0);up,uv=leaf(True,0)
same=delivery.deliver(ip,up,ROOT/'same',reference_only=True)
assert same['causal_comparison_supported'] is True and same['main_contrast_pass'] is False
up,uv=leaf(True,1)
different=delivery.deliver(ip,up,ROOT/'different',reference_only=True)
assert different['causal_comparison_supported'] is False and different['main_contrast_pass'] is False
def chain(ref):
    records={n:copy.deepcopy(ref) for n in ('tip','ref','mid')}
    records['tip'].update(direction=[1.,0.],fix_f00=None);records['tip']['verification']['f00_3']=.1
    records['mid']['fix_f00']=(.1+ref['fix_f00'])/2
    return {'reports':records}
for name,r in [('full_IR',ir),('full_UV',uv)]:(ROOT/(name+'.json')).write_text(json.dumps(chain(r)))
full=delivery.deliver(ROOT/'full_IR.json',ROOT/'full_UV.json',ROOT/'full_different')
assert not full['causal_comparison_supported'] and not full['main_contrast_pass']
loaded=figures.load_reports(str(ROOT/'UV'))[0]
assert loaded['basis']['sha256']==uv['basis']['sha256'] and figures.accepted_support(loaded)
(ROOT/'UV/basis.npy').write_bytes((ROOT/'IR/basis.npy').read_bytes())
tampered=figures.load_reports(str(ROOT/'UV'))[0]
assert not figures.accepted_support(tampered) and not tampered['basis_identity']['verified']
report={'synthetic_only':True,'same_basis_reference_causal_flag':True,'different_basis_reference_rejected_as_causal':True,
        'full_three_point_different_basis_not_main_pass':True,'loader_retains_basis_and_rejects_changed_bytes':True,
        'no_optimizations':True,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
