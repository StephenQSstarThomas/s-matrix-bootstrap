"""Compare Python's 2309 operators with independent 100-digit Mathematica formulas."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

import numpy as np

from . import constraints as C, formfactor as F, grid

MMA_TIMEOUT_SECONDS = 18000

def _compare(M, ref):
    ours = {"nodes": grid.s_nodes(M), "weights": grid.quad_weights(M),
            "hilbert": F.hilbert_kernel(M),
            "kinematic": np.array([F.kinematic_factor(e, grid.s_nodes(M)) for e in (0, 1)]),
            "targets": np.array(list(C.printed_targets().values()))}
    errors = {}
    for key,value in ours.items():
        target = np.asarray(ref[key],dtype=float)
        if target.shape != value.shape or not np.all(np.isfinite(target)):
            raise ValueError(f'Mathematica reference shape/value mismatch: {key}')
        errors[key] = float(np.max(abs(value-target)/np.maximum(abs(target),1e-30)))
    return errors


def reuse_audit(M, workdir, reference_report):
    """Recheck current arithmetic against an authenticated completed MMA control."""
    import shutil
    source,path = Path(reference_report).resolve(),Path(workdir).resolve()
    report = json.loads(source.read_text())
    script = Path(__file__).resolve().parents[3]/'scripts/mma/audit_2309.wls'
    digest = hashlib.sha256(script.read_bytes()).hexdigest()
    if not report.get('passed') or report.get('returncode')!=0 or report.get('script_sha256')!=digest:
        raise ValueError('Mathematica reuse requires a passed audit of the current script')
    original = source.parent/'independent.json';ref=json.loads(original.read_text())
    reference_hash = hashlib.sha256(original.read_bytes()).hexdigest()
    if report.get('independent_sha256',reference_hash)!=reference_hash:
        raise ValueError('Mathematica reference output hash mismatch')
    errors = _compare(M,ref)
    if not ref.get('gram_identity') or ref.get('working_precision',0)<100 or max(errors.values())>=1e-10:
        raise ValueError('Mathematica reference fails current formula comparison')
    if path.exists() and any(path.iterdir()):
        raise FileExistsError('Preserve existing Mathematica evidence; use a fresh directory')
    path.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(original,path/'independent.json')
    result = {'passed':True,'returncode':0,'reused':True,'source_report':str(source),
              'source_report_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
              'independent_sha256':reference_hash,'script_sha256':digest,'relative_errors':errors,
              'working_precision':ref['working_precision'],'version':ref['version'],
              'gram_identity':True,'M':M,
              'scope':'same-script Mathematica output; current Python formulas rechecked, no solver certificate'}
    (path/'report.json').write_text(json.dumps(result,indent=2))
    return result


def audit(M, workdir):
    root = Path(__file__).resolve().parents[3]
    path = Path(workdir).resolve()
    path.mkdir(parents=True, exist_ok=True)
    script = root / "scripts/mma/audit_2309.wls"
    cmd = [str(root / "scripts/mma/wolfram.sh"), str(script),
           f"rw:{path}:/audit", "--", str(M), "/audit/independent.json"]
    cidfile = path / "mma.cid"
    with (path / "mma.log").open("w") as log:
        from .sdpb import stop_owned_process, wait_process
        proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT,
            env=dict(os.environ, MMA_CIDFILE=str(cidfile)), start_new_session=True)
        try:
            rc = wait_process(proc, MMA_TIMEOUT_SECONDS)
        finally:
            if proc.poll() is None:
                stop_owned_process(proc, cidfile, log)
    result = {"returncode": rc, "command": cmd,
              "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(), "passed": False}
    if rc == 0 and (path / "independent.json").exists():
        ref = json.loads((path / "independent.json").read_text())
        errors = _compare(M,ref)
        result.update(relative_errors=errors, gram_identity=ref["gram_identity"],
                      version=ref["version"], working_precision=ref["working_precision"],
                      M=M,independent_sha256=hashlib.sha256((path/'independent.json').read_bytes()).hexdigest())
        result["passed"] = ref["gram_identity"] and max(errors.values()) < 1e-10
    (path / "report.json").write_text(json.dumps(result, indent=2))
    return result
