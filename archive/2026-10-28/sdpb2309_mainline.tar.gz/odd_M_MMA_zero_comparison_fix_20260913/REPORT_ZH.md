# 奇数 M 的 MMA 精确零比较修复

M45 的独立 Mathematica 已成功执行（rc=0、100位工作精度、Gram恒等式为真、当前脚本SHA匹配）。失败发生在 Python 比较器：对精确零参考使用 max(|reference|,1e-30) 作分母，把约1e-18的正常binary64舍入残差变成约1.36e12的所谓“相对误差”。原M45失败报告和independent.json字节完整保留。

## 数学定位与有界修改

在现有audit_2309.wls的K矩阵公式中，奇数M反对角线满足i+j=M+1：第一项为cot(−π/2)=0，第二项因i−j为偶数而为0。因此M45恰有45个精确零参考项。Python浮点三角函数留下约−1.3607186657192814e−18的残差；非零K最大相对误差只有7.850893071291627e−15，全矩阵最大绝对差4.9960036108132044e−15。

仅修改mma.py的诊断与复用门槛；hilbert、formfactor、precision、grid等公式和PMP系数生产核均未改变。非零项严格保留relative<1e−10，并取消把微小非零项截成1e−30的分母floor。只有参考值精确等于零时，使用独立绝对舍入预算32*eps_float64*max(1,maxabs(reference array))。这是浮点公式对照的舍入诊断，不是放宽任何物理约束。

M45 Hilbert的零点绝对预算为7.105427357601002e−15；实测1.3607186657192814e−18通过。1e−9零点扰动被拒绝；2e−40对1e−40的非零参考也被拒绝。比较器分别记录nonzero relative、exact-zero absolute、各自阈值/个数及全数组绝对误差，避免把混合误差标作相对误差。双方NaN/Inf和shape不匹配拒绝。

## 旧独立输出的安全复核

允许旧Python比较passed=False的记录作为已执行Mathematica数据源，前提是原执行returncode严格为0、scriptSHA当前、independentSHA必填且匹配、report M匹配、Gram身份与version/工作精度元数据一致且至少100位。随后必须重新通过当前全部数组比较。失败过程、缺失哈希、修改后的输出、旧脚本、错误Gram、低精度、非零系数偏差或不合法数组均不可绕过。

复核输出明确记录source_comparison_passed=False与source_execution_returncode=0，不改原报告。实际M45复核结果在validated_M45_reuse/；同一个原independent.json按字节复制。两份指定M50参考UV_M50_L12_fpi_calibrated_eps00021_tip/mma与IR_M50_L12_fpi_calibrated_eps00021_upper/mma也通过只读元数据、哈希和当前比较检查，未重新执行MMA或复制它们。

## 验证记录

永久比较器测试先出现8项RED；临时复用控制先出现7失败/9通过，确认旧代码拒绝有效旧false记录，却漏掉缺失hash、report Gram/精度/M与ours NaN等检查。修改后8项永久比较控制和16项复用控制通过。经统一入口 `python -m smatrix_bootstrap.run sdp selfcheck`，原222项加8项新控制共230项全部通过，pytest用时78.39秒、外部生命周期80.2189秒；完整结果见regression_selfcheck.log与validation.json。

为遵守三份测试文件及350行限制，仅移除test_sdp_projector.py中字符串之外的空行，并追加8例参数化测试；旧测试AST（包括docstring）保持完全相同。临时复用控制保留为test_reuse.py.txt，不新增第四个活动测试文件。

所有修改前字节及哈希在before/；actual_rechecks.json记录实际M45和M50结果。无solver/MMA启动，无源checkpoint/中央文档/冻结包修改。

## 实际资源纠正记录

第一次完整回归直接使用pytest，绕过既有selfcheck线程保护，实际达到约5055%CPU。按root明确指令只向自身pytest PID675424发送SIGINT：177项已通过、无失败，用时360.85秒，按interrupted_by_resource_guard分类保存原日志。之后通过同一公开selfcheck入口重跑相同测试，SDP_TEST_THREADS、OPENBLAS_NUM_THREADS、OMP_NUM_THREADS与MKL_NUM_THREADS均显式设为1，230项通过。没有操作任何科学solver进程。
