"""Serialize the accepted, selected observations; no optimization or rephasing."""
from pathlib import Path
import csv, json, hashlib, datetime
ROOT=Path(__file__).resolve().parent; RUN=ROOT.parent; REPO=Path('/home/shiqiu/s-matrix-bootstrap')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
paths={'IR_selected_upper':'IR_M50_L12_fpi_calibrated_eps00021_upper/ref/report.json',
 'UV_tip':'UV_M50_L12_fpi_calibrated_eps00021_tip/tip/report.json',
 'UV_ref':'UV_M50_L12_fpi_calibrated_eps00021_ref/ref/report.json',
 'UV_near':'UV_M50_L12_fpi_calibrated_eps00021_near_warm/report.json'}
c=json.loads((ROOT/'report.json').read_text());assert c['same_basis'] and c['paper_state_comparison_complete']
assert not c['paper_state_comparison_pass'] and not c['legacy_registered_chain_complete']
assert c['uv_role_mapping']=={'tip':'tip','ref':'ref','mid':'near'}
assert all(c[k]['verdict']=='FAIL' for k in ('C4','C6','C7'))
assert c['matched_objectives']=={'tip':False,'ref':True,'mid':False}
rows=[];inputs={};states={}
for state,rel in paths.items():
 p=RUN/rel;r=json.loads(p.read_text());assert r['accepted'] and r['verification']['primal_feasible']
 assert r['convergence']['solver_optimal'] and r['spec']['eps_chi']==.00021
 assert sha(p.parent/'out/y.txt')==r['y_sha256']
 inputs[rel]=sha(p);states[state]={'x':r['verification']['f00_3'],'y':r['verification']['f11_3'],'seconds':r['seconds'],'absolute_gap':r['convergence']['absolute_gap']}
 for wave in ('S0','S2','P1'):
  o=r['observables'][wave]
  for e,d,eta in zip(o['E_GeV'],o['delta_deg'],o['eta']):rows.append([state,wave,e,d,eta,'saved native observations',rel])
for wave,num in [('S0',10),('S2',10),('P1',9)]:
 for group,filename in [('UV',f'figure{num}_{wave.lower()}_phases.csv'),('IR',f'figure7_{wave.lower()}_phases.csv')]:
  p=REPO/'references'/filename;inputs['references/'+filename]=sha(p)
  for r in csv.DictReader(p.open()):rows.append(['paper_'+group+'_'+r['group'],wave,r['energy_gev'],r['phase_deg'],'','published phase; eta unavailable','references/'+filename])
with (ROOT/'phase_eta.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['state','wave','energy_GeV','delta_deg','eta','scope','source']);w.writerows(rows)
validation={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_cli_exit_code':0,
 'mode':c['comparison_mode'],'same_basis':True,'complete_selected_state_comparison':True,'physical_pass':False,
 'full_y_hash_verified_for_all_four_states':True,'phase_rebranching':False,'paper_eta_fabricated':False,
 'all_three_uv_roles_present':True,'source_identities':inputs,'state_scalars':states,
 'C4':c['C4'],'C6':c['C6'],'C7':c['C7'],'rho':c['rho'],
 'chronology':'UV near section plan and uv-select receipt existed before this real full contrast. Hash/time receipts preserve the declared ordering; they do not independently prove historical blindness.',
 'plots_visually_reviewed':['phases.png','inelasticity.png'],
 'csv_rows':len(rows),'csv_sha256':sha(ROOT/'phase_eta.csv'),
 'limitations':['M50/L12 is a paper appendix resolution, not nominal M50/L10.','New near replaces internal mid slot explicitly; legacy midpoint registration remains incomplete.','Only IR ref / UV ref have matching objective and section.','Finite native acceptance does not certify omitted waves or full density-space optimum.']}
(ROOT/'VALIDATION.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':True,'rows':len(rows),'states':states,'verdicts':{k:c[k]['verdict'] for k in ('C4','C6','C7')}}))
