"""Unified CLI and delivery glue controls; all amplitude/phase inputs synthetic."""
from pathlib import Path
from contextlib import ExitStack,redirect_stdout,redirect_stderr
from unittest.mock import patch
import ast,copy,hashlib,io,json,runpy,sys,tempfile
import numpy as np

ROOT=Path('/home/shiqiu/s-matrix-bootstrap')
OUT=ROOT/'results/runs/sdpb_mainline_20260912/uv_selection_validation_20260913/mask_guard_compatible'
producer=OUT/'control_producer.py'
tree=ast.parse(producer.read_text());nodes=[]
for node in tree.body:
    if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='run':break
    nodes.append(node)
fixture_ns={'__file__':str(producer)}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(producer),'exec'),fixture_ns)
fixture=fixture_ns['fixture'];write=fixture_ns['write'];sha=fixture_ns['sha'];XR=fixture_ns['XR']
from smatrix_bootstrap.sdp import uv_selection as U,delivery as D

checks=[];verify_calls=[];basis_calls=[];labels=[];savefig_calls=[]
def cli(args):
    output,error=io.StringIO(),io.StringIO()
    with patch.object(sys,'argv',['smatrix_bootstrap.run','sdp',*map(str,args)]),redirect_stdout(output),redirect_stderr(error):
        try:runpy.run_module('smatrix_bootstrap.run',run_name='__main__')
        except SystemExit as exc:return {'exit':exc.code,'stderr':error.getvalue(),'stdout':output.getvalue()}
        except Exception as exc:return {'exception':type(exc).__name__,'message':str(exc),'stderr':error.getvalue()}
    return {'exit':0,'stdout':output.getvalue(),'stderr':error.getvalue()}
def reject_cli(name,args,parser=True):
    result=cli(args)
    assert result.get('exit')==2 if parser else result.get('exception') in ('ValueError','FileNotFoundError'),(name,result)
    checks.append({'name':name,'passed':True,'result':{k:v for k,v in result.items() if k!='stdout'}})
def synthetic_observations(offset=0.):
    return {wave:{'E_GeV':[.3,.8,1.19],'delta_deg':[offset,offset+2,offset+3],
                  'eta':[.99,.99,.99],'crossing_90_GeV':None,'min_eta_below_1p2GeV':.99}
            for wave in ('S0','S2','P1')}
def add_observations(path,offset):
    r=json.loads(path.read_text());r['observables']=synthetic_observations(offset)
    r['spec']['tag']='SYNTHETIC CLI FIXTURE - NOT A SCIENTIFIC RESULT'
    r['synthetic_only']=True;r['synthetic_observables_not_from_solver']=True;write(path,r)
    return r
def ir_leaf(path,role,x):
    leaf=fixture(path,role,x,True);r=add_observations(leaf,0.)
    r['spec']['uv']=False;na=r['pmp']['n_a'];n=na+1
    np.save(path/'disk_mask.npy',np.ones(6,dtype=bool));r['pmp']['n_unitarity_disks']=6  # IR retains all native disks
    y=(path/'out/y.txt').read_text().splitlines()[1:][:na]
    (path/'out/y.txt').write_text(f'{na} 1\n'+'\n'.join(y)+'\n')
    a=np.array([float(v) for v in y]);basis=np.load(path/'basis.npy')
    np.savez(path/'solution.npz',y=a,a=a,c=basis@a)
    pmp=json.loads((path/'pmp.json').read_text());pmp['objective']=pmp['objective'][:n];pmp['normalization']=pmp['normalization'][:n]
    for b in pmp['PositiveMatrixWithPrefactorArray']:b['polynomials'][0][0]=b['polynomials'][0][0][:n]
    write(path/'pmp.json',pmp);r['pmp'].update(n_vars=n,sha256=sha(path/'pmp.json'))
    r.update(y_sha256=sha(path/'out/y.txt'),solution_sha256=sha(path/'solution.npz'));write(leaf,r)
    return r
def forbidden(*args,**kwargs):raise AssertionError('Solver, full assembly or dual path invoked')

with tempfile.TemporaryDirectory(prefix='uv-cli-synthetic-') as tmp:
    root=Path(tmp)
    negative=[('uv-plan missing out',['uv-plan']),('uv-plan missing source',['uv-plan','--out',root/'x']),
       ('uv-select missing source',['uv-select','--out',root/'x']),
       ('uv-select missing both role leaves',['uv-select','--out',root/'x','--source-report','plan']),
       ('uv-select missing near',['uv-select','--out',root/'x','--source-report','plan','--ref-report','ref']),
       ('uv-select missing ref',['uv-select','--out',root/'x','--source-report','plan','--near-report','near']),
       ('ref-report rejected outside uv-select',['uv-plan','--out',root/'x','--source-report','tip','--ref-report','ref']),
       ('near-report rejected outside uv-select',['contrast','--out',root/'x','--ir-report','ir','--uv-report','uv','--near-report','near']),
       ('contrast missing IR',['contrast','--out',root/'x','--uv-report','receipt']),
       ('contrast missing UV',['contrast','--out',root/'x','--ir-report','ir'])]
    for name,args in negative:reject_cli(name,args)
    for command in ('uv-plan','uv-select'):
        for flag,value in [('--bits','384'),('--precision','320'),('--digits','30'),('--operator-dps','40'),('--source-snapshot','snapshot.gz')]:
            reject_cli(command+' rejects '+flag,[command,'--out',root/'x','--source-report','source',flag+'='+value])
    with ExitStack() as stack:
        for target in ('smatrix_bootstrap.sdp.sdpb.run_once','smatrix_bootstrap.sdp.sdpb.execute',
                       'smatrix_bootstrap.sdp.pmp.Pmp.__init__','smatrix_bootstrap.sdp.pmp.Pmp.write',
                       'smatrix_bootstrap.sdp.assembly.Operators.__new__','smatrix_bootstrap.sdp.dual.replay_dual'):
            stack.enter_context(patch(target,side_effect=forbidden))
        tip=fixture(root/'tip',x=.606,nonzero_plane=True);add_observations(tip,10.)
        result=cli(['uv-plan','--source-report',tip,'--out',root/'plan']);assert result['exit']==0,result
        plan=root/'plan/report.json';p=json.loads(plan.read_text());xn=p['plan']['x_near']
        ref=fixture(root/'ref','ref',XR,True);add_observations(ref,20.)
        near=fixture(root/'near','near',xn,True);add_observations(near,37.)
        result=cli(['uv-select','--source-report',plan,'--ref-report',ref,'--near-report',near,'--out',root/'receipt']);assert result['exit']==0,result
        receipt=root/'receipt/report.json';summary=json.loads(result['stdout'])
        assert summary['role_mapping']=={'tip':'tip','ref':'ref','mid':'near'} and summary['legacy_registered_chain_complete'] is False
        checks.append({'name':'unified uv-plan and uv-select run real APIs on M2 two-column fixture','passed':True,'summary':summary})
        # A wrong nearby basis at receipt root would be selected by the old incorrect path.
        np.save(receipt.parent/'basis.npy',np.zeros((1,1)))
        irroot=root/'ir_chain';irroot.mkdir()
        ir={'tip':ir_leaf(irroot/'tip','tip',.606),'ref':ir_leaf(irroot/'ref','ref',XR),
            'mid':ir_leaf(irroot/'mid','mid',(.606+XR)/2)}
        irpath=irroot/'aggregate.json';write(irpath,{'reports':ir,'synthetic_only':True})
        real_verify=U.verify_uv_selection;real_basis=D.basis_identity
        def tracked_verify(path):
            verify_calls.append({'receipt':str(path),'completed':False})
            result=real_verify(path);verify_calls[-1].update(completed=True,source_paths=result['source_paths'],role_mapping=result['role_mapping'])
            return result
        def tracked_basis(record,path,point=None):
            result=real_basis(record,path,point);basis_calls.append({'uv':record['spec']['uv'],'path_argument':str(Path(path).resolve()),
                'point_argument':point,'verified':result['verified'],'actual_basis_path':result.get('path')});return result
        import matplotlib;matplotlib.use('Agg')
        from matplotlib.axes import Axes
        from matplotlib.figure import Figure
        real_plot=Axes.plot
        def tracked_plot(self,*args,**kwargs):
            if kwargs.get('label'):labels.append(kwargs['label'])
            return real_plot(self,*args,**kwargs)
        def no_save(self,path,*a,**kw):savefig_calls.append(str(path))
        with patch.object(U,'verify_uv_selection',side_effect=tracked_verify),patch.object(D,'basis_identity',side_effect=tracked_basis),\
             patch.object(Axes,'plot',tracked_plot),patch.object(Figure,'savefig',no_save):
            result=cli(['contrast','--ir-report',irpath,'--uv-report',receipt,'--out',root/'contrast'])
            assert result.get('exit')==0,result
            output=json.loads((root/'contrast/report.json').read_text())
            assert len(verify_calls)==1 and verify_calls[0]['completed']
            expected=verify_calls[0]['source_paths'];uv_calls=[c for c in basis_calls if c['uv']]
            assert len(uv_calls)==3 and {c['path_argument'] for c in uv_calls}==set(expected.values())
            assert all(c['point_argument'] is None and c['verified'] for c in uv_calls)
            assert expected['mid']==str(near.resolve())
            assert output['basis_identity']['UV']['mid']['path']==str((near.parent/'basis.npy').resolve())
            assert output['same_basis'] and not output['legacy_registered_chain_complete'] and output['incomplete_registered_chain']
            assert output['comparison_mode']=='paper-nearby-uv'
            assert output['uv_role_mapping']['mid']=='near' and output['uv_selection']['revalidated']
            assert 'UV near' in labels and 'UV mid' not in labels
            assert output['matched_objectives']['mid'] is False and output['main_contrast_pass'] is False
            assert output['C6']['role_mapping']['mid']=='near' and output['C7']['role_mapping']['mid']=='near'
            checks.append({'name':'contrast actual receipt verifier, source_paths, basis identity, plot labels and chain flags','passed':True,
                'observed_UV_labels':sorted(set(v for v in labels if v.startswith('UV '))),
                'comparison_mode':output['comparison_mode'],'legacy_registered_chain_complete':output['legacy_registered_chain_complete'],
                'incomplete_registered_chain':output['incomplete_registered_chain'],'matched_mid_objective':output['matched_objectives']['mid']})
            good=receipt.read_bytes();doc=json.loads(good);doc['selection']['role_mapping']['mid']='mid';write(receipt,doc)
            prior_basis,prior_plots=len(basis_calls),len(labels)
            reject_cli('contrast refuses tampered role mapping through real verifier',
                ['contrast','--ir-report',irpath,'--uv-report',receipt,'--out',root/'bad_receipt'],False)
            assert len(verify_calls)==2 and verify_calls[-1]['completed'] is False
            assert len(basis_calls)==prior_basis and len(labels)==prior_plots and not (root/'bad_receipt').exists()
            receipt.write_bytes(good)
            reject_cli('nearby receipt incompatible with reference-only mode',
                ['contrast','--ir-report',irroot/'ref/report.json','--uv-report',receipt,'--reference-only','--out',root/'refonly'],False)
            # This branch probe mocks only IR receipt authentication. UV receipt
            # verification, IR leaf validation, basis loading and plotting stay real.
            from smatrix_bootstrap.sdp import ir_selection as IS
            ir_receipt=root/'synthetic_ir_receipt.json';write(ir_receipt,{'synthetic_only':True})
            synthetic_selection={'selection':{'selected':'upper','endpoints':{'upper':{'direction':[0.,1.]}},
                'rule':'SYNTHETIC branch probe; IR receipt authentication is mocked'},'receipt_sha256':sha(ir_receipt)}
            with patch.object(IS,'verify_ir_selection',return_value=synthetic_selection) as ir_mock:
                selected=cli(['contrast','--ir-report',irroot/'ref/report.json','--uv-report',receipt,
                    '--ir-selection-report',ir_receipt,'--out',root/'selected_ir_contrast'])
                assert selected.get('exit')==0,selected
                assert ir_mock.call_count==1 and len(verify_calls)==3 and verify_calls[-1]['completed']
            selected=json.loads((root/'selected_ir_contrast/report.json').read_text())
            assert selected['comparison_mode']=='paper-nearby-uv-selected-ir'
            assert selected['legacy_registered_chain_complete'] is False and selected['incomplete_registered_chain'] is True
            assert selected['uv_role_mapping']['mid']=='near' and selected['same_basis']
            assert selected['main_contrast_pass'] is False and 'IR selected upper' in labels
            checks.append({'name':'selected-IR plus nearby-UV CLI branch with only IR receipt authentication mocked',
                'passed':True,'real_uv_verification':True,'comparison_mode':selected['comparison_mode'],
                'scope':'branch glue only; not validation of a real IR selection receipt'})
        oldmid=fixture(root/'old_mid','near',(.606+XR)/2,True);add_observations(oldmid,99.)
        reject_cli('CLI uv-select refuses legacy arithmetic midpoint relabelled near',
            ['uv-select','--source-report',plan,'--ref-report',ref,'--near-report',oldmid,'--out',root/'old_mid_selection'],False)
        reject_cli('CLI uv-select refuses duplicate ref as near',
            ['uv-select','--source-report',plan,'--ref-report',ref,'--near-report',ref,'--out',root/'duplicate'],False)
        checks.append({'name':'solver/full assembly/PMP writes/dual traps never triggered','passed':True})

base=json.loads((OUT/'CLI_BASE_36_REPLAY.json').read_text())
assert base['passed'] and len(base['controls'])==36
result={'passed':all(r['passed'] for r in checks),'synthetic_only':True,'scientific_reports_read':False,'scientific_solves':0,
 'existing_36_controls_replayed':{'passed':base['passed'],'sha256':sha(OUT/'CLI_BASE_36_REPLAY.json')},
 'CLI_delivery_checks':checks,'receipt_verifier_calls':verify_calls,'delivery_basis_calls':basis_calls,
 'plot_labels_observed':sorted(set(labels)),'suppressed_figure_save_paths':savefig_calls,
 'monkeypatch_boundary':{'actual':['unified run.py SDP route','argparse','plan_uv/select_uv','verify_uv_selection','PMP/basis/y validation',
            'delivery contract and flags','basis_identity','Axes.plot with near labels'],
     'test_only':['synthetic acceptance flags and fabricated observations in original fixture style','observation-only wrappers around verifier and basis_identity',
            'Figure.savefig suppressed; no synthetic plot files published','solver/full assembly/PMP-write/dual methods replaced only by raising traps',
            'verify_ir_selection mocked only in one selected-IR branch probe; verify_uv_selection always executed its real implementation']},
 'scope':'CLI/receipt/delivery engineering control, not a complete real three-UV chain, physical comparison, or calibrated IR phase inspection',
 'source_sha256':{name:sha(ROOT/'src/smatrix_bootstrap/sdp'/name) for name in ('__main__.py','uv_selection.py','delivery.py','assembly.py')},
 'producer_sha256':sha(Path(__file__))}
(OUT/'CLI_DELIVERY_VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'CLI_DELIVERY_PRODUCER.txt').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'passed':result['passed'],'new_checks':len(checks),'base_controls':36,'scope':result['scope']},indent=2))
