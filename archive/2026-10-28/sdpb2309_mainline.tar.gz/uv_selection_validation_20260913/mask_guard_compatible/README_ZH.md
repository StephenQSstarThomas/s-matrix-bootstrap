# 有效mask guard下的合成控制兼容性

在 `precision_pmp.py` SHA256 `725ace3308e473fc26e0d94316a90554dfdce042d40d06532ac9fe4cda8d316f` 下，原36项API控制与28项CLI/delivery控制均已重跑通过。

原M2/L1合成UV fixture把6个盘都写成true，不符合实际构造器在存在Gram时替代S0/P1直接散射盘的规则。新fixture按原生顺序设置 `[false,false,false,false,true,true]`，并记录 `n_unitarity_disks=2`。CLI控制把同类fixture转换成IR时，则恢复6个true并记录计数6。basis、PMP系数、目标与原有检查逻辑没有改变；CLI producer另外只把输出目录改到本子目录，避免覆盖历史结果。

`RED_OLD_FIXTURE.json`记录原全true合成UV fixture在新代码下的真实拒绝：`Source disk mask content differs from the ModelSpec effective mask`。随后使用修正输入，36项API检查和28项CLI/delivery检查全部通过，没有发现其它不能由旧fixture错误解释的失败。

`FIXTURE_ONLY_CHANGES.diff`列出完整差异。父目录的原producer和结果保持原字节，前后哈希在 `ORIGINAL_EVIDENCE_SHA256.json` 与 `FINAL_VALIDATION.json` 中核对一致。

本次没有修改核心代码、三个活动测试文件或实际科学输入，没有启动solver、读取live UV相位或生成实际三UV链。此前CLI控制的模拟边界保持不变：UV receipt验证真实执行，只有一个selected-IR分支模拟IR receipt认证，图文件写出被抑制；这些仍是工程控制，不是物理验收。
