"""Independent small normalized PMP fixtures; synthetic acceptance, no scientific solve."""
from dataclasses import asdict
from fractions import Fraction
import hashlib
import importlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import numpy as np
from smatrix_bootstrap.sdp.spec import ModelSpec
from smatrix_bootstrap.sdp.assembly import BASIS_PACKING
from smatrix_bootstrap.sdp.constraints import chiral_reference_point

HERE=Path(__file__).resolve().parent
SRC=Path(importlib.import_module('smatrix_bootstrap.sdp.pmp').__file__).parent
XR=chiral_reference_point()[0]
RESULT=[]


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')
def module():
    assert (SRC/'uv_selection.py').exists(),'UV selection API is not implemented'
    return importlib.import_module('smatrix_bootstrap.sdp.uv_selection')
def block(vector):
    return {'DampedRational':{'base':'1','constant':'1','poles':[]},
            'polynomials':[[[[str(v)] for v in vector]]]}


def fixture(root,role='tip',x=.606,nonzero_plane=False):
    """Constant A=a independently implies f00=5a/2 and f11=0 at s=3."""
    root.mkdir();(root/'out').mkdir();M=2;na=2 if nonzero_plane else 1;n=1+na+8
    spec=asdict(ModelSpec(M=M,L=1,chiral=True,uv=True,chi_caliber='chi-c',
                         sr_caliber='SR-a',ff_frozen_at_s0=False,reduce_basis=True,
                         operator_dps=40,scattering_prescription='sine-cardinal'))
    basis=np.zeros((12,na));basis[0,0]=1.
    if nonzero_plane:basis[1,1]=1.
    np.save(root/'basis.npy',basis)
    np.save(root/'disk_mask.npy',np.ones(6,dtype=bool))
    y=[str(float(Fraction(str(x))*Fraction(2,5)))]+['0']*(n-2)
    (root/'out/y.txt').write_text(f'{n-1} 1\n'+'\n'.join(y)+'\n')
    rounded=np.array([float(v) for v in y]);c=basis@rounded[:na]
    np.savez(root/'solution.npz',y=rounded,a=rounded[:na],c=c,
             ImF=rounded[na:na+4].reshape(2,2),rho_hat=rounded[na+4:].reshape(2,2))
    write(root/'sdpb_process.json',{'returncode':0,'terminal':True})
    norm=['1']+['0']*(n-1);fx=['0','2.5']+['0']*(n-2);fy=['0']*n
    if nonzero_plane:
        import mpmath as mp
        with mp.workdps(80):
            def g(s):
                z=(2-mp.sqrt(4-s))/(2+mp.sqrt(4-s))
                return mp.sqrt(2)/2*(z+1)+(z*z-1)/2
            fx[2]=mp.nstr(mp.quad(lambda mu:3*g(3)+g((1-mu)/2)+g((1+mu)/2),[-1,1])/4,30)
            fy[2]=mp.nstr(mp.quad(lambda mu:mu*(g((1-mu)/2)-g((1+mu)/2)),[-1,1])/4,30)
            assert abs(mp.mpf(fy[2]))>mp.mpf('.001')
    blocks=[block(['2']+['0']*(n-1)),block(['3']+['0']*(n-1))]
    fixed=None if role=='tip' else x
    if fixed is not None:
        row=[Fraction(str(fixed))]+[-Fraction(v) for v in fx[1:]]
        blocks += [block(row),block([-v for v in row])]
    write(root/'pmp.json',{'objective':fx if role=='tip' else fy,'normalization':norm,
                         'PositiveMatrixWithPrefactorArray':blocks})
    value=x if role=='tip' else 0.;reason='found primal-dual optimal solution'
    rec={'spec':spec,'solver':'SDPB','status':'numerically_accepted','accepted':True,
         'direction':[1.,0.] if role=='tip' else [0.,1.],'fix_f00':fixed,
         'sdpb':{'returncode':0},'sdpb_result':{'terminateReason':reason},
         'pmp':{'sha256':sha(root/'pmp.json'),'n_a':na,'n_vars':n,'n_blocks':len(blocks),
                'reduce_basis':True,'digits':30,'operator_precision':{'scattering_prescription':'sine-cardinal'}},
         'basis':{'sha256':sha(root/'basis.npy'),'packing':BASIS_PACKING},
         'source_sha256':{'src/smatrix_bootstrap/sdp/'+p.name:sha(p) for p in SRC.glob('*.py')},
         'y_sha256':sha(root/'out/y.txt'),'solution_sha256':sha(root/'solution.npz'),
         'convergence':{'solver_optimal':True,'candidate_lower':value,'candidate_upper':value+1e-8,
                        'absolute_gap':1e-8,'objective_readback_error':0.,'terminate_reason':reason},
         'verification':{'primal_feasible':True,'f00_3':x,'f11_3':0.,'objective_recomputed':value,
                         'source_audit':{'scattering_prescription':'sine-cardinal'},
                         'constraint_checks':{k:True for k in ['unitarity','chiral','section','rho_nonnegative','gram','fesr','ff']}}}
    write(root/'report.json',rec);return root/'report.json'


def edit(path,fn):
    r=json.loads(path.read_text());fn(r);write(path,r)


def program_edit(path,fn):
    p=path.parent/'pmp.json';d=json.loads(p.read_text());fn(d);write(p,d)
    edit(path,lambda r:r['pmp'].update(sha256=sha(p)))


def reject(call):
    try:call()
    except (ValueError,FileExistsError):return
    raise AssertionError('Malformed input was accepted')


def chain(root,tip_x=.606,nonzero_plane=False):
    u=module();tip=fixture(root/'tip',x=tip_x,nonzero_plane=nonzero_plane);u.plan_uv(tip,root/'plan')
    near=float(Fraction(str(XR))+min(Fraction(str(XR))/100,(Fraction(str(tip_x))-Fraction(str(XR)))/2))
    ref=fixture(root/'ref','ref',XR,nonzero_plane);nbr=fixture(root/'near','near',near,nonzero_plane)
    return u,tip,ref,nbr,root/'plan/report.json'


def run(name,fn):
    try:
        with tempfile.TemporaryDirectory(dir=HERE,prefix='synthetic_') as tmp:fn(Path(tmp))
        RESULT.append({'name':name,'passed':True})
    except Exception as exc:RESULT.append({'name':name,'passed':False,'error':type(exc).__name__+': '+str(exc)})


def positive(root,tip_x=.606):
    u,tip,ref,near,plan=chain(root,tip_x)
    receipt=u.select_uv(plan,ref,near,root/'selection')
    checked=u.verify_uv_selection(root/'selection/report.json')
    assert set(checked['reports'])=={'tip','ref','mid'}
    assert checked['role_mapping']=={'tip':'tip','ref':'ref','mid':'near'}
    assert checked['reports']['mid']['fix_f00']==json.loads(near.read_text())['fix_f00']
    assert checked['metadata']['legacy_registered_chain_complete'] is False
    assert checked['metadata']['two_dimensional_radius'] is None
    return checked


run('three accepted sources, exact constant-amplitude plane and explicit near alias',positive)
run('narrow tip uses half remaining interval, not fixed 1percent or rejection',lambda root:positive(root,XR+.0004))
def nonzero(root):
    u,tip,ref,near,plan=chain(root,nonzero_plane=True)
    u.select_uv(plan,ref,near,root/'selection')
    assert u.verify_uv_selection(root/'selection/report.json')['metadata']['revalidated']
run('independent original-mu M2 scalar/P1 plane with nonzero P1 coefficient',nonzero)
def observations(root):
    u,tip,ref,near,plan=chain(root)
    for p in (ref,near):edit(p,lambda r:r.update(observables={'arbitrary':'unused'},subthreshold={'arbitrary':'unused'}))
    u.select_uv(plan,ref,near,root/'selection')
    checked=u.verify_uv_selection(root/'selection/report.json')
    assert checked['metadata']['phase_data_used'] is False
run('arbitrary phase and linearity fields are not selection inputs',observations)

def relocation(root):
    bundle=root/'bundle';bundle.mkdir();positive(bundle)
    moved=root/'moved';shutil.move(bundle,moved)
    assert module().verify_uv_selection(moved/'selection/report.json')['metadata']['revalidated']
run('complete relative-source bundle relocates',relocation)

def pcase(root,fn):
    u,tip,ref,near,plan=chain(root);fn(near)
    reject(lambda:u.select_uv(plan,ref,near,root/'selection'))

for name,fn in [
 ('wrong full spec',lambda p:edit(p,lambda r:r['spec'].update(eps_chi=.004))),
 ('wrong role direction',lambda p:edit(p,lambda r:r.update(direction=[0.,-1.]))),
 ('wrong fixed section',lambda p:edit(p,lambda r:r.update(fix_f00=XR))),
 ('nonaccepted',lambda p:edit(p,lambda r:r.update(accepted=False))),
 ('missing y solve-time hash',lambda p:edit(p,lambda r:r.pop('y_sha256'))),
 ('sub-binary64 y tamper',lambda p:(p.parent/'out/y.txt').write_text((p.parent/'out/y.txt').read_text().replace('\n0\n','\n1e-90\n',1))),
 ('bad y header',lambda p:(p.parent/'out/y.txt').write_text('9 2\n'+'0\n'*9)),
 ('pending process',lambda p:write(p.parent/'sdpb_process.json',{'terminal':False,'returncode':0})),
 ('nonzero solver status',lambda p:edit(p,lambda r:r['sdpb'].update(returncode=1))),
 ('missing Gram acceptance',lambda p:edit(p,lambda r:r['verification']['constraint_checks'].update(gram=False))),
 ('wrong actual basis',lambda p:np.save(p.parent/'basis.npy',np.zeros((12,1)))),
 ('wrong PMP hash',lambda p:(p.parent/'pmp.json').write_text((p.parent/'pmp.json').read_text()+' ')),
 ('different base block despite refreshed hash',lambda p:program_edit(p,lambda d:d['PositiveMatrixWithPrefactorArray'][0]['polynomials'][0][0][0].__setitem__(0,'4'))),
 ('wrong normalization despite refreshed hash',lambda p:program_edit(p,lambda d:d['normalization'].__setitem__(0,'2'))),
 ('wrong actual P1 objective despite refreshed hash',lambda p:program_edit(p,lambda d:d['objective'].__setitem__(2,'1'))),
 ('forged section pair with wrong x row',lambda p:program_edit(p,lambda d:(d['PositiveMatrixWithPrefactorArray'][-2]['polynomials'][0][0][1].__setitem__(0,'-3'),d['PositiveMatrixWithPrefactorArray'][-1]['polynomials'][0][0][1].__setitem__(0,'3')))),
 ('nontrivial section prefactor',lambda p:program_edit(p,lambda d:d['PositiveMatrixWithPrefactorArray'][-1]['DampedRational'].update(base='2'))),
 ('legacy far midpoint relabelled near',lambda p:edit(p,lambda r:r.update(fix_f00=(XR+.606)/2))),
]:run(name,lambda root,fn=fn:pcase(root,fn))

def plan_reject(root,kind):
    u=module();tip=fixture(root/'tip',x=.606)
    if kind=='not right of xref':edit(tip,lambda r:r['verification'].update(f00_3=XR))
    elif kind=='sectioned tip':edit(tip,lambda r:r.update(fix_f00=XR))
    elif kind=='wrong actual tip objective':program_edit(tip,lambda d:d['objective'].__setitem__(1,'3'))
    elif kind=='unknown spec field':edit(tip,lambda r:r['spec'].update(hidden_input=1))
    elif kind=='source kernel hash':edit(tip,lambda r:r['source_sha256'].update({'src/smatrix_bootstrap/sdp/sine.py':'0'*64}))
    reject(lambda:u.plan_uv(tip,root/'plan'))
for kind in ['not right of xref','sectioned tip','wrong actual tip objective','unknown spec field','source kernel hash']:
    run(kind,lambda root,kind=kind:plan_reject(root,kind))

def tamper(root,which):
    u,tip,ref,near,plan=chain(root);u.select_uv(plan,ref,near,root/'selection')
    target=plan if which=='plan' else root/'selection/report.json'
    d=json.loads(target.read_text());d['tampered']=True;write(target,d)
    reject(lambda:u.verify_uv_selection(root/'selection/report.json'))
run('plan byte tampering rejected on receipt verification',lambda root:tamper(root,'plan'))
run('receipt unexpected field rejected',lambda root:tamper(root,'receipt'))
def producer_tamper(root,which):
    u,tip,ref,near,plan=chain(root);u.select_uv(plan,ref,near,root/'selection')
    target=plan if which=='plan' else root/'selection/report.json'
    edit(target,lambda r:r.update(producer_sha256='0'*64))
    reject(lambda:u.select_uv(plan,ref,near,root/'new_selection') if which=='plan' else u.verify_uv_selection(target))
run('forged plan producer identity rejected',lambda root:producer_tamper(root,'plan'))
run('forged receipt producer identity rejected',lambda root:producer_tamper(root,'receipt'))
def coherent_basis(root):
    u,tip,ref,near,plan=chain(root);basis=np.load(near.parent/'basis.npy');basis[0,0]=2
    np.save(near.parent/'basis.npy',basis)
    edit(near,lambda r:r['basis'].update(sha256=sha(near.parent/'basis.npy')))
    reject(lambda:u.select_uv(plan,ref,near,root/'selection'))
run('different actual finite basis with its refreshed recorded hash rejected',coherent_basis)
def duplicate(root):
    u,tip,ref,near,plan=chain(root);reject(lambda:u.select_uv(plan,ref,ref,root/'selection'))
run('missing near replaced with duplicate ref rejected',duplicate)
def existing(root):
    u=module();tip=fixture(root/'tip');(root/'plan').mkdir();(root/'plan/keep').write_text('preserve')
    reject(lambda:u.plan_uv(tip,root/'plan'));assert (root/'plan/keep').read_text()=='preserve'
run('existing output preserved',existing)
def no_solver(root):
    from unittest.mock import patch
    from contextlib import ExitStack
    def forbidden(*args,**kwargs):raise AssertionError('Solver/assembly operation called')
    with ExitStack() as stack:
        for target in ('smatrix_bootstrap.sdp.sdpb.run_once','smatrix_bootstrap.sdp.sdpb.execute',
                       'smatrix_bootstrap.sdp.pmp.Pmp.__init__','smatrix_bootstrap.sdp.pmp.Pmp.write',
                       'smatrix_bootstrap.sdp.assembly.Operators.__new__','smatrix_bootstrap.sdp.dual.replay_dual'):
            stack.enter_context(patch(target,side_effect=forbidden))
        positive(root)
run('solver, full assembly, PMP writes and dual replay are never called',no_solver)

out={'synthetic_only':True,'scientific_solves':0,'real_scientific_reports_read':False,
     'passed':all(row['passed'] for row in RESULT),'controls':RESULT,'producer_sha256':sha(__file__)}
target=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'validation.json';write(target,out)
print(json.dumps({'passed':out['passed'],'controls':len(RESULT),'failed':[r for r in RESULT if not r['passed']]},indent=2))
raise SystemExit(0 if out['passed'] else 1)
