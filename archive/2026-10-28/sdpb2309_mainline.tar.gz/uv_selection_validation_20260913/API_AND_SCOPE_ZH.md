# UV 邻点计划与收据：API、控制及交付范围

仅新增 `src/smatrix_bootstrap/sdp/uv_selection.py`。原求解接口、三代表旧规则、源核与活动测试文件均未改；CLI 与 delivery 由主线程独立合并。

最终规则为 `x_near=x_ref+min(0.01*x_ref,(x_tip-x_ref)/2)`。tip 必须完成接受、无截面、方向 `[1,0]` 且 x_tip>x_ref；ref/near 均沿 `[0,1]` 最大化 f11。1% 是横坐标偏移上限，不是物理误差或作者精确坐标。只报告到理论黑点的二维欧氏距离和距离/x_ref，不施加二维半径门槛。若 binary64 无法表示严格介于 x_ref 与 x_tip 的新点，明确拒绝。

## 公共 API

- `plan_uv(tip_report, outdir)`：创建全新 `outdir/report.json`，schema=`uv-nearby-plan-v1`。冻结实际 ref/near 文本、精确有理数规则结果、完整 spec、tip 文件身份、两条真实投影行及产生时间；不使用相位或阈下曲线。
- `select_uv(plan_report, ref_report, near_report, outdir)`：重新验证计划与三个完成叶，写 schema=`uv-nearby-selection-v1` 收据。支持计算仍使用已有 `sdp support --source-report TIP --direction 0 1 --fix-f00 X --out FRESH`。
- `verify_uv_selection(receipt)`：重算所有身份与数值几何并返回 `reports`、`source_paths`、`role_mapping`、`metadata`。前两项内部键为 `tip/ref/mid`；显式 `role_mapping={tip:tip,ref:ref,mid:near}`，真实收据 `points` 仍用 `tip/ref/near`，图例必须显示 near。元数据包含 `legacy_registered_chain_complete=False`、`two_dimensional_radius=None`、`phase_data_used=False`、`revalidated=True`。

主线程拟合并的统一 CLI 为 `uv-plan --source-report TIP --out FRESH`，以及 `uv-select --source-report PLAN --ref-report REF --near-report NEAR --out FRESH`。`contrast --uv-report RECEIPT` 可按 schema 自动识别，不需要再增加一项选择参数。逐叶 basis 检查应使用返回的 `source_paths`；旧登记是否完成与新纸样三状态是否齐全必须分开。

## 实际验证内容

完整 y 的求解时 SHA、行列头、有限十进制值及 NPZ 拷贝；PMP/basis/终态过程文件；全部 UV 与源式接受；完整 ModelSpec 与实际基底身份均核验。只以 `Pmp.from_saved` 重建 f00(3)、f11(3) 两条投影行，不重新 SVD、装配约束或写 PMP。实际目标必须逐项等于相应投影行。ref/near 的最后两条标量块必须有正确常数、正确 f00 系数、相反符号和单位 prefactor，确认后才从物理块哈希中移除。其余全部物理块、normalization、实际 mask 与 tip 相同；完整 y 读回的投影与记录一致。

计划和收据的来源路径为相对路径，验证后才返回供绘图使用的完整 reports；选择计算不引用其中的观测数组。求解时缺少 y 哈希的历史叶明确拒绝，不为此自动重求。模块 producer SHA 严格绑定：若今后修改本模块，应保存旧计划/收据后重新生成，不能直接给旧文件换哈希。产生时间与哈希不自行证明完全盲预登记；已有输出知情范围和计划先于新支持的执行日志仍应诚实保留。

## 红/绿与独立控制

`RED.json` 在新模块不存在时记录 31 项预先编写控制的预期失败。首轮实现通过全部控制；随后对伪造 producer 身份加入负例，`RED_PRODUCER_GUARD.json` 实际重现两个漏拒绝，修复后全部 36 项通过。测试未加入三个接近行数上限的活动文件；原字节、独立 producer 和阶段 JSON 均在本目录。

合成矩阵按独立恒等式 A=a ⇒ f00=5a/2、f11=0 构造；另以 80 位 mpmath 直接对 M2 的显式 g(z) 做原始 μ 积分，产生非零 P1 目标系数，验证真实投影行身份。合成 `accepted` 元数据只是接口前提，不宣称这些玩具矩阵经过物理求解。控制覆盖宽 tip/窄 tip、错 spec、真实 basis 及刷新哈希后的替换、PMP 物理块/normalization/目标/截面/prefactor 篡改、完整 y 尾数、缺项/重复/非终态叶、旧 midpoint 改名、相对搬移与观测字段无关性。运行时 trap 证实没有调用 solver、完整 assembly、PMP 写出或 dual replay。

唯一实物控制是已获准完成的 `UV_M50_L10_source_tip_20260913/tip/report.json`：计划生成耗时 **21.60 秒**，x_tip=0.6061065133883778、x_near=0.07405460447866398，完整文件身份与真实两条目标行吻合。结果在 `ACTUAL_NOMINAL_TIP_PLAN/report.json` 和 `ACTUAL_PLAN_VALIDATION.json`。它只验证该已完成 tip 的计划 API，没有计算新 ref/near，没有读取当前 χ=.00021 两端的相位或阈下曲线。

模块最终原字节与 SHA、36 项终态及实物控制汇总见 `FINAL_VALIDATION.json`。完整三点 receipt 的科学实物执行仍由后续已冻结计划和主线程控制，当前合成通过不冒充那条物理链完成。
