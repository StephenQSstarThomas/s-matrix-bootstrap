# 自包含 SDPB + Mathematica 执行

入口：`python -m smatrix_bootstrap.run sdp`。`solve` 始终使用 SDPB；`selfcheck` 跑本路线自检；`mma-audit` 独立核验原文公式；`figures` 只消费完整验收的新 SDPB 点。`scripts/sdp/pmp_run.py` 是兼容包装，不再包含另一条求解链。旧的 MOSEK 脚本和报告只作为历史证据，不用于主线。

本机使用 `/home/shiqiu/miniconda3/bin/python`；新依赖入口是 `pip install -e '.[sdpb,test]'`。已安装环境还有历史测试的 CVXPY，但 `solve`/PMP/ModelSpec 不导入它，也不需要 MOSEK 许可证。基础数学依赖是 NumPy/SciPy；Mathematica 和 SDPB 通过已有容器运行器执行。

当前全 UV 命令：

```bash
OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4 \
/home/shiqiu/miniconda3/bin/python -m smatrix_bootstrap.run sdp solve \
  --workdir /playpen1/shiqiu/sdpb_mainline_20260912/UV_M50_L10_full \
  --M 50 --L 10 --chiral --chi chi-b --uv --uv-parts gram fesr ff \
  --sr SR-b --reduce-basis --nproc 8 --precision 192 \
  --duality-gap 1e-6 --timeout 7200
```

这条命令已经结束，1853秒，原式验收失败；不要在该目录重复启动。每次新计算必须使用新目录。`--timeout` 为各外部阶段的运行上限，SDPB 另带内部 maxRuntime 并保留退出解。每轮保留 PMP、basis、disk mask、y文本、完整振幅、日志、checkpoint、参数、源哈希和 report。PMP始终degree-0，无密度球；自包含驱动拒绝 `--B`。

Mathematica 默认先执行 `scripts/mma/audit_2309.wls`：以100位精度独立计算(2.33)、(2.56)、(3.60–61)、(3.67)，并精确验证(3.68)的Gram酉变换。它不加载2403 notebook、不提供拟合输入。Mathematica必须保持 `--network none` 与可写容器HOME，这是现有许可证的条件。SDPB容器必须保留网络命名空间与足够的shm，默认16g。

```bash
/home/shiqiu/miniconda3/bin/python -m smatrix_bootstrap.run sdp mma-audit \
  --M 50 --out /playpen1/自己的新目录
```

三代表选择：把单点命令加 `--points tip ref mid`。同一可行集先求+x tip，再于物理xref及(x_tip+xref)/2截面最大化f11。tip失败则停止，不从另一个口径借tip。选择规则在求解前写入selection_rule.json；相位是同一完整振幅的导出量。当前这一接口已实现，完整UV三代表尚未实际全部通过。

## MPI机器与进程的区别

handoff已实测单机n=8在吞吐/单步时间之间较合适；当前机器没有发现Slurm/PBS命令或已分配远程节点。默认一次科学计算，8 ranks。不能把本机100 ranks称为100 nodes，也不应超额订阅共享80核机器。

真实集群路径已经提供：在每个获准节点安装或加载同版本的 SDPB3.1.0及其兼容MPI模块；代码、PMP、结果目录须在各节点同一路径可见。native运行器读取 `SDPB_HOSTFILE`，调用MPI，而不把多个Docker本地进程误当跨节点。

```bash
# 模块名称依集群实际安装而定；先加载该集群的 SDPB 3.1.0/MPI 配套模块。
SDPB_NATIVE=1 SDPB_HOSTFILE=/已分配集群/hostfile \
python -m smatrix_bootstrap.run sdp solve --workdir /共享盘/新运行目录 \
  --M 50 --L 10 --chiral --uv --reduce-basis --nproc 800
```

例如100个已分配节点、每节点8 ranks时，总进程数是800；这只是接口示例，不是当前已获得的资源。单个此规模SDP强扩展到800 ranks是否有收益必须测量。论文不同方向/不同配置在物理上独立，大批量交付宜每节点一个独立目录/方向，每个问题仍遵循同样的输入与验收。未知远程主机不会被自动扫描或使用。

`pmp2sdp` 与 SDPB 的precision必须一致。不同MPI配置不能复用不兼容checkpoint；当前驱动要求新目录避免这种混用。工作目录中的 `*_process.json` 是定位提示，活性判断必须结合真实PID/容器状态；锁文件或旧report不能证明任务仍在运行。

## 验收标签

- `verification.primal_feasible`：全部原生原式约束在明确数值容差下通过。
- `convergence.solver_optimal`：SDPB最终最优终止、双侧residual/gap、目标回读一致。
- `accepted`：前两项均通过；用于数值有限模型结果与图表。
- `certified`/`independent_dual_certified`：严格证书尚未完成，保持false。

Mathematica核验通过和SDPB gap变小都不证明C6/C7，也不证明连续节点间幺正性。完整论文验收仍按PLAN_ZH.md全部范围推进。
