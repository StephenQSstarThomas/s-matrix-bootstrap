from pathlib import Path
from dataclasses import asdict
import json,hashlib,copy
import numpy as np
from flint import arb,acb
from smatrix_bootstrap.sdp.spec import ModelSpec
from smatrix_bootstrap.sdp.pmp import Pmp
from smatrix_bootstrap.sdp.accuracy import audit_saved_currents
from smatrix_bootstrap.sdp.grid import kappa,s_nodes
root=Path('/playpen1/shiqiu/sdpb_mainline_20260912/current_diagnostic_controls_v3');root.mkdir(exist_ok=False)
source=root/'synthetic_source';source.mkdir();(source/'out').mkdir()
s=ModelSpec(M=4,L=1,uv=True,operator_dps=40,scattering_prescription='sine-cardinal',reduce_basis=False)
w=Pmp(s,digits=30);meta=w.write(str(source/'pmp.json'));meta['sha256']=hashlib.sha256((source/'pmp.json').read_bytes()).hexdigest()
y=['0']*(w.n_vars-1);y[0]='0.01'
for i in range(w.n_a+2*s.M,w.n_vars-1):y[i]='3'
(source/'out/y.txt').write_text(f'{len(y)} 1\n'+'\n'.join(y)+'\n');sol=w.read_solution(source/'out/y.txt')
np.savez_compressed(source/'solution.npz',**{k:v for k,v in sol.items() if k!='y_text'})
report={'solver':'SDPB','status':'not_accepted','verification':{},'sdpb':{},'spec':asdict(s),'pmp':meta,'solution_sha256':hashlib.sha256((source/'solution.npz').read_bytes()).hexdigest(),'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/smatrix_bootstrap/sdp').glob('*.py')},'synthetic_fixture':True,'optimization_performed':False}
(source/'report.json').write_text(json.dumps(report))
r=audit_saved_currents(source/'report.json',root/'positive',error_target='1e-18')
for node in r['nodes']:
 i=node['node'];S=acb(arb(node['S']['real']['ball']),arb(node['S']['imag']['ball']))
 expected=acb(1,arb.pi()*(1-4/arb(node['s']['ball'])).sqrt()*arb('.025')) if node['wave']=='S0' else acb(1)
 assert float((S-expected).abs_upper())<1e-15
 assert arb(node['F']['real']['ball']).contains(arb(1))
 assert arb(node['rho_hat']['ball']).contains(arb(3))
assert r['uv_checks']['gram_counts']['certified_fail']>0
for moment in r['current_mechanism']['moment_saturation']:
 assert arb(moment['two_pion_fraction']['ball']).contains(arb(1)/3)
checks={'analytic_constant_amplitude_rows':len(r['nodes']),'expected_invalid_Gram_rejected':True,'seconds':r['seconds'],'optimization_performed':False}
for label in ['basis_layout','pmp_hash','y_header']:
 bad=copy.deepcopy(report)
 if label=='basis_layout':bad['pmp']['n_vars']+=1
 if label=='pmp_hash':bad['pmp']['sha256']='bad'
 if label=='y_header':
  yp=source/'out/y.txt';yp.write_text('1 1\n'+'\n'.join(y)+'\n')
 (source/'bad_report.json').write_text(json.dumps(bad))
 try:audit_saved_currents(source/'bad_report.json',root/label)
 except ValueError as e:checks[label]=str(e)
 else:raise AssertionError(label+' accepted')
(root/'validation.json').write_text(json.dumps(checks,indent=2));print(checks)
