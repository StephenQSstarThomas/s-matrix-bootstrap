"""Read-only cross-L row and exact-amplitude controls; no full assembly/solver."""
from fractions import Fraction as F
from dataclasses import asdict,replace
import hashlib
import json
from pathlib import Path
import time
import numpy as np
from flint import arb,ctx
from smatrix_bootstrap.sdp.sine import SineFamily
from smatrix_bootstrap.sdp.projector import Layout,ells_for
from smatrix_bootstrap.sdp.spec import ModelSpec
from smatrix_bootstrap.sdp.assembly import load_saved_basis,BASIS_PACKING

HERE=Path(__file__).resolve().parent
REPO=Path('/home/shiqiu/s-matrix-bootstrap')
SRC=REPO/'src/smatrix_bootstrap/sdp'
START=time.monotonic()


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(values):return hashlib.sha256(json.dumps(values,separators=(',',':')).encode()).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def af(x):return arb(str(x))
def ball_token(x):return str(x.mid().fmpq())+':'+str(x.rad().fmpq())


cases=[('S0_plane',0,0,{'point':3}),('P1_plane',1,1,{'point':3}),
       ('S0_node42',0,0,{'node':42}),('P1_node33',1,1,{'node':33}),
       ('S2_node42',2,0,{'node':42}),('P1_l19_node0',1,19,{'node':0}),
       ('P1_l23_node0',1,23,{'node':0})]
rows={};family_meta={}
for L in (8,10,12,13):
    family=SineFamily(50,L,40)
    family_meta[str(L)]={'density_dimension':family.lay.n,'geometry_bits':family.geometry_bits,
                         'source_dps':family.dps,'base_bits':family.bits}
    rows[L]={}
    for name,I,ell,where in cases:
        if ell not in ells_for(I,L):continue
        row=family.rows(I,ell,**where).ravel().tolist()
        rows[L][name]=row
        info={'L':L,'case':name,'working_bits':ctx.prec,'entries':len(row)}
        family_meta[str(L)].setdefault('cases',[]).append(info)

comparisons=[]
for low,high in ((8,10),(10,12),(12,13)):
    for name in rows[low].keys() & rows[high].keys():
        a,b=rows[low][name],rows[high][name]
        exact_a=[ball_token(v) for v in a];exact_b=[ball_token(v) for v in b]
        mids_a=[str(v.mid().fmpq()) for v in a];mids_b=[str(v.mid().fmpq()) for v in b]
        dec_a=[v.mid().str(30,radius=False) for v in a];dec_b=[v.mid().str(30,radius=False) for v in b]
        ctx.prec=800
        difference=[abs(x.mid()-y.mid()) for x,y in zip(a,b)]
        bad=[i for i,(x,y) in enumerate(zip(exact_a,exact_b)) if x!=y]
        comparisons.append({'L_pair':[low,high],'case':name,'entries':len(a),
            'raw_Arb_midpoint_radius_identical':exact_a==exact_b,
            'exact_midpoints_identical':mids_a==mids_b,
            'thirty_digit_midpoint_text_identical':dec_a==dec_b,
            'binary64_midpoint_bytes_identical':np.array([float(x.mid()) for x in a]).tobytes()==np.array([float(x.mid()) for x in b]).tobytes(),
            'all_intervals_overlap':all(x.overlaps(y) for x,y in zip(a,b)),
            'max_midpoint_absolute_difference':str(max(difference).upper().fmpq()),
            'different_raw_ball_count':len(bad),'raw_sha256':[digest(exact_a),digest(exact_b)],
            'midpoint_sha256':[digest(mids_a),digest(mids_b)],
            'first_raw_differences':[{'index':i,'left':a[i].str(40),'right':b[i].str(40)} for i in bad[:2]]})

# For M=3, DST samples v=(1,-1,1) and w=(1/2,1,1/2) give q3 and q1 exactly.
# The n=2 row is sqrt(3)/3*(1,0,-1); it annihilates every constructed density leg.
M=3;v=list(map(F,[1,-1,1]));w=[F(1,2),F(1),F(1,2)]
s1=[(2*a-b)/8 for a,b in zip(v,w)];s2=[(-a+3*b)/16 for a,b in zip(v,w)]
R=[[(2*v[i]*w[j]-3*w[i]*v[j]+v[i]*v[j])/32 for j in range(M)] for i in range(M)]
Q=[[(v[i]*w[j]+w[i]*v[j]+2*w[i]*w[j])/64 for j in range(M)] for i in range(M)]
c=[F(3,8)]+s1+s2+[x for row in R for x in row]+[Q[i][j] for i in range(M) for j in range(i,M)]
D=[[F(1,3),F(2,3),F(1,3)],[F(0)]*3,[F(1,3),-F(1,3),F(1,3)]]
triples=[(F(1),F(0),F(0)),(F(0),F(1,2),-F(1,3)),
         (-F(1,2),F(1,3),-F(1,4)),(F(1,4),-F(2,3),F(3,4))]


def expected(zs,zt,zu):
    a,b,d=[z**3+1 for z in (zs,zt,zu)];e,f,g=[z+1 for z in (zs,zt,zu)]
    return F(3,8)+(2*a-e)/8+(-b+3*f-d+3*g)/16+(2*a*(f+g)-3*e*(b+d)+a*(b+d))/32+(b*g+f*d+2*f*g)/64


def exact_from_unpacked(data,zs,zt,zu):
    q=lambda z:[z+1,z*z-1,z*z*z+1]
    sigma=lambda values:[sum(D[i][j]*values[j] for j in range(M)) for i in range(M)]
    matrix=lambda values:[[sum(D[i][k]*values[k][l]*D[j][l] for k in range(M) for l in range(M)) for j in range(M)] for i in range(M)]
    a,b=map(sigma,(data['sigma1'],data['sigma2']));r,t=map(matrix,(data['rho1'],data['rho2']))
    x,y,z=map(q,(zs,zt,zu))
    return data['T0']+sum(x[i]*a[i]+(y[i]+z[i])*b[i] for i in range(M))+sum(x[i]*r[i][j]*(y[j]+z[j])+y[i]*t[i][j]*z[j] for i in range(M) for j in range(M))


small=[]
for L in (8,10,12,13):
    family=SineFamily(M,L,40);layout=family.lay
    raw=layout.unpack(np.array([float(x) for x in c]));data={'T0':F(float(raw['T0']))}
    for key in ('sigma1','sigma2'):data[key]=[F(float(x)) for x in raw[key]]
    for key in ('rho1','rho2'):data[key]=[[F(float(x)) for x in row] for row in raw[key]]
    assert data['sigma1'][0]==data['sigma1'][2] and data['sigma2'][0]==data['sigma2'][2]
    for key in ('rho1','rho2'):
        assert data[key][0]==data[key][2]
        assert all(row[0]==row[2] for row in data[key])
    for zs,zt,zu in triples:
        reference=expected(zs,zt,zu);exact=exact_from_unpacked(data,zs,zt,zu)
        assert exact==reference
        ctx.prec=800;x,y,z=(family.cardinal(af(a)) for a in (zs,zt,zu))
        value=af(data['T0'])+sum((x[i]*af(data['sigma1'][i])+(y[i]+z[i])*af(data['sigma2'][i]) for i in range(M)),arb(0))
        value+=sum((x[i]*af(R[i][j])*(y[j]+z[j])+y[i]*af(Q[i][j])*z[j] for i in range(M) for j in range(M)),arb(0))
        assert value.contains(af(reference))
        small.append({'M':M,'L':L,'z_arguments':[str(x) for x in (zs,zt,zu)],
                      'reference':str(reference),'exact_difference':'0','production_encloses_exact':True})

# Current loader positive/rejection controls; fake source acceptance is explicit.
fixture=HERE/'synthetic_basis_source';fixture.mkdir(exist_ok=True)
basis=np.column_stack(([float(x) for x in c],[1.]+[0.]*(len(c)-1)))
np.save(fixture/'basis.npy',basis)
spec=ModelSpec(M=3,L=12,chiral=True,reduce_basis=True,operator_dps=40,scattering_prescription='sine-cardinal')
record={'solver':'SDPB','status':'numerically_accepted','accepted':True,'spec':asdict(spec),
        'verification':{'primal_feasible':True,'source_audit':{'scattering_prescription':'sine-cardinal'}},
        'convergence':{'solver_optimal':True},'pmp':{'n_a':2,'n_vars':3,'reduce_basis':True},
        'basis':{'sha256':sha(fixture/'basis.npy'),'packing':BASIS_PACKING},
        'source_sha256':{'src/smatrix_bootstrap/sdp/'+name:sha(SRC/name) for name in ('projector.py','grid.py')}}
write(fixture/'report.json',record)
loader=[]
for L in (8,10,12,13):
    try:
        got,meta=load_saved_basis(replace(spec,L=L),fixture/'report.json')
        assert L==12 and got.tobytes()==basis.tobytes() and meta['feasibility_transferred'] is False
        loader.append({'target_L':L,'accepted':True,'basis_bytes_identical':True,'feasibility_transferred':False})
    except ValueError as exc:
        assert L!=12 and 'differs in L' in str(exc)
        loader.append({'target_L':L,'accepted':False,'reason':str(exc)})

result={'status':'completed_read_only_review','seconds':time.monotonic()-START,
 'source_files_sha256':{str(SRC/name):sha(SRC/name) for name in ('sine.py','precision.py','projector.py','grid.py','assembly.py','pmp.py','precision_pmp.py','spec.py')},
 'producer_sha256':sha(__file__),'family_metadata':family_meta,'M50_row_comparisons':comparisons,
 'all_M50_raw_rows_identical':all(x['raw_Arb_midpoint_radius_identical'] for x in comparisons),
 'all_M50_midpoints_identical':all(x['exact_midpoints_identical'] for x in comparisons),
 'all_M50_30digit_rows_identical':all(x['thirty_digit_midpoint_text_identical'] for x in comparisons),
 'all_M50_intervals_overlap':all(x['all_intervals_overlap'] for x in comparisons),
 'small_M_exact_amplitude_checks':small,'current_loader_checks':loader,
 'scope':'No core changes, full operator assembly, SVD, scientific amplitude reads, SDPB or new optimization. M3 rational controls are exact in the stated q1/q3 subspace; arbitrary z triples test the polynomial identity before restricting Mandelstam kinematics.'}
write(HERE/'CHECKS.json',result)
print(json.dumps({k:result[k] for k in ('seconds','all_M50_raw_rows_identical','all_M50_midpoints_identical','all_M50_30digit_rows_identical','all_M50_intervals_overlap')},indent=2))
print('M50 comparisons',len(comparisons),'exact M3 checks',len(small))
