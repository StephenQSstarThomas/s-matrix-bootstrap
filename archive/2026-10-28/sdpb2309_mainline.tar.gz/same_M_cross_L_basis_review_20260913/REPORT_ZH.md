# 同 M 跨 L 的保存基底运输：预实现审查

**结论：在同 M、同一已核实解析族和同一密度打包下，可以允许 `load_saved_basis` 运输原基底矩阵到不同 L；运输的是坐标空间，不是可行性或最优性。** 当前接口仍拒绝跨 L，本次未改代码或启动求解。该能力首先服务论文正式 C8 的 L8/L10/L12 控制，L13 只是另外一个可选相邻截断诊断，不预设下一次运行它。

## 数学依据与源码位置

原密度向量为 `T0, sigma1, sigma2, rho1, rho2-upper`，维数

\[
n_c(M)=1+2M+M^2+M(M+1)/2,
\]

只取决于 M。取保存矩阵 U∈R^(n_c×n_a)，c=Ua；在固定 U、a 和 M 下，完整 A(s,t,u) 与全部分波函数不会因为指定新的 L 而改变。L 只指定本次施加哪些角动量：I0/I2 为 0,2,…,2L−2，I1 为 1,3,…,2L−1。因此共享的 `(I,ell,s)` 所对应的**精确数学投影**相同；增加 L 会增加约束，减少 L 会减少约束，不是换一个密度空间。[论文第 21 页 (3.62)](https://arxiv.org/pdf/2309.12402v3#page=21)、[第 36 页附录 A](https://arxiv.org/pdf/2309.12402v3#page=36)

当前 [Layout 与 ells_for](/home/shiqiu/s-matrix-bootstrap/src/smatrix_bootstrap/sdp/projector.py:45)正是这一分工；[SineFamily](/home/shiqiu/s-matrix-bootstrap/src/smatrix_bootstrap/sdp/sine.py:20)的节点、D 矩阵和 g_j 多项式数学定义只含 M。然而它的初始化 `geometry_bits` 会随 L 增加保护位，故**相同解析行不保证每个 Arb 区间的中点和半径整体都逐字节相同**。不能仅删除 L guard 后泛称旧新 PMP 输入完全相同。

## 已执行的有界控制

M50 取 dps=40，检查 S0/P1 的 s=3 行、S0 node42、P1 node33、S2 node42，以及共享的 P1 ell19/node0、ell23/node0。仅在对应两个 L 都含该波时比较，没有全量装配或 SVD。

| L 对照 | 共享行对数 | 精确 dyadic 中点 | 30 位中点文本 / binary64 字节 | 原始中点+半径 |
|---|---:|---|---|---|
| 8 ↔ 10 | 5 | 全部逐项相同 | 全部相同 | 全部相同 |
| 10 ↔ 12 | 6 | 全部逐项相同 | 全部相同 | 仅 P1 ell19/node0 有 431/7752 个半径不同 |
| 12 ↔ 13 | 7 | 全部逐项相同 | 全部相同 | 全部相同，含 ell23/node0 |

共 18 对、139,536 个实/虚行条目，中点差严格为 0，区间全部重叠；M50 原坐标维数始终 3876。L8/10/12/13 的初始化保护精度分别为 429/482/539/569 bits，基础行目标仍为 40 dps。该例最大半径绝对差约 1.67947×10⁻¹³⁹；精确有理数在 `RADIUS_DETAIL.json`，完整行的规范化 dyadic 序列哈希在 `CHECKS.json`。这里的“相同”不指 Python 对象内存地址，也不把少量行结果推广为整个目标 PMP 的字节相同。

独立小 M 控制使用 M3、两组有理 DST 样本 v=(1,−1,1)、w=(1/2,1,1/2)，分别对应 q3=z³+1 与 q1=z+1。构造非对称 rho1、对称 rho2 及单谱系数，均为精确有理数；其 n=2 模由对称性严格消去。用独立 Fraction 多项式表达式与实际 Layout 解包后的密度收缩比较，在 L8/10/12/13、四组三腿参数上共 **16 项差严格为 0**，实际 cardinal 区间也均包含同一个精确值。任意 z 三元组检验的是限制到 s+t+u=4 之前的多项式恒等式，不把它们全部称作物理运动学点；其中 (z_s,z_t,z_u)=(1,0,0) 对应 (s,t,u)=(4,0,0)。这不是使用浮点 sin 的近似相等冒充精确 DST 证明。

合成的 M3/L12 保存 basis 还验证了当前 API：同 L12 读取后矩阵字节不变，`feasibility_transferred=False`；目标 L8/L10/L13 都按现有 guard 拒绝，理由为 `Basis source differs in L`。合成 `accepted` 元数据仅用于接口前提控制，不是科学可行见证。整组检查耗时约 2.86 秒，未读取真实科学幅度或相位。

## 最小安全实现边界（尚未实施）

1. 只放宽 [load_saved_basis 的 L 相等项](/home/shiqiu/s-matrix-bootstrap/src/smatrix_bootstrap/sdp/assembly.py:202)。保留 M、解析族/packing、源接受、实际 basis SHA、float64 有限性、原 n_c×n_a 布局、原 source 变量布局和 producer 身份检查；明确同名 scheme 不能掩盖改变过的数学核。
2. basis.npy 原字节和 n_a 不变，不重新 SVD，不应用目标 `basis_tol` 再截断。元数据新增 source_L/target_L、跨 L 运输标记，继续写 `feasibility_transferred=False`、`constraints_reassembled=True`；不得改写原报告 L。更小 L 的原生子集关系也不转移支持最优性。
3. **目标 mask、波索引、PMP 与 source verification 全部按目标 L 重建。** I1/I2 的扁平行起点随 L 移动，禁止直接复制旧 mask 或按原数组位置删加。Gram 仍只替换目标索引中的两主波盘；显式 subset mask 必须是目标维度并按 `(I,ell,node)` 定义。basis 的运输不授权 `Pmp.from_saved` 跨 L 重用旧 PMP。
4. 后续实现测试应覆盖双向 L12→10 与 L10→12、L12→13，及错 M/packing/basis/hash 拒绝；核对目标行数、正确 Gram mask 与新行验收。正式 C8 保留各自 ModelSpec 和选择规则，只在明确共同 U 的实验中把差异解释为施加波集合改变，不宣称已证明 SVD 全空间等价。

本次支持的是上述窄接口修复的数学可行性和已测共享行精度；不声称跨 L 运输已实现、目标解存在、截断收敛或 C8 完成。`CHECKS.json` 保存覆盖范围、源文件与 producer 哈希；未改变核心代码、源输入、中央交付或 solver 状态。
