在读取新相位前冻结：仅检验同一 IR M50/L12、χ-c εχ=0.00021、同 saved basis、同 (0,1) 目标与 x_ref 截面的停止 gap 敏感性。SDPB320 bits、源40digits、PMP30digits、8ranks、primal/dual阈值1e-10均固定。gap由1e-6改为1e-8；仅一次1200秒warm start，无自动续跑或升级。

先验证源checkpoint兼容；最终逐header、逐block比较PMP完整系数及basis身份。只有终态accepted并完成原完整y/source验收后，才比较complex S、native raw phase、modulo-pi phase差、eta、40点Weinberg RMS与C4_source。报告phase差max/RMS，1度只作为诊断用途目标，不变成论文新验收，不声称最优幅度唯一。旧基线保持。精确参数、hash、command和checkpoint清单见PLAN.json。

启动前追加冻结：比较新accepted目标与旧数值support上下候选；明确旧/新目标读回误差和截面残差。若新目标超过旧upper且超出roundoff，标记原数值support界不可靠，不仅称相位漂移。1度是操作性10度比较的10%诊断精度预算，不是论文统计误差。
