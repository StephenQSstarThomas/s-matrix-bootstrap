"""Frozen same-PMP stopping-gap comparison; no solver and no selection changes."""
from pathlib import Path
from fractions import Fraction
import csv
import datetime
import hashlib
import json
import math
import re

import numpy as np
from smatrix_bootstrap.sdp.delivery import c4_source, ir_linearity
from smatrix_bootstrap.sdp.sdpb import Settings, convergence_report, read_out

ROOT = Path(__file__).resolve().parent
plan = json.loads((ROOT/'PLAN.json').read_text())
paths = [Path(plan['source_report']), Path(plan['command'][-1])/'report.json']
records = [json.loads(p.read_text()) for p in paths]
assert all(r['status']=='numerically_accepted' and r['accepted'] is True for r in records), 'Only terminal accepted sources are eligible'
identity = json.loads((ROOT/'INPUT_IDENTITY.json').read_text())
assert identity['pmp_bytes_identical'] and identity['basis_bytes_identical']


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def check_source(path, record):
    directory, v = path.parent, record['verification']
    for name, digest in [('pmp.json',record['pmp']['sha256']),
                         ('basis.npy',record['basis']['sha256']),
                         ('out/y.txt',record['y_sha256']),
                         ('solution.npz',record['solution_sha256'])]:
        assert sha(directory/name)==digest, name
    assert record['pmp']['sha256']==plan['source_pmp_sha256']
    assert record['basis']['sha256']==plan['basis_sha256']
    lines=(directory/'out/y.txt').read_text().splitlines()
    shape=list(map(int,lines[0].split()))
    count=len([v for v in lines[1:] if v.strip()])
    assert shape==[record['pmp']['n_vars']-1,1] and count==record['pmp']['n_a']
    audit=v['source_audit'];tol=Fraction(1,10**8)
    slack=[Fraction(row['slack']['lower']) for row in audit['unitarity']]
    square=[Fraction(row['h_squared']['lower']) for row in audit['unitarity']]
    worst=max(-value for value in slack)
    relative=max(-s/h for s,h in zip(slack,square) if h>Fraction(1,10**12))
    unitary=worst<=tol and relative<=Fraction(1,10**6)
    eps=Fraction(str(record['spec']['eps_chi']))
    budget=eps**2*(2*tol+tol**2)
    chiral=all(Fraction(row['slack']['lower'])>=-budget for row in audit['chiral']['constraints'])
    section=abs(v['f00_3']-record['fix_f00'])<=1e-8
    raw=read_out(directory/'out/out.txt')
    convergence=convergence_report(raw,record['sdpb']['returncode'],v['objective_recomputed'],Settings(**record['settings']))
    assert unitary and chiral and section and convergence['solver_optimal']
    assert v['primal_feasible'] is True and all(v['constraint_checks'].values())
    assert len(slack)==1800 and len(audit['chiral']['constraints'])==2
    projection=audit['projection_at_3']
    exact_section=[Fraction(projection['f00'][edge])-Fraction(str(record['fix_f00'])) for edge in ('lower','upper')]
    out_text=(directory/'out/out.txt').read_text()
    raw_dual=Fraction(re.search(r'dualObjective\s*=\s*([^;]+);',out_text).group(1).strip())
    exact_readback=[Fraction(projection['f11'][edge])-raw_dual for edge in ('lower','upper')]
    return {'report_sha256':sha(path),'full_y_sha256':record['y_sha256'],'full_y_entries':count,
            'source_interval_numeric_replay':{'unitarity':unitary,'chiral':chiral,'section':section,
              'max_absolute_violation':float(worst),'max_relative_violation':float(relative)},
            'convergence':convergence,'source_audit_counts':audit['unitarity_counts'],
            'chiral_verdict':audit['chiral_verdict'],'projection_at_3':audit['projection_at_3'],
            'section_residual':v['section_residual'],
            'source_minus_decimal_section_enclosure':[str(x) for x in exact_section],
            'source_minus_decimal_section_float_bounds':[float(x) for x in exact_section],
            'source_minus_raw_dual_objective_enclosure':[str(x) for x in exact_readback],
            'source_minus_raw_dual_objective_float_bounds':[float(x) for x in exact_readback],
            'scope':'Original saved Arb enclosures and raw solver output independently checked under unchanged numerical budgets; not a new rigorous dual certificate.'}


checks=[check_source(path,record) for path,record in zip(paths,records)]
assert checks[0]['report_sha256']==plan['source_report_sha256'], 'Baseline changed'
source_c4=[c4_source(r['observables']) for r in records]
linearity=[ir_linearity(r) for r in records]
assert all(v['status']=='evaluated' and v['n']==40 for v in linearity)
native_rows=[];summaries={}


def stats(values,mask):
    use=np.asarray(values)[mask]
    return {'max_abs':float(np.max(np.abs(use))),'rms':float(np.sqrt(np.mean(np.abs(use)**2)))}


for wave,quantum in [('S0',(0,0)),('S2',(2,0)),('P1',(1,1))]:
    old,new=[r['observables'][wave] for r in records]
    E=np.asarray(old['E_GeV']);assert np.array_equal(E,new['E_GeV']) and len(E)==50
    delta0,delta1=np.asarray(old['delta_deg']),np.asarray(new['delta_deg'])
    eta0,eta1=np.asarray(old['eta']),np.asarray(new['eta'])
    assert all(np.all(np.isfinite(v)) for v in [delta0,delta1,eta0,eta1])
    S0,S1=eta0*np.exp(2j*np.radians(delta0)),eta1*np.exp(2j*np.radians(delta1))
    for record,S,eta in zip(records,[S0,S1],[eta0,eta1]):
        rows=[v for v in record['verification']['source_audit']['unitarity'] if (v['isospin'],v['ell'])==quantum]
        h2=np.array([float((Fraction(v['h_squared']['lower'])+Fraction(v['h_squared']['upper']))/2) for v in rows])
        assert np.max(np.abs(S.real-(1+eta**2-h2)/2))<1e-12
    raw=delta1-delta0
    mod=np.degrees(np.angle(S1*np.conjugate(S0)))/2
    masks={'all_native':np.ones(len(E),bool),'E_le_1p2_GeV':E<=1.2}
    for row in source_c4[0]['rows']:
        if row['wave']==wave:
            lo,hi=row['common_energy_GeV'];masks['C4_published_overlap']=(E>=lo)&(E<=hi)
    summaries[wave]={}
    for name,mask in masks.items():
        summaries[wave][name]={'nodes':int(mask.sum()),'energy_GeV':[float(E[mask].min()),float(E[mask].max())],
          'raw_phase_change_deg':stats(raw,mask),'mod_pi_phase_change_deg':stats(mod,mask),
          'complex_S_change':stats(S1-S0,mask),'eta_change':stats(eta1-eta0,mask),
          'minimum_eta_old_new':[float(eta0[mask].min()),float(eta1[mask].min())],
          'max_mod_pi_within_1deg':bool(np.max(abs(mod[mask]))<=1.)}
    for i in range(50):
        native_rows.append([wave,i,float(E[i]),float(S0[i].real),float(S0[i].imag),float(S1[i].real),float(S1[i].imag),
          float(delta0[i]),float(delta1[i]),float(raw[i]),float(mod[i]),float(eta0[i]),float(eta1[i])])

with (ROOT/'native_comparison.csv').open('w') as stream:
    writer=csv.writer(stream);writer.writerow(['wave','node','E_GeV','old_S_re','old_S_im','new_S_re','new_S_im','old_raw_phase_deg','new_raw_phase_deg','raw_change_deg','mod_pi_change_deg','old_eta','new_eta']);writer.writerows(native_rows)
sub_rows=[]
for wave in ('S0','S2','P1'):
    a,b=[r['subthreshold'] for r in records]
    assert a['s']==b['s']
    s=np.asarray(a['s']);mask=np.isin(s,np.linspace(.05,3.95,40));assert mask.sum()==40
    for i in np.flatnonzero(mask):sub_rows.append([wave,float(s[i]),a[wave][i],b[wave][i],b[wave][i]-a[wave][i]])
with (ROOT/'subthreshold_comparison.csv').open('w') as stream:
    writer=csv.writer(stream);writer.writerow(['wave','s','old_f','new_f','change']);writer.writerows(sub_rows)
old_cv,new_cv=[v['convergence'] for v in checks]
objective=records[1]['verification']['objective_recomputed'];excess=objective-old_cv['candidate_upper']
ulp=max(math.ulp(objective),math.ulp(old_cv['candidate_upper']))
support={'old_candidate_lower':old_cv['candidate_lower'],'old_candidate_upper':old_cv['candidate_upper'],
         'new_objective':objective,'new_candidate_upper':new_cv['candidate_upper'],
         'new_minus_old_upper':excess,'roundoff_ulp_scale':ulp,'excess_in_ulps':excess/ulp,
         'old_support_unreliable_flag':excess>100*ulp,'flag_scope':'An excess larger than 100 binary64 ulps flags numerical-bound inconsistency. This does not turn either reported support interval into a rigorous bound.',
         'old_new_readback_error':[old_cv['objective_readback_error'],new_cv['objective_readback_error']],
         'old_new_section_residual':[v['section_residual'] for v in checks]}
log=(paths[1].parent/'sdpb.log').read_text()
result={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan_sha256':sha(ROOT/'PLAN.json'),
        'source_reports':list(map(str,paths)),'input_identity':identity,'acceptance_checks':checks,
        'support_comparison':support,'phase_summaries':summaries,'C4_source_old_new':source_c4,
        'weinberg_linearity_40_old_new':linearity,'main_iterations':len(re.findall(r'^\d+\s+\d+\s+',log,re.M)),
        'checkpoint_load_logged':'Loading binary checkpoint from' in log,
        'timing':{'total':records[1]['seconds'],'solver':records[1]['sdpb']['seconds'],'pmp2sdp':records[1]['pmp2sdp']['seconds']},
        'complex_S_scope':'Reconstructed from saved source-evaluated eta and raw native phase; real part independently checked against stored Arb |h|^2 identity.',
        'diagnostic_budget':'1 degree = 10% of the operational 10-degree comparison, not paper statistical uncertainty.',
        'limitations':['Fixed section and fixed finite PMP only','No uniqueness or stability theorem for optimal amplitudes','Numerical stopping-gap sensitivity is not L-convergence','No strict global/dual certificate'],
        'producer_sha256':sha(Path(__file__))}
(ROOT/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'accepted':True,'support':support,'phase_summaries':summaries,'C4_verdicts':[v['verdict'] for v in source_c4]},indent=2))
