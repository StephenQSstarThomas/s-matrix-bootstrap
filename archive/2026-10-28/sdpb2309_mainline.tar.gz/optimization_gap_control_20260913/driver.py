"""Execute exactly one frozen gap-control command, preserving lifecycle evidence."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

root = Path(__file__).resolve().parent
plan_path = root / 'PLAN.json'
plan = json.loads(plan_path.read_text())
record = {'driver_pid': os.getpid(), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'started_unix': time.time(), 'command': plan['command'],
          'plan_sha256': hashlib.sha256(plan_path.read_bytes()).hexdigest(), 'terminal': False}
path = root / 'driver.json'
path.write_text(json.dumps(record, indent=2)+'\n')
with (root / 'run.log').open('x') as log:
    process = subprocess.Popen(plan['command'], cwd='/home/shiqiu/s-matrix-bootstrap',
                               stdout=log, stderr=subprocess.STDOUT)
    record['cli_pid'] = process.pid
    path.write_text(json.dumps(record, indent=2)+'\n')
    code = process.wait()
record.update(returncode=code, terminal=True,
              finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              seconds=time.time()-record['started_unix'])
out = Path(plan['command'][-1])
record['cids'] = {p.name: p.read_text().strip() for p in out.glob('*.cid')}
record['process_records'] = {p.name: json.loads(p.read_text()) for p in out.glob('*_process.json')}
path.write_text(json.dumps(record, indent=2)+'\n')
