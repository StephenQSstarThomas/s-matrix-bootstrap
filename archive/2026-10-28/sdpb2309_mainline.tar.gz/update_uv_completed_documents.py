from pathlib import Path
import gzip,json,hashlib,datetime
R=Path('/home/shiqiu/s-matrix-bootstrap');B=(R/'results/runs/sdpb_mainline_20260912').resolve();D=B/'reproduction_review_20260913'
paths=[R/'HANDOFF_PHYSICS_AUDIT_ZH.md',B/'LIMITATIONS_FIRST_ZH.md',D/'REPORT_ZH.md',D/'evidence_index_producer.py']
snapshot=B/'documents_before_calibrated_uv_completion.json.gz'
assert not snapshot.exists()
with gzip.open(snapshot,'wt') as f:json.dump({str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'text':p.read_text()} for p in paths},f,ensure_ascii=False)
p=R/'HANDOFF_PHYSICS_AUDIT_ZH.md';t=p.read_text();start=t.index('当前两项科学计算是');end=t.index('\n\n前一组',start)
t=t[:start]+'''χ=.00021 的同basis UV tip/ref/near已全部终态通过，完整选定IR＋三UV对比见 `FPI_CALIBRATED_FULL_CONTRAST/`：C4、C6、C7均FAIL。tip：x=.205068159213、y=−.0136248072904、63.7分钟，P1首次90°≈911.779MeV、minη=.469667；ref：x=xref、y=−.00443854642136、64.3分钟，无原生低能90°、minη=.140574；near：x=.0740546044436、y=−.00448739123093、12.49分钟，也无90°、minη=.144387。各波图及1116行支持CSV保持保存相位，论文η留空。实际basis/完整y/源合同均通过核对，只有IR ref与UV ref匹配目标和截面；不同代表的差不能全部归因于UV。

near截面已在新UV相移读取前由 `FPI_CALIBRATED_UV_NEAR_PLAN/report.json` 固定，随后 `FPI_CALIBRATED_UV_SELECTION/report.json` 核验三完整幅度。内部mid槽明确映射near，旧算术中点登记仍为未完成。近点没有因曲线差异再选择。保持M50/L12、χ=.00021、chi-c、无B、sine-cardinal、SR-a raw四矩、逐节点FF、mqmean和原QCD参数；此为fπ校准实验，不是恢复作者ε。

当前唯一优化是C5下边界 `UV_M50_L12_fpi_calibrated_eps00021_lower_warm/report.json`，driver PID745902、2026-09-13 11:55:25 UTC启动，方向(0,−1)、固定xref，8ranks、320bit、1200秒求解预算。它只补同basis上下收缩，未作为第四个相位代表；不读取其相位。计划见 `FPI_CALIBRATED_C5_LOWER_PLAN.json`。''' +t[end:]
t=t.replace('已实际写出8个非空rank检查点；尚未测试加载恢复。','当时仅实际写出8个非空rank检查点；后续near已实际验证加载，见下述warm-start记录。')
t=t.replace('按现有M50实测，单个支持约45–70分钟；IR参考加UV三代表的一轮先预算3–5小时。','按现有M50实测，冷启动单个支持约45–70分钟；同合同邻点warm-start实测12.49分钟。固定M50/L12的一轮IR两端＋UV三代表，按两组各8ranks并行及已验收邻点复用，约2–3小时（理想实测工段合计约2小时）；冷启动串行或环境重试约3–5小时。')
t=t.replace('最新完整工程测试为 [PREPARED_MASK_FINAL_TESTS.txt](results/runs/sdpb_mainline_20260912/PREPARED_MASK_FINAL_TESTS.txt)：217项通过，78.37秒。','最新完整工程测试为 [WARM_START_CLI_FINAL_TESTS.txt](results/runs/sdpb_mainline_20260912/WARM_START_CLI_FINAL_TESTS.txt)：217项通过，76.65秒。')
a=t.index('[更新综合报告]');z=t.index('\n\n## 选定IR',a)
t=t[:a]+'''[综合报告](results/runs/sdpb_mainline_20260912/reproduction_review_20260913/REPORT_ZH.md)及[PDF](results/runs/sdpb_mainline_20260912/reproduction_review_20260913/pdf/REPORT_ZH.pdf)纳入名义tip、相邻χ、凸组合校准、两IR端点和三UV代表，缺陷优先。`reproduction_package_20260913/`持续更新完成案例；以 `PACKAGE_INDEX.json` 的实际归档哈希与验证为准，不能把staging新增文件说成旧压缩包已有。完整PMP/basis单独压缩，mask、MMA复用资料和完整y保留；搬移后实际PMP目标重建、MMA资料复用及幅度重导出已通过。许可证和账号凭据不入包。''' +t[z:]
t=t.replace('真实三UV收据仍待本轮支持完成。','真实三UV收据和完整contrast已通过实际CLI核验，物理C4/C6/C7仍FAIL。')
t+='''

## 已实测的SDPB检查点复用

`python -m smatrix_bootstrap.run sdp support --source-report 完成UVref叶 --direction 0 1 --fix-f00 0.07405460447866398 --warm-start --timeout 1200 --out 新目录`可复现本次near初始化方式。source报告必须已接受；完整转换块结构/采样、basis、normalization、SDPB3.1.0、320bit、8ranks和分块分配必须匹配。只允许目标/截面改变，原式验收重新执行。检查点独立复制到warm_start_input，输入与输出sdp.ck分离，原checkpoint不改。

near的SDPB日志实际记录加载binary checkpoint，主迭代14步，SDPB520.36秒、转换121.61秒、总749.37秒，最终primalError4.72e−32、dualError3.51e−11，原式数值通过。它说明邻近问题可减少耗时；没有同PMP冷启动对照，不宣称严格加速倍数。当前仅验证单宿主Docker；多节点须保持兼容MPI及分块身份，不能把本地加载说成百节点验证。原始初始化检查点及哈希留在运行目录，便携归档是否含其二进制以PACKAGE_INDEX为准。
'''
p.write_text(t)
p=D/'REPORT_ZH.md';t=p.read_text()
t=t.replace('同容差的完整UV tip/ref仍在计算，未读取其新相移。','同容差的UV tip/ref/near已完成完整对比，C4/C6/C7均FAIL；C5下边界正在补算。')
t=t.replace('完整 UV 上下截面与三代表组合、五种 M/L 的对应幅度。','完整 UV 上下截面、五种 M/L 的对应幅度。校准M50/L12的一IR＋三UV状态对比已完成，C4/C6/C7仍FAIL。')
t=t.replace('当前交付明确写着 `incomplete_registered_chain=true`、`main_contrast_pass=false`。','新交付写着 `paper_state_comparison_complete=true`、`paper_state_comparison_pass=false`；`incomplete_registered_chain=true`专指未完成旧算术mid登记，不能再解释为缺新near。')
t=t.replace('同 basis L12 上截面降低 3.5998e−5；缺 UV lower、完整边界及名义分辨率匹配，不能完成上下比例。','名义L12上截面降低3.5998e−5；校准χ=.00021上截面降低1.29561e−5，下端正在补算；完整边界及名义分辨率匹配未齐。')
t=t.replace('当前 UV ref 无低能 90° 读数、min η≈.276；tip/mid 缺项，总项 not run。源相位无法提供 η。','校准三UV已齐：tip90°≈911.78MeV，ref/near无原生穿越；minη=.4697/.1406/.1444，C6 FAIL。源相位无法提供η。')
t=t.replace('ref 的 RMS 已偏离；源域修正完成，完整三代表集合未齐，C7_source not run。','校准三UV集合已齐，六项S0/S2比较均FAIL；near明确不同于旧mid，源域与覆盖保护保留。')
t=t.replace('同 basis 的 reference-only IR→UV 对照、单点相移/η | 完整 UV 区域、三代表与可复现的 ρ/相位结果','同basis的选定IR＋三UV相位/η完整对照，失败已量化 | 完整UV区域、名义分辨率及通过的ρ/相位结果')
a=t.index('[20] **当前固定χ=.00021进入完整UV。**');z=t.index('\n\n<!-- pagebreak -->',a)
t=t[:a]+'''[20] **校准UV三代表全部完成。** 同basis tip、ref及冻结near保持SR-a、逐节点FF、mqmean和原QCD参数。accepted tip后、读取新UV相位前，统一`uv-plan`固定 x_near=xref+min(.01xref,(xtip−xref)/2)=.074054604478664；实际near截面误差3.51e−11在原预算内。`uv-select`已实际逐叶核对目标、截面、完整PMP物理块、mask、basis及完整y。完整contrast使用一份已选IR和三UV，内部mid槽显式标为near，旧算术中点不追认为完成。

| 校准UV代表 | f00(3) | f11(3) | P1首次90°（MeV） | 原生窗minη | 总耗时 |
|---|---:|---:|---:|---:|---:|
| tip | .205068159213 | −.0136248072904 | 911.779 | .469667 | 63.7 min |
| ref | .073321390573 | −.00443854642136 | 未观测 | .140574 | 64.3 min |
| near | .074054604444 | −.00448739123093 | 未观测 | .144387 | 12.49 min |

三个已验收状态仍未复现论文的ρ与S波结论。C6 FAIL，tip穿越括区为[864.418,952.250]MeV；ref/near没有原生低能穿越，不作连续无共振排除。C7_source六项均FAIL，tip/ref/near的S0 RMS为18.93°/12.78°/15.57°，S2为7.08°/5.29°/4.98°，后者仍因公开高能末点差而不通过。全部是同保存幅度的比较，没有再次调整χ、相位分支或代表坐标。

![校准一IR与三UV的完整相位对照；near按事前固定规则选取，原相位不改。](../FPI_CALIBRATED_FULL_CONTRAST/phases.png)

![同四幅度的原生η；水平线仅为幺正上界，论文未公开η曲线。](../FPI_CALIBRATED_FULL_CONTRAST/inelasticity.png)

[完整对比与验收](../FPI_CALIBRATED_FULL_CONTRAST/VALIDATION.json)及[1116行支持CSV](../FPI_CALIBRATED_FULL_CONTRAST/phase_eta.csv)保留所有保存点和公开曲线，论文η留空。全组basis相同，但只有IR ref／UV ref的目标及截面相同；不同代表之间的变化不能全部归因于UV。当前唯一新求解为同xref UV lower，只补C5上下几何，不作第四个相位代表。选定IR的[阈下CSV](../FPI_CALIBRATED_IR_FIGURES_FINAL/subthreshold.csv)继续绑定同一完整幅度。
''' +t[z:]
t=t.replace('后续实际观察到 8 个非空 rank checkpoint，但恢复加载本身没有经过实测。','当时只观察到8个非空rank checkpoint；后续near已实际完成checkpoint加载与原式重新验收。')
t=t.replace('| 当前完整工程测试 | 217 passed，78.37 s |','| 校准UV tip / ref / near | 3821.17 s / 3858.65 s / 749.37 s | near实际warm-start；没有同PMP冷启动加速比 |\n| 当前完整工程测试 | 217 passed，76.65 s |')
t=t.replace('当前单个M50支持约45–70分钟，IR加三个UV代表的一轮先预算3–5小时，环境等待或重试会延长；完整Fig.3–11另计。','冷启动单个M50支持约45–70分钟。同合同邻点warm-start已实测12.49分钟；按IR两端并行约45.9分钟、UV tip/ref并行约64.3分钟和near约12.5分钟，固定M50/L12核心一轮工段合计约2小时，实际预算2–3小时。冷启动串行、环境等待或重试可至3–5小时或更长；完整Fig.3–11另计。')
t=t.replace('[最新测试原文](../PREPARED_MASK_FINAL_TESTS.txt)','[最新测试原文](../WARM_START_CLI_FINAL_TESTS.txt)')
pos=t.index('\n[13] 可搬移的 canonical')
t=t[:pos]+'''
[22] 实际near检查点复用遵循SDPB 3.1.0的[官方说明](https://github.com/davidsd/sdpb/blob/3.1.0/docs/Usage.md#running-sdpb)：结构、精度、进程数及分配保持匹配，沿用原block_timings。原checkpoint独立复制到输入目录，输出写另一目录；重新执行所有物理验收。near主迭代14步、SDPB520.36秒、转换121.61秒、总749.37秒，primalError4.72e−32、dualError3.51e−11。沿用gap1e−6，但为满足原始可行性阈值实际gap降到8.67e−11，并非新增过严精度目标。[实测记录](../FIRST_FPI_CALIBRATED_UV_NEAR_WARM.json)。此初始化仅实测单宿主Docker；冷启动再生成PMP可以重算同一个有限问题，精确重复本次初始化还需二进制checkpoint。
''' +t[pos:]
t=t.replace('[SOURCE_L12_PAPER_STYLE_REFERENCE/report.json](../SOURCE_L12_PAPER_STYLE_REFERENCE/report.json)；保留输入哈希、C4_source、C7_source、rho 与选择身份','[校准完整对比](../FPI_CALIBRATED_FULL_CONTRAST/VALIDATION.json)；旧名义L12对比继续保存，校准结果不追认为名义结果')
t+='\n22. **实际SDPB初始化复用。** [完成记录](../FIRST_FPI_CALIBRATED_UV_NEAR_WARM.json)、[官方SDPB3.1.0用法](https://github.com/davidsd/sdpb/blob/3.1.0/docs/Usage.md#running-sdpb)：仅改变固定截面，完整source重新验收；不宣称多节点或成对冷启动加速比。\n'
p.write_text(t)
p=D/'evidence_index_producer.py';t=p.read_text().replace("FORBIDDEN = ('UV_M50_L12_fpi_calibrated_eps00021_tip', 'UV_M50_L12_fpi_calibrated_eps00021_ref')","FORBIDDEN = ('UV_M50_L12_fpi_calibrated_eps00021_lower_warm',)")
t=t.replace("assert '217 passed，78.37 s' in text","assert '217 passed，76.65 s' in text").replace("assert '217 passed in 78.37s' in (RUN / 'PREPARED_MASK_FINAL_TESTS.txt').read_text()","assert '217 passed in 76.65s' in (RUN / 'WARM_START_CLI_FINAL_TESTS.txt').read_text()")
t=t.replace('no solver or reads of running calibrated-UV reports/phase arrays; completed nominal and adjacent tip metadata included.','no optimizer or reads of the pending C5 lower phase; completed calibrated IR and all three UV states included.')
t=t.replace("'selected_current_metrics': {k: contrast[k] for k in ('C4_source', 'C7_source', 'rho', 'selected_ir_diagnostics')},","'historical_nominal_metrics': {k: contrast[k] for k in ('C4_source', 'C7_source', 'rho', 'selected_ir_diagnostics')},\n    'selected_current_metrics': read('FPI_CALIBRATED_FULL_CONTRAST/VALIDATION.json'),")
p.write_text(t)
p=B/'LIMITATIONS_FIRST_ZH.md';t=p.read_text()
t=t.replace('当前只运行同容差的完整UV tip/ref，冻结uv-plan前不读新UV phase。','同容差的UV tip/ref/near已经全部验收并完成对比，C4/C6/C7均FAIL。当前只补算C5下边界，不用其相移选点。')
t=t.replace('三UV代表缺项仍不得通过。','校准三UV完整对比已执行，仍未通过。')
t=t.replace('当前仅试论文列出的ε=.001和原合同下优先UV tip，没有B/Watson或大网格调参。','已完成论文列出的ε=.001试验，再用物理fπ的既有幅度凸见证校准χ=.00021，完成两IR和三UV；没有B/Watson或相移拟合。')
t=t.replace('完整IR/UV截面与三UV代表、五配置稳定性等。','完整IR/UV截面及区域、五配置稳定性等；χ=.00021的三UV代表已齐而物理失败。')
t=t.replace('目前最新完整测试217项通过（84.26秒）','目前最新完整测试217项通过（76.65秒）').replace('当前两项独立任务合计16 ranks在一台已核验主机','当前一项8ranks任务在一台已核验主机')
t=t.replace('当前χ=.00021按已存幅度重建physical black及邻域来校准','本次χ=.00021按已存幅度重建physical black及邻域来校准')
t=t.replace('完整组合只评了投影和χ','完整组合已核对投影、χ及1800个原生盘（0失败、67项inactive未定）')
t=t.replace('完整UV主线已按FPI_CALIBRATED_UV_MAINLINE_PLAN.json启动','完整UV三代表已按FPI_CALIBRATED_UV_MAINLINE_PLAN.json完成')
t=t.replace('新UV三代表的实物交付仍未完成。','新UV三代表的实物交付已完成，见FPI_CALIBRATED_FULL_CONTRAST：tip90°约911.779MeV、minη=.469667；ref/near无原生穿越、minη=.140574/.144387；六项S0/S2比较均FAIL。')
t+='\nnear实际加载检查点，14步主迭代、总12.49分钟并重新通过原式验收。固定M50/L12核心一轮按已有有限并行及邻点复用约2–3小时；全部Fig.3–11及研究查错另计。原数值预算不变，没有为追求额外位数硬算。\n'
p.write_text(t)
print('updated',len(paths),'documents; preserved original bytes in',snapshot)
