IR 两端点选择与论文式状态交付

```bash
python -m smatrix_bootstrap.run sdp ir-select \
  --source-report UPPER_LEAF/report.json \
  --compare-report LOWER_LEAF/report.json --out FRESH_SELECTION

python -m smatrix_bootstrap.run sdp contrast \
  --ir-selection-report FRESH_SELECTION/report.json \
  --ir-report SELECTED_LEAF/report.json \
  --uv-report UV_COMPLETE_CHAIN/report.json --out FRESH_CONTRAST
```

加 `--reference-only` 可比较 selected IR 与 UV ref；此时 UV triplet 仍不完整，C6/C7 为 not run，main_contrast_pass 为 false。不加该标志时，新模式允许一份已选择 IR 加 UV tip/ref/mid 三点，不要求另造三个 IR 代表。没有 selection receipt 的旧接口保持原规则。

选择只接受完成、数值验收通过的 IR/no-B/chiral 叶报告；upper/lower 的方向分别为 (0,+1)/(0,−1)，均须固定并满足 x_ref。两者 ModelSpec、实际本地 basis、全部 PMP 约束块（包括固定截面）及 normalization 必须一致，objective 必须为精确相反的非零向量。源报告、PMP 和 basis 用相对路径及哈希记录；搬移完整来源目录和收据后可重验。

理论目标为 Weinberg (x_ref,−x_ref/15)，度量为未加权欧氏距离。每点距离使用支撑 gap、目标回读差、固定 x 残差和浮点保护构成保守数值误差包络；两个包络重叠时记录 ambiguous，不能用于自动交付。该包络不是严格对偶证书。收据明确只是在这两个端点中较近，不证明全局最近边界点。

选择模块不按 observables、subthreshold 或 phase 字段取值。整体 report 哈希用于绑定全部源字节，不用于按相位选解。测试从没有这些字段的源完成选择，再添加它们，选择和几何值保持不变；旧收据同时会正确拒绝源字节变化。此前 upper-proxy 相位已经被观察过的历史范围明确保留，不追认为全盲预登记。原始预登记没有修改。

`contrast` 会重新读取两来源、重新核对矩阵与几何选择，并拒绝篡改、ambiguous 收据和非选中叶。`same_basis` 与 `matched_objective_causal_comparison_supported` 分开报告；新完整模式逐一比较 selected IR 与每个 UV 点的方向及截面。不同方向或截面时不作 matched-objective causal 声明，但仍允许明确标记的论文式状态比较。

新模式的 C4 使用 `C4_source`：三波与 Fig.7 的 ir_magenta 曲线在共同能区比较，采用 10° RMS 和最后公开 in-range 能量上的 10° endpoint 差预算，不外推到 1.2 GeV。旧 `claims.c4` 和阈值保存在 `C4_legacy`。依据是原图自己的 S0(.9 GeV)=82.5727°，会被旧 85–110° 门槛拒绝；这项源数据修正在新 lower 相位检查之前已由 root 冻结于 `C4_SOURCE_ACCEPTANCE_AMENDMENT.json`。

新模式的 C7 使用 `C7_source`：保持 S0 85–110°、S2 −40–−15°、RMS 10°及三点集合要求；仅把端点放到各波/颜色最后公开 in-range 能量，避免原 1.196 GeV 超出全部 Fig.10 参考数据末端。旧判据保存在 `C7_legacy`。C4_source 与 C7_source 都通过原图 phase-only 自身控制，并拒绝统一 +11° 偏移；未从参考相位制造 eta。

C6 的 crossing、spread、eta 门槛未改。eta≥.9 保留为已有 native-solution 诊断，并注明公开相位曲线不能提供这项数值证据。合成交付控制里的 eta 数组仅用于测试绘图输入格式，不能当作论文 eta 数据。

selected IR 的阈下报告给每波相对于同 f00(3) Weinberg 直线的 RMS/f00(3)。这是描述量，没有资格门槛或 pass 标签。原 C3 的 8% 比较的是同 epsilon 的 Fig.5 彩色论文曲线，不能套给 Weinberg 直线，也不能用这里的一条 IR 曲线代替完整 C3 epsilon 链。几何选择、C4 端点匹配或源参考自测通过都不自动证明 near-Weinberg 已成立。

本目录控制程序使用合成 M4 端点、真实公开参考曲线及独立矩阵/篡改/搬移控制。没有读取真实新 lower 的相位、启动科学 SDPB、执行真实选择或生成真实科学交付；真实选择由 root 单独执行。报告中的完整/部分标记描述交付输入是否齐备，不代表 Fig.3–11 已复现。
