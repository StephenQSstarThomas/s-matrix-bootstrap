"""Synthetic matrix, geometry, tamper, relocation and delivery controls; no solves."""
import copy,hashlib,json,shutil
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
import numpy as np
from smatrix_bootstrap.sdp import __main__ as cli,delivery,ir_selection as S
from smatrix_bootstrap.sdp.pmp import Pmp
from smatrix_bootstrap.sdp.spec import ModelSpec
from smatrix_bootstrap.sdp.constraints import chiral_reference_point
from smatrix_bootstrap.sdp.figures import load_csv

BASE=Path(__file__).resolve().parent;index=1
while (BASE/f'run_{index:02d}').exists():index+=1
ROOT=BASE/f'run_{index:02d}';ROOT.mkdir();XR,YR=chiral_reference_point()
spec=ModelSpec(M=4,L=2,chiral=True,chi_caliber='chi-c',uv=False,sr_caliber='SR-a',
    ff_frozen_at_s0=False,reduce_basis=True,operator_dps=40,scattering_prescription='sine-cardinal',tag='synthetic_ir_selection')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path,data):Path(path).write_text(json.dumps(data,indent=2)+'\n')
def leaf(folder,sign,y,*,uv=False,fixed=XR,x=XR,direction=None):
    folder.mkdir(parents=True);cfg=copy.deepcopy(spec);cfg.uv=uv
    direction=[0.,float(sign)] if direction is None else direction
    w=Pmp(cfg,direction=direction,fix_f00=fixed,digits=30);meta=w.write(str(folder/'pmp.json'));meta['sha256']=sha(folder/'pmp.json')
    np.save(folder/'basis.npy',w.basis);np.save(folder/'disk_mask.npy',w.keep)
    objective=direction[0]*x+direction[1]*y;gap=1e-7
    record={'solver':'SDPB','status':'numerically_accepted','accepted':True,'spec':asdict(cfg),'pmp':meta,
        'direction':direction,'fix_f00':fixed,'verification':{'primal_feasible':True,'f00_3':x,'f11_3':y,
        'objective_recomputed':objective,'constraint_checks':{k:True for k in ('unitarity','chiral','section','rho_nonnegative','gram','fesr','ff')},
        'source_audit':{'scattering_prescription':'sine-cardinal'}},
        'convergence':{'solver_optimal':True,'candidate_lower':objective,'candidate_upper':objective+gap,
                       'absolute_gap':gap,'objective_readback_error':0.},
        'basis':{'sha256':sha(folder/'basis.npy'),'tolerance':1e-12},
        'source_sha256':{'src/smatrix_bootstrap/sdp/'+p.name:sha(p) for p in Path(S.__file__).parent.glob('*.py')}}
    dump(folder/'report.json',record);return folder/'report.json'
def pair(folder,upper=YR+.003,lower=YR-.0001):
    return leaf(folder/'upper',1,upper),leaf(folder/'lower',-1,lower)
def forbidden(*args,**kw):raise AssertionError('No solver/full reassembly is allowed during selection')
upper,lower=pair(ROOT/'pair');upper_closer=pair(ROOT/'upper_case',YR+.0001,YR-.003)
ambiguous=pair(ROOT/'ambiguous_case',YR+.001,YR-.00100005)
with patch('smatrix_bootstrap.sdp.sdpb.execute',forbidden),patch.object(Pmp,'__init__',forbidden):
    assert cli.main(['ir-select','--source-report',str(upper),'--compare-report',str(lower),'--out',str(ROOT/'pair/receipt')])==0
    receipt=ROOT/'pair/receipt/report.json';selected=json.loads(receipt.read_text())
    assert selected['selection']['selected']=='lower'
    assert S.verify_ir_selection(receipt,lower)['revalidated']
    assert S.select_ir(*upper_closer,ROOT/'upper_case/receipt')['selection']['selected']=='upper'
    assert cli.main(['ir-select','--source-report',str(ambiguous[0]),'--compare-report',str(ambiguous[1]),'--out',str(ROOT/'ambiguous_case/receipt')])==1
    try:S.verify_ir_selection(ROOT/'ambiguous_case/receipt/report.json',ambiguous[0])
    except ValueError:pass
    else:raise AssertionError('Ambiguous receipt accepted for delivery')
    moved=ROOT/'relocated';shutil.copytree(ROOT/'pair',moved)
    assert S.verify_ir_selection(moved/'receipt/report.json',moved/'lower/report.json')['revalidated']
    bad=copy.deepcopy(selected);bad['selection']['selected']='upper';dump(ROOT/'pair/receipt/tampered.json',bad)
    try:S.verify_ir_selection(ROOT/'pair/receipt/tampered.json',upper)
    except ValueError:pass
    else:raise AssertionError('Tampered choice accepted')
    try:S.verify_ir_selection(receipt,upper)
    except ValueError:pass
    else:raise AssertionError('Unselected IR leaf accepted')
rejects=[]
for name in ('pending','direction','spec','basis','missing_local_basis','pmp_hash','matrix','normalization','objective'):
    folder=ROOT/('bad_'+name);shutil.copytree(ROOT/'pair',folder)
    path=folder/'lower/report.json';r=json.loads(path.read_text())
    if name=='pending':r['status']='solving'
    if name=='direction':r['direction']=[0.,1.]
    if name=='spec':r['spec']['chi_caliber']='chi-b'
    if name=='basis':
        V=np.load(folder/'lower/basis.npy');V[0,0]+=1e-3;np.save(folder/'lower/basis.npy',V);r['basis']['sha256']=sha(folder/'lower/basis.npy')
    if name=='missing_local_basis':(folder/'lower/basis.npy').unlink()
    if name=='pmp_hash':(folder/'lower/pmp.json').write_text((folder/'lower/pmp.json').read_text()+' ')
    if name in ('matrix','normalization','objective'):
        p=folder/'lower/pmp.json';doc=json.loads(p.read_text())
        if name=='matrix':doc['PositiveMatrixWithPrefactorArray'][0]['polynomials'][0][0][0][0]='123'
        if name=='normalization':doc['normalization'][0]='2'
        if name=='objective':doc['objective'][0]='1'
        dump(p,doc);r['pmp']['sha256']=sha(p)
    dump(path,r)
    try:S.evaluate_pair(folder/'upper/report.json',path,folder/'new_receipt')
    except ValueError as exc:rejects.append({'case':name,'error':str(exc)})
    else:raise AssertionError('Inconsistent pair accepted: '+name)
obs={}
for wave,name in delivery.IR_REFERENCES.items():
    data=load_csv(name);m=data['group']=='ir_magenta'
    obs[wave]={'E_GeV':data['energy_gev'][m].tolist(),'delta_deg':data['phase_deg'][m].tolist(),'eta':[.99]*int(m.sum())}
s=np.linspace(.05,3.95,40);sub={'s':s.tolist(),'S0':((2*s-1)*XR/5).tolist(),'P1':((s-4)*XR/15).tolist(),'S2':((2-s)*XR/5).tolist()}
for path in (upper,lower):
    r=json.loads(path.read_text());r.update(observables=obs,subthreshold=sub);dump(path,r)
phase_receipt=ROOT/'pair/receipt_with_phase_arrays'
again=S.select_ir(upper,lower,phase_receipt)
assert again['selection']['selected']==selected['selection']['selected']
assert all(again['selection']['endpoints'][k]['distance']==selected['selection']['endpoints'][k]['distance'] for k in ('upper','lower'))
try:S.verify_ir_selection(receipt,lower)
except ValueError:pass
else:raise AssertionError('Receipt failed to detect source byte changes')
uv={}
for name,d,f,x in [('tip',[1.,0.],None,.1),('ref',[0.,1.],XR,XR),('mid',[0.,1.],(.1+XR)/2,(.1+XR)/2)]:
    p=leaf(ROOT/'UV'/name,1,YR,uv=True,fixed=f,x=x,direction=d);r=json.loads(p.read_text())
    r.update(observables=obs,subthreshold=sub);dump(p,r);uv[name]=r
dump(ROOT/'UV/report.json',{'reports':uv})
with patch('smatrix_bootstrap.sdp.sdpb.execute',forbidden):
    args=['contrast','--ir-selection-report',str(phase_receipt/'report.json'),'--ir-report',str(lower),'--uv-report',str(ROOT/'UV/ref/report.json'),'--reference-only','--out',str(ROOT/'partial_contrast')]
    assert cli.main(args)==0
    full=delivery.deliver(lower,ROOT/'UV/report.json',ROOT/'full_contrast',ir_selection_report=phase_receipt/'report.json')
    assert full['paper_state_comparison_complete'] and not full['incomplete_registered_chain']
    assert full['available_points']['IR']==['ref'] and set(full['available_points']['UV'])=={'tip','ref','mid'}
    assert full['same_basis'] and not full['matched_objective_causal_comparison_supported']
    assert set(full['matched_objectives'])=={'tip','ref','mid'}
    assert full['C4']['verdict']=='pass' and full['C4_legacy']['verdict']=='FAIL'
    assert full['selected_ir_diagnostics']['applied_threshold'] is None and not full['selected_ir_diagnostics']['complete_C3']
    partial=json.loads((ROOT/'partial_contrast/report.json').read_text())
    assert partial['incomplete_registered_chain'] and not partial['main_contrast_pass']
    assert partial['C6']['verdict']==partial['C7']['verdict']=='not run'
    try:cli.main(['support','--ir-selection-report',str(receipt),'--out',str(ROOT/'invalid_cli')])
    except SystemExit:pass
    else:raise AssertionError('Selection receipt option accepted on wrong command')
result={'synthetic_only':True,'scientific_solves':0,'real_endpoint_or_phase_data_read':False,
        'geometry_cases':['lower closer','upper closer','gap ambiguous','relative relocation','choice tamper rejected','unselected leaf rejected'],
        'matrix_and_endpoint_rejects':rejects,'phase_fields_absent_and_then_added_do_not_change_choice':True,
        'source_byte_tamper_rejected':True,'single_selected_IR_plus_UV_triplet_supported':True,
        'opposite_IR_UV_objectives_not_causal':True,'C4_source_active_and_legacy_retained':True,
        'Weinberg_RMS_has_no_8percent_gate':True,'producer_sha256':sha(__file__)}
dump(ROOT/'VALIDATION.json',result);print(json.dumps({'validation':str(ROOT/'VALIDATION.json'),'passed':True}))
