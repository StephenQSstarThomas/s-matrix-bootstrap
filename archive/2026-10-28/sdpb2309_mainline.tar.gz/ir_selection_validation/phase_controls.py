"""Published-reference controls; no solved lower-endpoint phase data is read."""
import json
from pathlib import Path
import numpy as np
from smatrix_bootstrap.sdp import claims,delivery
from smatrix_bootstrap.sdp.figures import load_csv

assert hasattr(delivery,'c4_source'),'Fig7 source acceptance is missing'
obs={}
for wave,name in delivery.IR_REFERENCES.items():
    data=load_csv(name);m=data['group']=='ir_magenta'
    obs[wave]={'E_GeV':data['energy_gev'][m].tolist(),'delta_deg':data['phase_deg'][m].tolist()}
own=delivery.c4_source(obs)
shifted={w:dict(v,delta_deg=(np.asarray(v['delta_deg'])+11).tolist()) for w,v in obs.items()}
bad=delivery.c4_source(shifted)
assert own['verdict']=='pass' and bad['verdict']=='FAIL'
assert all(r['endpoint_energy_GeV']<1.2 for r in own['rows'])
assert claims.c4({'ref':obs})['rows'][0]['delta00_0.9GeV']<85
uv={}
for point,group in claims.PAIRING.items():
    uv[point]={}
    for wave,file in [('S0','figure10_s0_phases.csv'),('S2','figure10_s2_phases.csv')]:
        data=load_csv(file);m=data['group']==group
        uv[point][wave]={'E_GeV':data['energy_gev'][m].tolist(),'delta_deg':data['phase_deg'][m].tolist()}
source_c7=delivery.c7_source(uv)
assert source_c7['verdict']=='pass' and all(r['endpoint_energy_GeV']<1.196 for r in source_c7['rows'])
assert all('eta' not in series for point in uv.values() for series in point.values())
bad_c7=delivery.c7_source({p:{w:dict(v,delta_deg=(np.asarray(v['delta_deg'])+11).tolist()) for w,v in waves.items()} for p,waves in uv.items()})
assert bad_c7['verdict']=='FAIL'
x=.073;s=np.array([.5,1,1.5,2,3.])
record={'verification':{'f00_3':x},'subthreshold':{'s':s.tolist(),'S0':((2*s-1)*x/5).tolist(),
    'P1':((s-4)*x/15).tolist(),'S2':((2-s)*x/5).tolist()}}
linear=delivery.ir_linearity(record)
assert max(r['rms_over_f00_3'] for r in linear['waves'].values())<1e-14
assert linear['applied_threshold'] is None and not linear['complete_C3']
result={'source_self_pass':own,'uniform_11_degree_offset_fail':bad,'linearity_identity':linear,
        'C7_reference_self_pass_without_eta':source_c7,'C7_uniform_11_degree_offset_fail':bad_c7,
        'source_endpoint_not_extrapolated_to_1p2':True,'real_lower_phase_read':False,'phase_reference_eta_inferred':False}
Path(__file__).with_name('phase_validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source_self_pass':True,'offset11_fail':True,'no_Weinberg_8percent_gate':True}))
