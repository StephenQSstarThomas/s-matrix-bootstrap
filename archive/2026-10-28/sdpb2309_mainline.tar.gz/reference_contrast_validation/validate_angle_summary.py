"""CLI summary separates integration agreement from physical unitarity."""
import json
from pathlib import Path
from smatrix_bootstrap.sdp import __main__ as cli

assert hasattr(cli,'_angle_summary'),'Explicit angular agreement summary is missing'
record={'status':'completed','passed':True,'selected_rows':[[0,0,0],[0,20,0],[1,21,0]],
        'results':[{'unitarity_verdict':'pass'},{'unitarity_verdict':'fail'},{'unitarity_verdict':'fail'}]}
summary=cli._angle_summary(record,'synthetic_out')
assert summary['integrators_agree'] is True and 'passed' not in summary
assert summary['selected_unitarity_counts']=={'pass':1,'fail':2,'inconclusive':0,'not_applicable':0}
partial={'status':'partial','passed':False,'selected_rows':[[0,0,0],[1,1,0],[2,0,0]],
         'results':[{'unitarity_verdict':'inconclusive'},{'unitarity_verdict':'not_applicable_below_threshold'}]}
p=cli._angle_summary(partial,'synthetic_out')
assert p['selected_unitarity_counts']=={'pass':0,'fail':0,'inconclusive':1,'not_applicable':1}
assert p['selected_unitarity_not_evaluated']==1 and p['integrators_agree'] is False
Path(__file__).with_name('ANGLE_SUMMARY_VALIDATION.json').write_text(json.dumps({'synthetic_only':True,'passed':True,'complete_summary':summary,'partial_summary':p},indent=2)+'\n')
print(json.dumps({'passed':True,'complete_summary':summary,'partial_summary':p},indent=2))
