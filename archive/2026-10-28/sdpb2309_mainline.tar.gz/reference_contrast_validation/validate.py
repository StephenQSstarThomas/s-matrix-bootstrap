"""Synthetic reference-contrast acceptance/rejection controls; no physical runs."""
import copy,hashlib,json
from pathlib import Path
from smatrix_bootstrap.sdp import constraints as C,delivery
from smatrix_bootstrap.sdp.spec import ModelSpec

BASE=Path(__file__).resolve().parent
index=1
while (BASE/f'run_{index:02d}').exists():index+=1
ROOT=BASE/f'run_{index:02d}';ROOT.mkdir();XR=C.chiral_reference_point()[0]
def leaf(uv):
    spec=ModelSpec(M=50,L=10,chiral=True,chi_caliber='chi-c',uv=uv,sr_caliber='SR-a',
                   ff_frozen_at_s0=False,reduce_basis=True,operator_dps=40,
                   scattering_prescription='sine-cardinal').__dict__
    waves={w:{'E_GeV':[.28,.6,.9,1.1994],'delta_deg':v,'eta':[1.,.98,.97,.96]}
           for w,v in [('S0',[0.,50.,95.,105.]),('S2',[0.,-10.,-20.,-25.]),('P1',[0.,10.,15.,20.])]}
    checks={k:True for k in ['unitarity','chiral','section']+(['rho_nonnegative','gram','fesr','ff'] if uv else [])}
    return {'solver':'SDPB','status':'numerically_accepted','accepted':True,'spec':spec,
            'direction':[0.,1.],'fix_f00':XR,'convergence':{'solver_optimal':True},
            'verification':{'primal_feasible':True,'f00_3':XR,'constraint_checks':checks,
                            'source_audit':{'scattering_prescription':'sine-cardinal'}},'observables':waves}
def write(name,doc):
    p=ROOT/(name+'.json');p.write_text(json.dumps(doc));return p
ir,uv=leaf(False),leaf(True)
ip,up=write('synthetic_IR_ref',ir),write('synthetic_UV_ref',uv)
out=delivery.deliver(ip,up,ROOT/'leaf_positive',reference_only=True)
assert out['incomplete_registered_chain'] is True and out['main_contrast_pass'] is False
assert out['C6']['verdict']==out['C7']['verdict']=='not run'
assert set(out['rho']['IR'])==set(out['rho']['UV'])=={'ref'}
assert out['C4']['decisive_point']=='ref'
assert all((ROOT/'leaf_positive'/p).exists() for p in ('phases.pdf','phases.png','inelasticity.pdf','inelasticity.png'))
aggregate=write('synthetic_UV_aggregate',{'reports':{'ref':uv}})
assert delivery.load_reference(aggregate)=={'ref':json.loads(up.read_text())}
rejects=[]
for name,change in [
    ('missing acceptance',lambda r:r.pop('accepted')),
    ('live status',lambda r:r.update(status='solving')),
    ('malformed source audit',lambda r:r['verification'].update(source_audit='accepted')),
    ('malformed primal flag',lambda r:r['verification'].update(primal_feasible='true')),
    ('missing model field',lambda r:r['spec'].pop('B')),
    ('wrong direction',lambda r:r.update(direction=[1.,0.])),
    ('wrong section',lambda r:r.update(fix_f00=XR+.001)),
    ('nonfinite section',lambda r:r.update(fix_f00=float('nan'))),
    ('wrong verified coordinate',lambda r:r['verification'].update(f00_3=XR+.001)),
    ('missing source audit',lambda r:r['verification'].pop('source_audit')),
    ('missing FF acceptance',lambda r:r['verification']['constraint_checks'].pop('ff')),
    ('failed Gram acceptance',lambda r:r['verification']['constraint_checks'].update(gram=False)),
    ('mixed contract',lambda r:r['spec'].update(chi_caliber='chi-b')),
    ('mixed family',lambda r:r['spec'].update(scattering_prescription='mixed-pv')),
    ('partial UV',lambda r:r['spec'].update(uv_parts=['gram','fesr'])),
    ('B added',lambda r:r['spec'].update(B=100)),
    ('malformed observable',lambda r:r['observables']['P1'].update(eta=[1.])),
]:
    bad=copy.deepcopy(uv);change(bad)
    try:delivery.deliver(ip,write('bad_'+name.replace(' ','_'),bad),ROOT/('reject_'+name.replace(' ','_')),reference_only=True)
    except ValueError as exc:rejects.append({'case':name,'error':str(exc)})
    else:raise AssertionError('Malformed reference accepted: '+name)
try:delivery.deliver(ip,up,ROOT/'full_incomplete')
except ValueError as exc:rejects.append({'case':'full mode still requires tip/ref/mid','error':str(exc)})
else:raise AssertionError('Full mode accepted two leaves')
def fullchain(reference):
    chain={name:copy.deepcopy(reference) for name in ('tip','ref','mid')}
    chain['tip'].update(direction=[1.,0.],fix_f00=None)
    chain['tip']['verification']['f00_3']=.1
    chain['mid']['fix_f00']=(.1+XR)/2
    chain['mid']['verification']['f00_3']=(.1+XR)/2
    return {'reports':chain}
full=delivery.deliver(write('synthetic_full_IR',fullchain(ir)),write('synthetic_full_UV',fullchain(uv)),ROOT/'full_positive')
assert full['incomplete_registered_chain'] is False and full['missing_registered_points']==[]
assert set(full['rho']['UV'])=={'tip','ref','mid'}
inactive=copy.deepcopy(ir);inactive['spec'].update(sr_caliber='SR-b',ff_frozen_at_s0=True)
assert delivery.deliver(write('synthetic_IR_inactive_difference',inactive),up,ROOT/'inactive_IR_positive',reference_only=True)['incomplete_registered_chain']
report={'synthetic_only':True,'physical_calculations':0,'reference_leaf_positive':True,
        'reference_aggregate_positive':True,'plots_created':True,'reject_controls':rejects,
        'full_chain_positive':True,'inactive_IR_UV_settings_may_differ':True,
        'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'delivery_sha256':hashlib.sha256(Path(delivery.__file__).read_bytes()).hexdigest()}
(ROOT/'VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
