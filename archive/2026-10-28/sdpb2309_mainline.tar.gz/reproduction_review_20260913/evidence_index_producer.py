"""Read-only report evidence indexing; no optimizer or running-leaf reads."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import re

HERE = Path(__file__).resolve().parent
RUN = HERE.parent
REPO = Path('/home/shiqiu/s-matrix-bootstrap')
REPORT = HERE / 'REPORT_ZH.md'
FORBIDDEN = ()


def sha(path):
    assert not any(x in str(path) for x in FORBIDDEN)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(rel):
    assert not any(x in rel for x in FORBIDDEN)
    return json.loads((RUN / rel).read_text())


text = REPORT.read_text()
files = {REPORT, Path(__file__).resolve()}
files.update(HERE.glob('*.csv'))
links = re.findall(r'\[[^\]]*\]\(([^)]+)\)', text)
for target in links:
    if '://' not in target:
        path = (HERE / target.split('#')[0]).resolve()
        assert path.is_file(), f'Missing local citation: {target}'
        files.add(path)
for pattern in ('figure3_boundary.*', 'figure5_subthreshold.*',
                'figure7_*phases.*', 'figure8_boundary.*',
                'figure9_*phases.*', 'figure10_*phases.*', 'figure11_*phases.*'):
    files.update((REPO / 'references').glob(pattern))
files.add(REPO / 'references/2309.12402v3-source/prd_submission_2.tex')
files.add(RUN / 'IR_M50_L12_section_lo/report.json')
for rel in ('foundations_normalization_review/validation.json',
            'foundations_normalization_review/calculation_record.json',
            'canonical_amplitude_export_20260913/MANIFEST_SHA256.json',
            'legacy_report_retirement_20260913/RED.json'):
    files.add(RUN / rel)

selection = read('IR_L12_GEOMETRIC_SELECTION/report.json')['selection']
upper, lower = (selection['endpoints'][key] for key in ('upper', 'lower'))
uv = read('FIRST_SOURCE_UV_L12.json')
region = read('REFERENCE_REGION_COMPARISON/report.json')
self_audit = read('paper_acceptance_self_audit_20260913/PAPER_SELF_AUDIT.json')
contrast = read('SOURCE_L12_PAPER_STYLE_REFERENCE/report.json')
derived = {
    'IR_section_width': {
        'value': upper['projection'][1] - lower['projection'][1],
        'formula': 'IR upper y minus IR lower y; same x_ref and basis',
        'source': 'IR_L12_GEOMETRIC_SELECTION/report.json#/selection/endpoints',
    },
    'UV_upper_boundary_lowering': {
        'value': upper['projection'][1] - uv['projection']['y'],
        'formula': 'IR upper y minus UV upper y; positive means UV y is lower',
        'source': ['IR_L12_GEOMETRIC_SELECTION/report.json', 'FIRST_SOURCE_UV_L12.json'],
    },
    'Fig8_convex_hull_section': region['paper_marker_sections'],
    'Fig8_ordered_branch_section': {
        'IR_width': self_audit['C2']['width'],
        'branches': self_audit['C5']['branches'],
        'upper_shrink': self_audit['C5']['upper_shrink'],
        'scope': 'same figure8_boundary.csv; distinct geometric estimator from convex hull',
    },
}
assert math.isclose(derived['IR_section_width']['value'], .007935698250273512, abs_tol=1e-18)
assert math.isclose(derived['UV_upper_boundary_lowering']['value'], 3.599802826869097e-5, abs_tol=1e-18)
assert upper['distance_interval'][1] < lower['distance_interval'][0]
assert selection['selected'] == 'upper' and selection['phase_data_used'] is False
assert contrast['same_basis'] and contrast['matched_objective_causal_comparison_supported']
assert not contrast['main_contrast_pass'] and contrast['incomplete_registered_chain']
assert contrast['C4_source']['verdict'] == 'FAIL'
assert contrast['C6']['verdict'] == contrast['C7_source']['verdict'] == 'not run'
assert contrast['rho']['UV']['ref']['low_energy_crossing_GeV'] is None

table_width = None
table_count = 0
for line in text.splitlines():
    if line.startswith('|'):
        width = line.count('|')
        if table_width is None:
            table_width = width
            table_count += 1
        assert width == table_width, f'Malformed Markdown table: {line}'
    else:
        table_width = None
assert text.count('<!-- pagebreak -->') == 9
assert '222 passed，77.18 s' in text
assert '222 passed in 77.18s' in (RUN / 'same_M_cross_L_basis_implementation_20260913/FULL_TESTS.txt').read_text()

entries = []
for p in sorted(files):
    assert p.is_file(), p
    try:
        relative = str(p.relative_to(RUN))
        root = 'runroot'
    except ValueError:
        relative = str(p.relative_to(REPO))
        root = 'repository'
    entries.append({'root': root, 'path': relative, 'bytes': p.stat().st_size, 'sha256': sha(p)})
result = {
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Documentation synthesis and scalar checks only; no optimizer or lower-phase evaluation; completed calibrated IR/threeUV and C5 scalar section included.',
    'report': {'file': REPORT.name, 'sha256': sha(REPORT), 'bytes': REPORT.stat().st_size,
               'page_units': 10, 'markdown_tables': table_count},
    'source_roots': {'repository': str(REPO), 'runroot': str(RUN)},
    'scientific_inputs': 'Unmodified. Large PMP/basis/y hashes remain bound by the cited accepted leaf reports; this producer only hashes listed evidence files.',
    'pending_excluded_paths': list(FORBIDDEN),
    'derived_quantities': derived,
    'historical_nominal_metrics': {k: contrast[k] for k in ('C4_source', 'C7_source', 'rho', 'selected_ir_diagnostics')},
    'selected_current_metrics': read('FPI_CALIBRATED_FULL_CONTRAST/VALIDATION.json'),
    'calibrated_C5_section': read('FPI_CALIBRATED_C5_SECTION/report.json'),
    'checks': {'all_local_links_exist': True, 'markdown_tables_consistent': True,
               'same_basis_and_objective_disclosed': True, 'geometry_intervals_separated': True,
               'incomplete_chain_preserved': True, 'actual_test_log_checked': True,
               'scalar_values_match_saved_records': True},
    'files': entries,
}
(HERE / 'EVIDENCE_INDEX.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': True, 'files': len(entries), 'report_bytes': REPORT.stat().st_size,
                  'page_units': 10, 'report_sha256': sha(REPORT)}, ensure_ascii=False))
