# He–Kruczenski 2309.12402v3：当前 SDP 复现的综合研究审查

**2026-09-13 综合审查｜SDPB-only、finite sine-cardinal、无 B。** 已纳入名义UV tip、相邻χ=.001试验，以及按fπ校准的χ=.00021两IR截面和几何选定幅度。该IR幅度的原式验收、阈下曲线、相位与独立积分已完成；同容差的UV tip/ref/near已完成完整对比，C4/C6/C7均FAIL；C5上下截面也已完成，但收缩不对称方向与论文相反。

## 1. 首页结论：复现尚未完成，内部方法与截断问题仍在

**现在不能把偏差归结为“只缺作者参数”，也不能声称已经反驳论文。** 已完成的有限问题能够通过保存输入和原式的数值验收，但当前振幅的低能形状、允许区域和未约束高分波仍与目标有实质差异。作者未公开的插值、范数和选点约定确实存在；与此同时，本实现自己的有限插值、浮点 SVD 保留空间、分波截断及代表工作流的稳定性尚未消除。两类缺口必须同时保留。

最直接的内部反例是**未约束分波的幺正性违反**。M50/L10 的 UV 参考幅度，在原生能量节点上有 I=0、ℓ=20 的 |S|=52.9057，以及 I=1、ℓ=21 的 |S|=1.84553。M50/L12 虽增加了分波，I=0、2 的首个遗漏 ℓ=24 仍有 |S|=7.85590、5.76876。独立原始角积分与生产核吻合。这些不是图像误差、相移分支或求解器末位误差；它们说明这些冻结振幅的分波截断没有受到控制。它们也不等于所声明的有限 PMP 在其已施加行上不可行。[遗漏 L10](../source_UV_first_omitted_waves/report.json)、[遗漏 L12](../source_UV_L12_first_omitted_waves/report.json)

第二项决定性事实是**IR 偏差先于 UV 信息出现**。共同基底 M50/L12 的两端点在固定 x=f00(3)=x_ref 截面上完成求解，几何选择仍取 upper。这个已选 IR 幅度与论文 Fig.7 的 S0、S2、P1 相移 RMS 分别为 49.32°、28.36°、15.40°，三波均未通过源图比较。它的阈下 S0 对同 x_ref 的 Weinberg 直线偏差也很大。因此不应先把失败归于 FESR 或 P1 的 UV 传递机制。[完成对照](../SOURCE_L12_PAPER_STYLE_REFERENCE/report.json)

第三项是**数值修复没有自动变成物理修复**。L12 的 192-bit Cholesky(Q) 故障，用逐字节相同 PMP/basis 的 320-bit 重算得到完成态；gap≈5.25×10⁻⁷，原式数值验收通过。所得 UV ref 在 0.28–1.2 GeV 原生节点相位读数中仍无首次 90° 穿越，P1 最小 η≈0.275914。提高精度已解决该次算术失败，没有消除这些物理差异。[完成记录](../FIRST_SOURCE_UV_L12.json)

| 当前事实 | 能支持的结论 | 不能支持的结论 |
|---|---|---|
| 同位旋、1/4 投影、8π² 与 κ 通过独立控制 | 已排除所查范围内的整体规范化错误 | 全管线不存在任何实现缺陷 |
| 原生约束数值验收通过 | 保存的有限候选满足既定误差口径 | 全能量、全分波幺正；独立严格对偶最优界 |
| IR/UV L12 保存基底完全相同 | 同目标同截面的有限问题上侧收缩可比较 | 被 SVD 删去的方向无影响 |
| upper 比 lower 更接近黑点，数值包络分离 | 两个截面端点中的几何选择稳定 | 全边界最近点、近 Weinberg 资格或代表唯一性 |
| 222 项测试通过，完整振幅可精确导出 | 工程回归与数据身份有证据 | C1–C8 / Fig.3–11 已完成 |

新增名义 UV tip 已数值通过，ρ 相位穿越却在545.17 MeV，P1 minη≈.9324；首遗漏 I0、ℓ20 的 ∣S∣≈55.2958，独立角积分吻合。相邻χ=.001的IR tip仍达x≈.40379。名义精度、tip选择以及单次减半容差均未恢复论文区域和相位。[15]

论文主链仍缺纯区域、多 ε 区域、三 ε 阈下幅度、完整纯／手征／UV边界、五种M/L的对应幅度。校准M50/L12的一IR＋三UV状态对比已完成，C4/C6/C7仍FAIL。新交付写着 `paper_state_comparison_complete=true`、`paper_state_comparison_pass=false`；`incomplete_registered_chain=true`专指未完成旧算术mid登记，不能再解释为缺新near。旧 Newton / Clarabel / B 结果不填入任何缺项。对原文的物理结论，应继续区分“此有限复现未得到”与“论文原问题不可能得到”。

<!-- pagebreak -->

## 2. 底层物理链：已核对的恒等式与它们的范围

[1] 本报告以 [2309.12402v3 PDF](https://arxiv.org/pdf/2309.12402v3) 为唯一目标版本；下述页码为从 1 开始的 PDF 页序，同时与文内页码一致。论文第 7 页取 mπ=1，恢复单位采用 mπ≈140 MeV、fπ≈92 MeV。第 8 页式 (2.6a–c)、第 9 页式 (2.9–2.12) 给出

\[
T^0=3A_s+A_t+A_u,\quad T^1=A_t-A_u,\quad T^2=A_t+A_u,
\]
\[
f_\ell^I(s)=\frac14\int_{-1}^{1}P_\ell(\mu)T^I(s,t,u)\,d\mu,
\quad t=-\frac{s-4}{2}(1-\mu),\quad u=4-s-t,
\]
\[
S_\ell^I=1+i\kappa(s)f_\ell^I=\eta_\ell^I e^{2i\delta_\ell^I},
\qquad \kappa=\pi\sqrt{\frac{s-4}{s}},\qquad |S|\le1.
\]

这里 A_s=A(s,t,u)、A_t=A(t,s,u)、A_u=A(u,t,s)。令 h=κf，严格有 Re S=1−Im h、Im S=Re h，以及 1−|S|²=2 Im h−|h|²；这也是 PMP 散射锥和原式审计的共同物理条件。[原文第 8–9 页](https://arxiv.org/pdf/2309.12402v3#page=8)

第 10 页式 (2.17–2.18) 与脚注 7 明确振幅相对于常见散射 M 的 1/(8π²) 规范化。设 F=fπ/mπ=23/35、c=1/(8π²F²)，Weinberg 振幅 A=c(s−1) 给出 T⁰=c(2s−1)、T¹=c(s−4)μ、T²=c(2−s)。由 ∫1=2、∫μ²=2/3 得

\[
f_0^0=\frac{2s-1}{16\pi^2F^2},\quad
f_1^1=\frac{s-4}{48\pi^2F^2},\quad
f_0^2=\frac{2-s}{16\pi^2F^2}.
\]
\[
x_{\rm ref}=f_0^0(3)=\frac{6125}{8464\pi^2}
=0.07332139057293464675,\qquad
y_{\rm phys}=-x_{\rm ref}/15=-0.00488809270486230978.
\]

这排除了把 92 MeV 当作无量纲 F、把 s=3 当作 3 GeV、遗漏 8π² 或 1/4 的简单解释。固定 x_ref 只固定一个分波的一个阈下值，并未同时固定黑点的 y，更没有固定其它能量上的共同斜率。树级 f 为实数，代入完整 S 定义会在所忽略的高阶产生 |S|>1；这不是归一化错误。相位只有 δ→δ+kπ 保持同一 S，不能用任意换支修正几十度的差异。[原文第 10 页](https://arxiv.org/pdf/2309.12402v3#page=10)

第 22 页式 (3.63–3.64) 的两类残差为

\[
r_{01}=f_0^0-\frac{3(2s-1)}{s-4}f_1^1,\qquad
r_{21}=f_0^2-\frac{3(2-s)}{s-4}f_1^1,
\quad s\in\{\tfrac12,1,\tfrac32,2\}.
\]

生产器按交错顺序存储，再分别取两组四维 L2 范数；χ 使用裸 f，没有误乘物理区 κ。原文只规定“某种范数”，没有唯一指定 L2、L∞ 或权重。更关键的是第 23 页明确说四点关系不强制整个区间线性或树级散射长度。χ 通过与近 Weinberg 之间，需要实际阈下幅度检查，不能在逻辑上直接跳过。[原文第 22–23 页](https://arxiv.org/pdf/2309.12402v3#page=22)

[3] 源码对应关系保存在 [独立归一化报告](../foundations_normalization_review/REPORT_ZH.md) 和其带哈希计算记录：当前 sine 主线是 `sine.py → precision.assemble_rows → precision_pmp/pmp → arbaudit`；保留的 `projector.py` mixed-PV 检查不能单独证明 sine 主线。该审查对原 L10 IR 冻结幅度用完整 y 和 basis 独立重建：S0 在 E≈0.402349 GeV 的复 S 与保存值相差约 4.06×10⁻¹⁶；χ 两组约为 0.00199999960、0.00199999964，但阈值 f00≈0.3701，相对于 Weinberg≈0.10265 已明显变形。此 L10 数值只用于归一化反例，不冒充后续 L12 的测量。

<!-- pagebreak -->

## 3. 解析族、源精度与保留空间：已修复什么，尚未控制什么

论文第 9 页式 (2.7) 的 Mandelstam 单、双谱表示要求所有 s/t/u 腿属于同一解析振幅。第 21 页式 (3.58–3.62) 给出 ν₀=0 的映射、半格节点及谱坐标，却未完整公布节点之间的散射密度插值。旧mixed-PV的有限有理求和有节点极点，不能与所赋Hilbert值同时作为同一精确有限函数的边界与延拓。归档却明确将off-cut规则称为midpoint approximation；该残量不单独否定其作为共同色散表示的数值近似。当前sine选择也不是论文唯一要求。[25][原文第 9、21 页](https://arxiv.org/pdf/2309.12402v3#page=21)、[此前研究](../deepresearch/REPORT_ZH.md)

当前明确声明有限 sine-cardinal 族：φ_j=π(2j+1)/(2M)，s_j=8/(1+cosφ_j)，

\[
D_{nj}=\frac{2-\delta_{nM}}M\sin(n\phi_j),\qquad
g_j(z)=\sum_{n=1}^{M}D_{nj}\,[z^n-(-1)^n],\qquad
z(\nu)=\frac{2-\sqrt{4-\nu}}{2+\sqrt{4-\nu}}.
\]

有限正弦正交关系使 Im g_j(e^{iφ_k})=δ_jk，最高 n=M 模必须使用半权重。g_j(−1)=0 是基核的减法约定；有自由 T₀ 与单谱补偿时，它本身不等于给完整 A 加新的物理端点等式。同一 g 用于

\[
A=T_0+g(s)\sigma_1+[g(t)+g(u)]\sigma_2
+g(s)\rho_1[g(t)+g(u)]^T+g(t)\rho_2g(u)^T.
\]

ρ₂ 对称，保存上三角包含对角，展开时没有 2 或 √2 因子；ρ₁ 按行顺序保存。M50 有 1+2M+M²+M(M+1)/2=3876 个原散射坐标。与电流谱密度 ρ 的名字相似不意味着变量相同。这个表达式可直接由完整导出复算 crossing 与分波，**仍不能称为恢复了作者的有限插值**。

源精度、PMP 投影与读取完整 y 是一条链。旧 double 输入在 SDPB 内部收敛而源式不通过，说明任意精度求解器不能修复已舍入的源算子。当前采用源算子 40 位、PMP 输出 30 位，原 binary64 basis 每项保留其精确二进制值，完整 SDPB y 文本保留十进制尾数，原式用 Arb 重建 c。保存 NPZ 的 double c 仅供方便读取，不参与高精度物理核验。大系数约 10¹⁶、L1 约 10¹⁹ 时，机器精度 c 可在强消减中失去物理分波。

原式复验并非完全独立实现：它仍共享 SineFamily。补充控制采用独立 mpmath sine 多项式、Horner 收缩和原始 μ∈[−1,1] 积分，覆盖 M4 六例、冻结 M50 三个原生点、后续首遗漏分波。双阶积分一致是经验误差控制；生产 Arb 包络另含其声明的尾界。两者不得混称一个独立严格积分证书。[M4](../foundations_independent_control/report.json)、[冻结 M50](../foundations_M50_angle_check/report.json)

真实实现错误也包括 Arb 对跨零区间求平方曾产生 NaN，现以乘法修复；离节点虚部尾界遗漏后来也已修复。原生 baseline 与三点检查不依赖后者的离节点分支，因此不能把其修复说成重新改变了原生基线。一次修复或大量测试都不足以穷尽未知缺陷。[当前缺陷清单](../LIMITATIONS_FIRST_ZH.md)

还应先排除纯坐标差异，再讨论缺参。如果同一完整基核仅作有限实常量平移 g=h+vᵀ，可保留 R′=R、Q′=Q，以 σ₁′=σ₁+2Rv、σ₂′=σ₂+(Rᵀ+Q)v 及相应 T₀ 补偿严格保持 A；完整 M 模的 DST 也可逆。一般展开与 M1–5 的 1600 组独立精确有理数控制已保存。但非平凡映射中心变化通常不保持固定阶多项式空间；独立重做 SVD 也不自动运输同一子空间。因此只有核实 ν₀ 的实际作用及完整约束变换后，才能称它为可消除坐标，不能凭符号把未知 ν₀ 一概视为物理输入或纯冗余。[条件性等价证明与反例](../subtraction_coordinate_equivalence_20260913/REPORT_ZH.md)

[4] SVD 的责任边界尤其重要。旧 L10 IR/UV 都保留 1781/3876 维，却因锥缩放与 Gram 替换行序不同而产生不同子空间，最大主角正弦约 8.73×10⁻⁵，远大于约 10⁻¹⁵ 的正交误差。构建现已规范化为按原生顺序取未缩放 h 实虚行、有效 mask 包含 Gram 主行、再作行归一化；并支持直接复用已验收 basis。但 SVD 的 10⁻¹² 截断本身仍是有限近似。没有系数范数界时，小投影残差不统一控制被删方向的支持或相位影响。共同 basis 消除了对照中的一项混杂，没有证明精确秩或完整空间最优性。[基底比较](../IR_UV_BASIS_COMPARISON.json)、[修复验证](../common_basis_validation/VALIDATION.json)

<!-- pagebreak -->

## 4. 输入约定与 UV→IR 机制：源文可确定部分与未证实假设

[2] 当前主线使用 χ-c：两组四维未加权 L2，εχ=0.002；SR-a：四个 raw 谱矩各允许绝对误差 0.002；FF 按每个 s_i 的运动学因子约束，εFF=6×10⁻⁵。没有密度正则化 B，没有后续 Watson 迭代。旧 χ-b 合并八维球、相对 10% FESR 和冻结 k(s₀) 的 FF 是不同输入合同，旧结果只作带标签控制。[源文决定与数值核算](../deepresearch/PARAMETER_AUDIT.json)

第 19 页式 (2.54–2.55) 给出 s₀=(1.2 GeV)²、α_s=0.4、m_u=4 MeV、m_d=7.3 MeV 及凝聚估计；第 20 页式 (2.56) 打印归一化谱矩；第 24 页式 (3.72–3.74) 给出中点离散与容差。mπ=1 后 s₀=3600/49。打印矩乘 s₀^(n+2) 回到 raw 矩，不是把截止直接写成 1.2 的一次幂。恢复量纲时 scalar ρ 除 mπ⁴、vector ρ 除 mπ²；两类 raw moment 分别按 mπ^(2n+6)、mπ^(2n+4) 换算。[原文第 19–20 页](https://arxiv.org/pdf/2309.12402v3#page=19)、[第 24 页](https://arxiv.org/pdf/2309.12402v3#page=24)

| 通道、矩阶 | 归一化目标 | raw 目标 | raw 0.002 相对大小 |
|---|---:|---:|---:|
| S0，n=0 | 4.41870×10⁻⁷ | 0.0023851042 | 83.85% |
| S0，n=1 | 2.82014×10⁻⁷ | 0.1118381387 | 1.79% |
| P1，n=−1 | 5.75484×10⁻⁵ | 0.0042280457 | 47.30% |
| P1，n=0 | 2.69948×10⁻⁵ | 0.1457112070 | 1.37% |

这个误差分配不均可以作为近似选择讨论，但“统一绝对数值容差量纲不合法，所以必须改成 10%”不成立。SR-a 和相对盒既非简单等价，也无单向包含。按算术平均质量 5.65 MeV 重算 scalar OPE 矩比打印目标低约 8.48%，RMS 质量 5.886 MeV 的结果低约 0.68%；凝聚打印值与使用 140/92 MeV 的 GMOR 估计也不完全相同。它们属于近似输入和舍入约定待澄清，不允许用相移拟合来选择质量。

第 23 页式 (3.65–3.68) 规定 F(0)=1、Re F_i=1+Σ_jK_ij Im F_j，并逐 s_i 定义 ℱ=kF；第 25 页式 (3.75) 为 s_i>s₀ 的 |ℱ_S0|²≲2m_q²εFF、|ℱ_P1|²≲εFF/2。冻结 k(s₀) 会对 M50 最高节点把 P1 的 |F|² 上界放宽约 239.92 倍；正文在截止处估算 εFF 数量级，不是取消逐节点定义。[原文第 23、25 页](https://arxiv.org/pdf/2309.12402v3#page=23)

连接 UV 谱信息与散射的实际约束是第 24 页式 (3.70) 的 Gram PSD。以正 k 作合同变换，记 ρ̂=ρ/k²，

\[
\widehat G=\begin{pmatrix}1&S&F\\S^*&1&F^*\\F^*&F&\widehat\rho\end{pmatrix}\succeq0,
\quad
\det\widehat G=(1-|S|^2)(\widehat\rho-|F|^2)-|F-SF^*|^2.
\]

这个恒等式严格区分弹性余量、两 pion 谱余量和 Watson 残差。η=1 强制 F=SF*，但不强制 ρ̂=|F|²；ρ̂=|F|² 且 F≠0 则强制 Watson 与弹性。det G=0 单独不够：S=0、F=1、ρ̂=2 是反例。第 19 页的机制解释期待中间能区近似两 pion 饱和及近似弹性；有限数值 PSD 并没有把这两项饱和作为等式施加。四个谱矩也不能唯一恢复形状因子零点或共振。

当前 L12 UV ref 的两 pion 谱矩比例约为 S0：92.42%、92.95%；P1：61.8%、63.6%。这比“Gram 接近奇异，所以机制已实现”的说法更有辨识力，但仍只是当前解的诊断。不能在复现 2309 的名义下新增 B、额外谱密度界或 Watson 目标来强制所希望的结果。[同振幅机制报告](../source_UV_L12_ref_mechanism/report.json)

<!-- pagebreak -->

## 5. 几何选择与同 basis 对照：当前已经闭合到哪一步

论文先在 Fig.4/5 检查阈下幅度，再在 Fig.6 选择靠近物理黑点的边界幅度，画 Fig.7 的 IR 相位；加入 UV 后在 Fig.8 选 tip 及附近两点，画 Fig.9/10。最近边界原则见第 30 页 Fig.6 图注；黑线 y=−x/15 见第 27 页式 (4.79)。固定 x_ref 上端点只是截面代理，不能不经检查就等同全边界最近点。[第 27–30 页](https://arxiv.org/pdf/2309.12402v3#page=27)

[6] geometry-only 选择收据，对两个已完成 IR/no-B/χ/x_ref 端点检查相同 spec、实际 basis、全 PMP 物理块及 normalization，目标必须为精确相反的 (0,+1)/(0,−1)。然后只用到理论点的未加权欧氏距离；不读相位、阈下误差或其它观测量。gap/readback/截面残差产生的保守数值距离包络若重叠即 ambiguous。该包络不是严格对偶区间。[冻结计划](../IR_REFERENCE_GEOMETRY_PLAN.json)、[实际收据](../IR_L12_GEOMETRIC_SELECTION/report.json)

| 项目 | IR upper | IR lower |
|---|---:|---:|
| x=f00(3) | 0.07332139057293464 | 相同 |
| y=f11(3) | −0.002100421085515907 | −0.010036119335789418 |
| 到 Weinberg 点距离 | 0.00278767161935 | 0.00514802663093 |
| 数值距离包络 | [0.00278682065808, 0.00278852258061] | [0.00514759816626, 0.00514845509559] |
| 支持 gap | 8.50961×10⁻⁷ | 4.28465×10⁻⁷ |
| 总耗时 | 2664.19 s（44.4 min） | 2459.74 s（41.0 min） |

两区间分离，选择 upper。收据明说 **closest of these two endpoints, not global closest**；此前 upper 的相位已知，不能追认为完全盲预登记。正确的认识改进是排除了“在本截面两侧中挑错一侧”这个具体解释，未排除其它边界方向更近，也未证明黑点在整个二维区域中的位置和完整振幅唯一性。即使另选到近点，也不能从允许集合中移除已经通过的偏大支持见证。

共同基底 SHA256 为 `e541340318a1eb8c7deeb8c7c9725fae8c270998240a2371a5ff7808a03c8269`，形状 3876×1989。IR upper 与 UV ref 都在该空间、同 x_ref、同方向最大化 y；UV ref y=−0.002136419113784598，因此**上端点降低／上侧收缩 3.59980283×10⁻⁵**。这个差约为两 gap 之和的 26 倍，可作当前数值精度下有限问题的收缩证据；独立严格对偶认证仍为 false。当前没有同合同 UV lower，不能得出完整宽度、下侧收缩或 C5 上下比例。

论文图形几何本身也不是唯一精确求解边界。下面分开列出两种已保存提取口径：

| 数据与几何定义 | x_ref 截面 IR 宽度 | UV 上侧变化或宽度 | 范围 |
|---|---:|---:|---|
| Fig.8 矢量标记中心凸包、分段线性截面 | 0.000766247953 | UV 宽 0.000491163583；上端降低 0.000231773650 | 仅显示点凸包，不是外支持证书 |
| 同一 Fig.8 CSV，按原顺序识别上下分支并作相邻点插值 | 0.00075980504 | 旧 C5 上侧 0.00023238580 | 保留原采样与算法身份 |
| 当前 M50/L12、共同 basis 的两 IR 支持端点 | 0.007935698250 | UV 仅 ref，上端降低 0.0000359980283 | 保存有限候选及数值 gap |

[Fig.8 凸包几何报告](../REFERENCE_REGION_COMPARISON/report.json) 给出 CSV SHA、全部上下端值和算法；[旧门槛源自测](../paper_acceptance_self_audit_20260913/PAPER_SELF_AUDIT.json) 给出第二行的包围节点。两种几何算法作用于同一 `references/figure8_boundary.csv`；IR 下端分别为 −0.00513403432603（凸包）与 −0.00512759141637（原顺序分支），造成两种宽度约 0.8% 的差异。该差异要保留，不能混称论文精确值。当前 IR 截面约大一个数量级，但 L12 与 Fig.8 名义 L10 也不同。名义 L10 UV 已验收 ref 同样远在显示区域上方，这说明单靠重新选择代表不能修复允许集合差异；它不证明作者使用了完全相同的有限函数空间。 支持数据为[原区域图 CSV](region_plot_data.csv)与[同 basis 截面点 CSV](same_basis_section_points.csv)：前者逐字节保留 Fig.8 标记及既有 UV L10/L12 点，后者列理论目标、完成的 IR upper/lower 和 UV ref，两个几何口径分别保留。

<!-- pagebreak -->

## 6. 完成相位与遗漏分波：物理失败和数值验收并列报告

[7] 已完成的 [SOURCE_L12_PAPER_STYLE_REFERENCE](../SOURCE_L12_PAPER_STYLE_REFERENCE/report.json) 是 **paper-style-reference-only**：一个按几何选定的 IR 与一个 UV ref，双方 basis 相同且目标匹配。完整纸样比较允许一个已选 IR 对 UV tip/ref/mid，不要求虚构三个 IR；当前还缺 UV tip/mid，不能使 C6、C7 的全三点条件通过。

![已完成的同基底 IR/UV 相移对照](../SOURCE_L12_PAPER_STYLE_REFERENCE/phases.png)

图 1：M50/L12、同 basis 的已选 IR upper 与 UV ref；虚点线为 Fig.7、Fig.9/10 公开相位。连接线仅展示保存节点读数，不代表离节点幺正证书。对应的[相移与 η 数据](same_basis_phase_eta.csv)逐值保留完成叶的 300 个原生读数；[公开相位数据](published_phase_curves.csv)保留六条源曲线的 258 个原始数值，η 留空。

| 量 | IR selected upper | UV ref |
|---|---:|---:|
| P1 原生低能首次 90° 穿越 | 无读数 | 无读数 |
| P1 在 1.2 GeV 以下最小 η | 0.9998727764 | 0.2759136902 |
| 单点 C6 诊断 | 不通过 | 不通过 |
| 与 Fig.7 的 S0/S2/P1 RMS | 49.3211° / 28.3647° / 15.4020° | 不适用：UV 对照为 Fig.9/10 |
| UV ref 对 Fig.10 light_pink 的 S0/S2 RMS | 不适用 | 35.0365° / 27.1541° |

“无穿越”严格指现有节点相位提升和相邻点线性读数中，在 0.28–1.2 GeV 没找到首次 90°；不是对所有中间能量或复平面极点的排除。各波相位来自同一复 S；跨状态比较不能分别换一个更有利的支。图形数据的能量轴使用 139.57 MeV，而代码恢复单位采用原文 140 MeV，相差约 0.31%；报告保留此坐标约定，不以其解释几十度偏差。

选择后保存的 40 点阈下诊断，s∈[0.05,3.95]，对同 f00(3) 的 Weinberg 直线 RMS/f00(3) 为 S0=0.633525、P1=0.0414486、S2=0.213528。它们是描述量，没有新 pass/fail 阈值，未用于几何选择。特别是 C3 的 8% 预算不是这里的资格门槛；一个点的这张表也不完成 Fig.5 三 ε 链。

另一方面，UV L12 p320 的 1800 个原生散射盘有 1725 个严格区间通过、75 个区间含零而 inconclusive、0 个严格失败；全部符合既定数值接受预算。700 个 Gram 主子式、4 个 FESR 和 14 个 FF 项均严格通过。`numerically_accepted` 与全严格 `certified` 的状态不同。独立对偶界未认证，保存结果不能被描述为全空间严格最优。

| 冻结幅度 | 首遗漏波 | 原生节点（零基）及 E | 独立重算 | 幺正性 |
|---|---|---|---:|---|
| UV M50/L10 source ref | I0，ℓ=20 | 42；1.199424 GeV | ∣S∣=52.9056914 | 失败 |
| 同上 | I1，ℓ=21 | 38；0.792136 GeV | ∣S∣=1.84552679 | 失败 |
| UV M50/L12 source ref p320 | I0，ℓ=24 | 42；1.199424 GeV | ∣S∣=7.85589981 | 失败 |
| 同上 | I1，ℓ=25 | 38；0.792136 GeV | ∣S∣=0.992173272 | 该点通过 |
| 同上 | I2，ℓ=24 | 42；1.199424 GeV | ∣S∣=5.76875768 | 失败 |

[8] 上述控制用完整 y×保存 basis，不重求最优、不改约束；独立原始 μ 的两阶参考与生产 SineFamily 相符，L10 总 14.50 s，L12 总 18.37 s。L12 最大源差上界约 1.81×10⁻²⁵，远小于幺正违反。CLI 的 `integrators_agree` 与选定行 `unitarity_verdict` 分开，避免 `passed=true` 被读成物理验收。[L10 记录](../source_UV_first_omitted_waves/report.json)、[L12 记录](../source_UV_L12_first_omitted_waves/report.json)

增加 L 后 |S| 的部分下降不能被宣称为已收敛：L10/L12 保存的低波最大相位变化约 S0=23.88°、P1=14.99°、S2=24.97°，且两者保留 SVD 空间也不同。这个对照同时改变分波约束与有限坐标空间，不能隔离纯 L 效应。[漂移记录](../SOURCE_UV_L10_L12_DRIFT.json) 论文附录第 36–38 页主动比较五种 M/L，并说明 M 同时改变变量与约束；本项目仍未完成同类链。有限原型不必先得到一个全连续定理，但已经发现的巨大遗漏波违反不能省略。

<!-- pagebreak -->

## 7. 验收器先接受源图自检：C3、C4、C7 的具体修正

[9] 复现验收不应把论文自己的曲线判为失败。此次确认的三项问题均保留原代码快照、原预登记和原数据，修正在读取新 lower 相位之前冻结或仅依据源域事实作出。它们没有使当前物理结果通过。

**C4。** 旧条件要求 IR S0 在 0.9 GeV 达到 85–110°，而从 Fig.7 原图提取的作者曲线在该点约为 82.572718°。该旧门槛会拒绝目标自身。新纸样 `C4_source` 用三波到 Fig.7 `ir_magenta` 的共同域 RMS≤10°，再在每波最后一个公开且在当前评价域内的能量检查端点差≤10°。这是与已有相移比较相同级别的操作预算，不是论文统计误差；不外推到 1.2 GeV。旧 `C4_legacy` 保留。[冻结修订](../C4_SOURCE_ACCEPTANCE_AMENDMENT.json)、[原图第 31 页](https://arxiv.org/pdf/2309.12402v3#page=31)

Fig.7 每波有 43 个源节点，当前共同域实际比较 42 个；末点约 1.19574 GeV。名义χ=.002 IR在该末点相对于源图的差分别为 S0=−100.0448°、S2=−4.00933°、P1=−78.2463°。S2 末点单独接近不能覆盖其 28.36° 的全曲线 RMS。源曲线自比通过，全曲线平移 +11° 的负例失败。这是一项有判别能力的验收修复。

**C7。** 旧函数固定在 1.196 GeV 求端点；Fig.10 六条参考曲线的最大能量都略小于它，约为 1.19574 GeV。域保护返回 None 是正确的，取点超域才是错误。论文曲线自比虽 RMS=0，却因此 FAIL。新纸样 `C7_source` 保留 S0=85–110°、S2=−40 至 −15°、RMS≤10°及 tip/ref/mid 全三点集合，只把端点改成每波每色自身最后公开且在域内的能量；旧 C7 保留。[自审查](../paper_acceptance_self_audit_20260913/AUDIT_ZH.md)、[原图第 34 页](https://arxiv.org/pdf/2309.12402v3#page=34)

| Fig.10 源曲线 | S0 最后公开点 | S2 最后公开点 | 新源域自检 |
|---|---:|---:|---|
| red / 本地 tip 对照名 | 99.56569° | −36.40596° | 通过 |
| pink / mid | 87.26008° | −26.35210° | 通过 |
| light_pink / ref | 106.41352° | −18.28435° | 通过 |

名义χ=.002 UV ref在相应末点是 S0≈163.73167°、S2≈−39.39184°，RMS 两波均超 10°。该名义L12三点尚缺，因此其C7总项仍`not run`；这不覆盖后文已经完整执行且FAIL的校准三点C7，不能把一个 ref 失败行变成“完整 C7 已执行”。C6 的 795–845 MeV、三点跨度≤20 MeV、原解 min η≥0.9 保持原值。论文 Fig.9 三色的 90° 读数约为 812.53、824.30、826.62 MeV，跨度 14.09 MeV，与相位部分门槛相容；图中没有完整 η 数值，不能从相移赋 η=1 当源证据。

**C3。** 原有 8% 是“与同 ε 的 Fig.5 彩色曲线比较”的 RMS 预算，不是偏离 Weinberg 直线的 8%。大 ε 曲线本来就是原文展示的非线性对照，第 27 页说明它们不宜作为后续物理基线。真正的实现缺口是保存的 40 点只到 s=3.95，而 Fig.5 有 9 个比较点接近 3.99；`np.interp` 曾静默钳到末点。[第 27–29 页](https://arxiv.org/pdf/2309.12402v3#page=27)

[10] 现有评价器改为旧 40 点 ∪ Fig.5 的 90 个不同横坐标 ∪ s=3，共 131 点；只读参考横坐标，不用参考振幅选择输入或代表。对已选 upper 精确重评 393 个三波值，耗时 16.58 s，旧 40 点的 binary64 显示差逐项为 0，原报告哈希不变。补求报告通过显式 overlay 进入图表，缺少其它 ε 仍不完成 C3。[补评实现与独立控制](../subthreshold_completion_20260913/IMPLEMENTATION_ZH.md)、[实际验证](../subthreshold_completion_20260913/ACTUAL_REPLAY_VALIDATION.json)

这些修正的独立反例与源自比结果见 [选择/交付验证](../ir_selection_validation/VALIDATION.json)。原预登记 SHA256 `3fe62f034bc11e6908a600d0c5e09f0a98504c6befe20f7c86eeb19fb1acfa4a` 未变。新字段不会追认旧 C4/C7 通过，也不会把描述性线性偏差改名为 C3 完成。

<!-- pagebreak -->

## 8. C1–C8、Fig.3–11 与 STATUS A1–F3 的当前对应

下表只描述当前 SDP sine 源文合同。C1–C8 是本项目复现验收编号，不是论文公式；STATUS 的 A1–F3 是仓库任务定义，旧 Newton 已填状态不在此沿用。只有完整幅度、合同和实际 basis 身份相容的记录才能在同一有限问题下合并；M/L 的分辨率对照则必须保留它们有意不同的身份。

| 本地 claim | 论文出处 | STATUS 责任 | 当前证据与缺口 |
|---|---|---|---|
| C1：纯 S 矩阵投影区域 | Fig.3，第 27 页；正文第 26 页 | A1/A3、B1/B2 | 基础算子和支持接口有控制；新源合同下完整方向区域尚缺。scalar λ 标准值不代替 pion 区域。 |
| C2：六 ε 手征区域、端点与截面 | Fig.4，第 28 页；式 (3.64) | A2、B3 | ε=.002 的 L12 两侧完成；六 ε 嵌套、完整区域与名义 L10 支持未齐。两组 L2 是声明范数。 |
| C3：三 ε 阈下曲线与零点 | Fig.5，第 29 页 | C1 | 131 点评价域修复，单个已选 IR 可重放；.002/.004/.006 三组完整对应幅度未齐，8% 门槛不改。 |
| C4：IR-only 物理相位 | Fig.6–7，第 30–31 页 | C2/C3 | 两端点几何选择收据完成；已选 upper 的 C4_source FAIL。全边界最近点与近线性资格仍未证明。 |
| C5：UV 区域收缩 | Fig.8，第 32 页 | D1–D3、E1 | 名义L12上截面降低3.5998e−5；校准上／下截面收缩1.29561e−5／7.95028e−5，比值区间[.150,.174]，与源图6.30方向相反；全边界及名义分辨率未齐。 |
| C6：三点 P1 ρ 与弹性诊断 | Fig.9，第 33 页 | E2/E3 | 校准三UV已齐：tip90°≈911.78MeV，ref/near无原生穿越；minη=.4697/.1406/.1444，C6 FAIL。源相位无法提供η。 |
| C7：三点 S0/S2 相位 | Fig.10，第 34 页 | E2/E3 | 校准三UV集合已齐，六项S0/S2比较均FAIL；near明确不同于旧mid，源域与覆盖保护保留。 |
| C8：五组 M/L 稳定性 | 附录 A，第 36–38 页；Fig.11 第 37 页 | F1/F2 | L10/L12 ref 漂移及遗漏波控制已保存；五组同规则代表未齐，当前不能称分辨率收敛。 |

| STATUS 阶段 | 当前可交付的实质内容 | 仍欠缺的证据 |
|---|---|---|
| A1–A3 | 同一具名解析族、crossing/isospin、χ/QCD 单位、源精度、独立局部投影 | 作者插值身份、截断影响及完整独立实现控制 |
| B1–B3 | SDPB 有限支持、保存 PMP 通用方向/截面复用、完成参考端点 | 纯区域与六 ε 区域的足够边界覆盖及支持身份 |
| C1–C3 | 同幅度阈下补评、几何收据、已选 IR 源图比较 | Fig.5 多 ε 工作流、全边界近点及通过的 IR 比较 |
| D1–D3 | F(0)=1、同 S Gram、raw FESR、node FF 及联合候选原式验收 | 极值解是否实现论文期待的饱和与稳定物理机制 |
| E1–E3 | 同basis的选定IR＋三UV相位/η完整对照，失败已量化 | 完整UV区域、名义分辨率及通过的ρ/相位结果 |
| F1–F3 | 部分漂移/遗漏波、可搬移幅度与哈希、失败可追溯 | 五配置稳定性、所有图表和完整结论链 |

Fig.11 的源数据五配置为 (50,8)、(50,10)、(50,12)、(45,10)、(60,10)。源自测得到 P1 的 90° 读数约 820.12、832.66、831.64、786.55、778.31 MeV；固定 M 的跨度约 12.54 MeV，固定 L 的跨度约 54.35 MeV。论文自己承认 M 变化同时改变变量、幺正节点和 FESR；这些图形漂移不是统计误差条，也不是物理上必须保持某个不收敛下限的定理。附录只公开每配置一套曲线，没有证据要求三代表×五配置共 15 套，也不能把其曲线冒认成 Fig.9 的某个已知颜色幅度。[原文附录](https://arxiv.org/pdf/2309.12402v3#page=36)、[完整源指标](../paper_acceptance_self_audit_20260913/PAPER_SELF_AUDIT.json)

合理的下一步必须对应一个尚未决定的物理问题：例如已有支持见证是否已经把区域推得过宽、指定 ε 是否保留黑点邻域且改善阈下形状、首遗漏波违反在一个最小分辨率改变后是否仍大。先复用保存幅度与 PMP，避免把同一源算子反复装配；不得凭曲线更相似就追认为找到了作者参数，也不把精确秩平台或连续证书新设为完成论文有限原型的必要前置条件。

<!-- pagebreak -->

## 9. 参数查找、已完成试验与物理 fπ 校准

[11] 有界公开检索没有找到 2309 专属求解程序、原始矩阵或完整参数表。作者仓库在固定 commit `801684d9ece3de2918a20145178f569459081098` 的 README 明确说明 2309 当时未发布公开代码，2403 才是首次公开版本。v1/v2/v3 arXiv 源包包含 TeX、文献与图，没有 .m/.nb/.py producer 或 .mat 原矩阵；仓库可见历史、tag、公开 gist、期刊页面和作者主页也未提供所缺对象。这个结论限于已检查公开范围，不声称私人或未索引资料不存在。[作者 README](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/README.md#L85)、[检索记录](../author_implementation_search_20260913/REPORT_ZH.md)

同期 2023-10-24 CERN 讲演可补程序性背景：幻灯第 60 页说使用 fπ≈92 MeV 选适当 χ 容差，第 71 页说按可行性收紧 FESR 容差，第 74 页展示逐节点 FF 界；没有公开具体范数、误差打包或隐藏插值阶数。[讲演页面](https://indico.cern.ch/event/1331655/?view=lecture)、[原幻灯 PDF](https://indico.cern.ch/event/1331655/attachments/2739524/4765108/bootstrapQCD_CERN.pdf)

后续代码只作标明年代的线索。认证 2403 快照的 χ 数据确为本论文规范化的裸 f，未乘 κ、除 Λ 或加四点权重；常数列与 48 项独立单/双谱积分控制给出最大差约 3.40×10⁻⁷²。它使用合并八维 L2，但还有不同 ν₀、能标、密度界和其它波约束，不能据此把 2309 的范数宣布为已恢复。2511 将密度级数阶数与约束节点数分开，是可供诊断的数值线索，不是把后续物理输入导入本线的授权。[χ 权重追踪](../author_implementation_search_20260913/chiral_weight_trace/REPORT_ZH.md)、[后续实现的固定来源](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/theories/qcd/papers/arxiv-2403.10772/GTB_numerics.m#L97)

作者最小可答问题按减少歧义的价值排列如下；这些问题尚未发送，也不以回答为当前内部核验的替代：

1. **散射离散到底是什么？** 对式 (3.61–3.62) 的 M50 节点，密度插值、端点/无穷尾部、最高密度模、角投影规则分别如何定义？若只能分享一个对象，一份 M50 散射算子或 Fig.6 完整幅度比相移图片更有用。
2. **χ 的两个 norm 在运行中如何打包？** 分开还是合并，L2 还是 L∞，是否有逐点/通道权重或均方归一化？给出约束的实际一行表达式即可。
3. **式 (3.74–3.75) 的实际数值表达式是什么？** 确认 raw 0.002、硬截止节点、逐节点 k_i，以及 scalar m_q 的精确质量组合和打印矩是否直接作为目标；无需发送整套私有程序。
4. **Fig.5/6/8/11 各选了哪一个完整边界解？** 提供投影坐标、目标或搜索规则、距离度量与退化面处理；明确 Fig.11 与 Fig.8 三色是否共享代表定义。只给 x_ref 上端点不足以恢复全边界最近点。
5. **发表计算如何控制截断和求解误差？** 分波/密度截断、是否做过消元或 SVD、容差、求解器版本与精度；尤其是否曾检查首遗漏分波的 |S|。没有依据预设作者一定有隐藏 B。

这些回答可能解释剩余差异，但目前同族内的遗漏波失败和阈下非线性必须先如实呈现。不能通过问作者“哪个参数能调到对的 ρ”取代一个可复核的数学合同。

**两项有界试验已完成并通过原式数值验收。**

| 任务 | 已验收结果 | 物理判断 |
|---|---|---|
| 名义 M50/L10 UV tip，χ=.002 | x=.6061065134，y=−.04134905754；gap9.74675e−7；4001.15 s | ρ读数545.174 MeV；S0/S2/P1对论文相位RMS约31.67°/11.74°/42.48°，未复现 |
| 同保存 M50/L12 basis 的 IR tip，χ=.001 | x=.4037901852，y=−.02710509066；gap7.10539e−7；4157.89 s | x远大于物理xref；单独不证明整个黑点准入，也不完成线性或IR相位验收 |

新名义UV tip与旧L10 UV ref的1624个物理PMP块、normalization和basis逐项相同；移除旧ref两条截面约束后摘要一致。可保留为同有限合同不同代表的比较，旧ref缺求解时完整y哈希的记录缺口不追补为已认证事实。tip的P1两pion谱矩比例仅20.62%和10.17%，虽然minη≈.93；弹性接近饱和仍不足以使谱信息按期待传递。原始700个Gram项严格通过，较松的5秒机制诊断有2项极小子式符号未定而无严格失败；其uv_ok=false不推翻原验收。[15]

![名义UV tip/ref的原生相位及η；只有两个代表，未完成三点稳定性。](../nominal_UV_tip_ref_comparison_20260913/comparison.png)

支持数据为[完整原生观测CSV](../nominal_UV_tip_ref_comparison_20260913/saved_observations.csv)与[比较指标](../nominal_UV_tip_ref_comparison_20260913/report.json)。独立角积分核验了两个ρ穿越相邻节点和首遗漏I0、ℓ20；后者∣S∣=55.2958019，19.43秒。[独立核验](../nominal_source_UV_tip_independent_angles/report.json)

[16] 下一容差来自物理fπ的既有幅度见证，不用论文相位拟合。两份同basis IR解与零幅度取u≈.011954389470218、v≈.179412181804531、γ≈.808633428725251，可到达Weinberg黑点。完整y及高精度源式复算的两组χ范数为.000194724286619与.000192844443310；投影误差包络≤1.71e−37与2.71e−40。组合没有被用作边界代表，也没有计算其相移。

[17] 在原生输入数值接受的范围下，凸性与三角不等式给出容差上界.000203320960745；χ=.00021时，显式投影见证域包含黑点周围半径约1.0337e−5的邻域。实际χ也低于论文网格中的.0002；本次保留.00021的保守邻域余量，不为5%差异重跑已冻结试验。它不是作者参数或全空间最小容差，复用论证也不是独立严格的全凸可行证书。

[18] **校准两端已经完成。** 上端44.8分钟、y=−.00442559034316，下端45.9分钟、y=−.00564173901187；在读取新相位前仍按几何选择upper。两者完整y哈希均核对，原生1800盘数值通过，分别75/77项区间未定而无严格失败。与旧χ=.002上端相比，1804个PMP块只有两个χ块改变：目标、normalization、basis、1800原生盘和两截面块全部相同，确认这是同保留空间中的χ受控对照。

S0/P1/S2对同xref Weinberg直线的40点RMS/xref分别降为.08942/.00594/.02849（旧值.6335/.04145/.2135）。S0在[.45,.5319955]有经Arb端点异号与连续性保证的零，未声称唯一。下图保持该完整幅度；它是校准分支的线性诊断，不冒称论文χ=.002的Fig.5精确点或完整C3。

![校准后选定IR的阈下幅度与同xref Weinberg线；数据取同一保存振幅。](../FPI_CALIBRATED_IR_FIGURES_FINAL/subthreshold.png)

物理相位仍有重要差异。C4_source的S0/S2/P1原生RMS为48.53°/3.94°/11.87°；逐点取模180°后的最小相位误差RMS为17.10°/3.94°/11.87°，最末公开点仍分别差34.35°/17.41°/67.52°。后者是任何整数π换支都无法消除的最低误差，不是另选或改画相位。S2大部分区间已经接近源图；S0与高能端仍未通过完整图形比较。IR的P1本来缺少UV信息，完整错误曲线的复现与“没有原生ρ穿越”这一质性结论也分开记录。

![校准选定IR与论文Fig.7；保持原生相位提升，不按图形改变分支。](../FPI_CALIBRATED_IR_FIGURES_FINAL/phases.png)

预先指定的五个原始角积分均与源式吻合，27.98秒。其中三个低波节点通过，而首遗漏I0/I2 ell24、node42仍有∣S∣=6.68358/8.06104。阈下线性改善没有自动消除截断问题；没有加B、Watson或事后幺正化。

[19] **已用廉价复用界约束几何误差。** 以零幅、两端和.21倍χ=.001 tip组成的凸包，在当前固定basis、原生数值接受及数值支撑界的条件下，给出最近边界距离区间[.0004597107016150954,.0004633990329218793]，相对宽度.8023%。上端来自原out.txt的primalObjective，未把候选当严格边界。此界不覆盖未截秩空间，也不证明严格对偶、作者距离度量或幅度/相移唯一性；它足以说明再花一轮求解微调本模型几何的收益很小。

[20] **校准UV三代表全部完成。** 同basis tip、ref及冻结near保持SR-a、逐节点FF、mqmean和原QCD参数。accepted tip后、读取新UV相位前，统一`uv-plan`固定 x_near=xref+min(.01xref,(xtip−xref)/2)=.074054604478664；实际near截面误差3.51e−11在原预算内。`uv-select`已实际逐叶核对目标、截面、完整PMP物理块、mask、basis及完整y。完整contrast使用一份已选IR和三UV，内部mid槽显式标为near，旧算术中点不追认为完成。

| 校准UV代表 | f00(3) | f11(3) | P1首次90°（MeV） | 原生窗minη | 总耗时 |
|---|---:|---:|---:|---:|---:|
| tip | .205068159213 | −.0136248072904 | 911.779 | .469667 | 63.7 min |
| ref | .073321390573 | −.00443854642136 | 未观测 | .140574 | 64.3 min |
| near | .074054604444 | −.00448739123093 | 未观测 | .144387 | 12.49 min |

三个已验收状态仍未复现论文的ρ与S波结论。C6 FAIL，tip穿越括区为[864.418,952.250]MeV；ref/near没有原生低能穿越，不作连续无共振排除。C7_source六项均FAIL，tip/ref/near的S0 RMS为18.93°/12.78°/15.57°，S2为7.08°/5.29°/4.98°，后者仍因公开高能末点差而不通过。全部是同保存幅度的比较，没有再次调整χ、相位分支或代表坐标。

![校准一IR与三UV的完整相位对照；near按事前固定规则选取，原相位不改。](../FPI_CALIBRATED_FULL_CONTRAST/phases.png)

![同四幅度的原生η；水平线仅为幺正上界，论文未公开η曲线。](../FPI_CALIBRATED_FULL_CONTRAST/inelasticity.png)

[完整对比与验收](../FPI_CALIBRATED_FULL_CONTRAST/VALIDATION.json)及[1116行支持CSV](../FPI_CALIBRATED_FULL_CONTRAST/phase_eta.csv)保留所有保存点和公开曲线，论文η留空。全组basis相同，但只有IR ref／UV ref的目标及截面相同；不同代表之间的变化不能全部归因于UV。同xref UV lower也已完成，只补C5上下几何，不作第四个相位代表。选定IR的[阈下CSV](../FPI_CALIBRATED_IR_FIGURES_FINAL/subthreshold.csv)继续绑定同一完整幅度。

[24] **同输入C5截面补齐，不对称方向仍失败。** UV下端y=−.00556223619319，1714个原生盘严格通过、86项符号未定、0失败，700个Gram子式、4个FESR和14个FF界严格通过。上侧降低1.29561e−5，下侧抬升7.95028e−5，二者之比.162964；由原SDPB数值支持上下限传递得到[.150202,.174294]。论文Fig.8的同xref分支插值给约6.30322，强调上侧变化更大；这里反而下侧变化更大。差异远大于当前支持误差，但这些仍是固定保留空间的数值区间，不是严格对偶证书或全区域比较。

![同xref的上下截面变化：左为论文源图插值，右为固定χ=.00021校准结果；原始下点相位没有参与比较。](../FPI_CALIBRATED_C5_SECTION/sections.png)

[截面结果](../FPI_CALIBRATED_C5_SECTION/report.json)、[绘图CSV](../FPI_CALIBRATED_C5_SECTION/section_data.csv)及[实际续算验收](../FIRST_FPI_CALIBRATED_C5_LOWER_RESUMED.json)保留误差口径、同PMP和完整y哈希。校准不是论文名义ε的逐值恢复；原名义结果和全部失败仍单列。

[23] **下一步不再扫描χ或常见norm。** χ=.001的已验收见证x=.403790185，在ε=.002下同时满足逐点盒、合并L2和两组L2（合并上界√2×.001<.002），约为源图主ε端点的4.89倍。若保留空间U扩为包含U的U′，同一有限物理约束下已有幅度仍允许，故支持只能不减；多保留SVD方向不能单独修复区域过宽。此为当前sine族的数值见证范围，不能转成作者有限程序的反例。物理黑点邻域已建立，精确minε不是论文规定的目标；新增该优化也不能自动保证阈下线性或消除遗漏波。[范围与剩余最小计算](../remaining_mainline_decision_20260913/REPORT_ZH.md)。继续计算时须先确定固定空间的分波截断检验，与论文正式五配置C8分别标记。


<!-- pagebreak -->

## 10. 成本、可复用交付与证据索引

[5] L12 p192 的失败发生于 Cholesky(Q)，观察到 Q 条件数约 4.26×10⁶⁷，最后主迭代 gap≈8.15×10⁻⁶。目录只有 block timings，没有可恢复主迭代的有效 checkpoint；旧 out/y 来自计时阶段，objective≈6.9237，不能当作主解。精度重算保存完全相同 PMP、basis、mask，避免重新 SVD 或改变物理合同；pmp2sdp 与 SDPB 都升为 320 bit，并设 checkpointInterval=300。当时只观察到8个非空rank checkpoint；后续near已实际完成checkpoint加载与原式重新验收。[故障与重启记录](../L12_PRECISION_FAILURE_AND_RESTART.json)、[完成记录](../L12_PRECISION_REPAIR_RESULT.json)

| 已完成工作 | 实测成本 | 结论的范围 |
|---|---:|---|
| UV L12 精确输入 p320 重算 | 3702.90 s；其中转换 570.68 s、SDPB 3044.49 s | 数值接受；不是 320 bit 最小必要精度的证明 |
| 同 basis IR L12 upper / lower | 2664.19 s / 2459.74 s | 两个截面支持；不是全区域 |
| L12 首遗漏三行独立角积分 | 18.37 s | 已发现两行大违反；不是高波全覆盖 |
| 同 UV 幅度 Gram/谱矩机制 | 5.54 s | 原生电流诊断，无新优化 |
| 已选 IR 三波 131 点阈下重评 | 16.58 s | 同保存幅度的评价网格补全 |
| IR / UV 完整原坐标精确导出 | 6.69 s / 6.85 s | 相对保存数据的表示误差为 0 |
| 新名义UV tip / 相邻χ=.001 IR tip | 4001.15 s / 4157.89 s | 数值通过，物理仍有大偏差 |
| 黑点的既有幅度组合核验 | 15.10 s | 只评投影与χ，没有新优化或相移选择 |
| 校准UV tip / ref / near | 3821.17 s / 3858.65 s / 749.37 s | near实际warm-start；没有同PMP冷启动加速比 |
| C5同PMP续算 | 466.57 s，其中SDPB264.32 s，7步 | 原320bit及原阈值；此前超时1463.45 s另计 |
| 跨L坐标接口后的工程测试 | 222 passed，77.18 s | 回归证据，不是物理验收 |

[12] 这些成本支持“先重放现有幅度再求解”的顺序。一台已核验主机有 80 逻辑 CPU、40 物理核、约 503 GB 内存；科学任务通常各 8 MPI ranks。旧 Docker rank 曾建 42 个线程，短窗口只有主线程消耗 CPU，线程数不能冒充满载算力。新 launcher 将 BLAS/OMP/MKL 固定为 1，并显式传入 Docker 与 OpenMPI；本地双 rank 环境控制通过，不是远程百节点测试。[资源审查](../runtime_resource_review/REPORT_ZH.md)、[MPI 环境控制](../runtime_thread_fix/explicit_mpi_exports_validation.json)

新名义UV tip的pmp2sdp外部耗时1688.00秒，内部矩阵转换75.443秒；SDPB外部2089.32秒。冷启动单个M50支持约45–70分钟。同合同邻点warm-start已实测12.49分钟；按IR两端并行约45.9分钟、UV tip/ref并行约64.3分钟和near约12.5分钟，固定M50/L12核心一轮工段合计约2小时，实际预算2–3小时。冷启动串行、环境等待或重试可至3–5小时或更长；完整Fig.3–11另计。

一次 8-rank 预处理测量因 Docker 创建延迟超时，外部 966.845 s、rc=124，没有完成转换。不能据此给出加速比，也不能把单 rank 外部 570.678 s 与程序内部 105.198 s 的差全部归于 MPI 计算。公共 `sdp selfcheck` 已默认约束测试线程，避免曾实测约 48 CPU 的 pytest 过度并发。[最新测试原文](../same_M_cross_L_basis_implementation_20260913/FULL_TESTS.txt)

[22] 实际near检查点复用遵循SDPB 3.1.0的[官方说明](https://github.com/davidsd/sdpb/blob/3.1.0/docs/Usage.md#running-sdpb)：结构、精度、进程数及分配保持匹配，沿用原block_timings。原checkpoint独立复制到输入目录，输出写另一目录；重新执行所有物理验收。near主迭代14步、SDPB520.36秒、转换121.61秒、总749.37秒，primalError4.72e−32、dualError3.51e−11。沿用gap1e−6，但为满足原始可行性阈值实际gap降到8.67e−11，并非新增过严精度目标。[实测记录](../FIRST_FPI_CALIBRATED_UV_NEAR_WARM.json)。此初始化仅实测单宿主Docker；冷启动再生成PMP可以重算同一个有限问题，精确重复本次初始化还需二进制checkpoint。

C5下边界的第一次warm尝试达到1200秒预算仍未通过原阈值，gap1.93917e−6、primalError1.8647e−7；总1463.45秒。其同PMP终态检查点续算现已完成：实际加载、7步主迭代、额外466.57秒，SDPB264.32秒；gap2.35333e−8、primalError7.60864e−11、原式数值通过。只把timeout延长到7200秒。新`refine --resume`核对终态进程、完全相同PMP/目标/basis及除timeout外的settings，独立复制检查点并重新验收，30项控制、9项CLI控制与217项回归通过。下点相位未用于选择或比较。[原超时记录](../FPI_CALIBRATED_C5_LOWER_TIMEOUT.json)、[续算计划](../FPI_CALIBRATED_C5_RESUME_PLAN.json)。

[13] 可搬移的 canonical amplitude export 已就绪：原 binary64 basis 用精确二进制有理数解释，完整 y 十进制文本转精确有理数，以整数点积还原全部 3876 个 c；UV 另保留电流 Im F 与 ρ̂。`amplitude.wl` 是无外部调用的纯数据 Association，`amplitude.json` 写全块布局、节点、函数族、单位和来源哈希，`canonical_y.txt` 保留原字节。24 项控制覆盖强消减、subnormal、低于 double 分辨率的 y 尾数、错哈希与非终态拒绝；四个导出投影读数与源报告已保存 Arb 包络相容。精确导出没有恢复 SVD 被删方向，也不是新可行性证明。[使用和数据范围](../canonical_amplitude_export_20260913/README_ZH.md)、[导出验证](../canonical_amplitude_export_20260913/VALIDATION.json)

实际 Mathematica 15.0 已完成 `Get` 全部 UV 精确系数，核对 3876 个系数均为整数/有理数、ρ₂ 对称与打包、电流维度正确；再用 70 位独立数值角积分求 f00(3)、f11(3)，两项与保存包络相容（控制预算 10⁻²⁵），总外部耗时 56.05 s。这是实际消费者读入与两项独立投影检查，不是全分波或区间积分证明。统一 CLI 的另一份 UV 导出实测约 7.46 s，7 项接口控制通过。[MMA 实测](../canonical_amplitude_export_20260913/mma_readin_20260913/report.json)、[CLI 控制](../canonical_amplitude_export_20260913/CLI_VALIDATION.json)

[14] 还需防止旧文案通过复用入口重生。残留 `sdp/report.py` / `scripts/sdp/finalize.py` 含旧 Clarabel/B 报告和硬编码“数学精确 SVD”等错误判断；统一 SDP CLI 不调用它。独立控制确认：给空输入目录也会生成“B 就是论文”“M50 全不收敛”的断言。现已认证保存原 producer 字节并关闭旧 API 与脚本，均在写文件前拒绝；7 项控制通过。这是报告来源隔离修复，没有改变当前 SDPB 数值；本报告不采用其任何旧结果。[退休与反例证据](../legacy_report_retirement_20260913/VALIDATION.json)

[21] 便携性已从系数导出扩展到PMP重建。13个科学叶的原disk_mask及11组M50 MMA资料已补齐；搬移后Pmp.from_saved、uv-plan和MMA结果复用通过。restore另增加有效mask内容校验，26项独立控制与17项定向测试通过，正常目标文字不变。修正合成fixture的UV Gram mask后，36+28项接口检查仍通过；历史控制材料不改写。

本目录的 `EVIDENCE_INDEX.json` 记录本次实际引用的报告、CSV、PDF、关键完成叶与测试日志的 SHA256，并保存本文派生截面量的计算式。查表优先级如下：

| 证据层 | 首选对象 |
|---|---|
| 论文公式与图 | [论文 PDF](https://arxiv.org/pdf/2309.12402v3)、[v3 原始源包](https://arxiv.org/src/2309.12402v3)、对应 `references/figure*_*.csv` 与 metadata |
| 当前物理对照 | [校准完整对比](../FPI_CALIBRATED_FULL_CONTRAST/VALIDATION.json)；旧名义L12对比继续保存，校准结果不追认为名义结果 |
| 代表选择 | [IR_L12_GEOMETRIC_SELECTION/report.json](../IR_L12_GEOMETRIC_SELECTION/report.json)；相对来源路径、全 PMP 块身份、两距离包络 |
| 原式数值与输入 | [IR upper](../IR_M50_L12_shared_basis/ref/report.json)、[UV ref](../UV_M50_L12_source_ref_p320/report.json)；完整 basis/PMP/y 哈希及数值状态 |
| 内部反例与源域修正 | `source_UV*_first_omitted_waves/`、`paper_acceptance_self_audit_20260913/`、`subthreshold_completion_20260913/` |
| 可复算完整振幅 | `canonical_amplitude_export_20260913/`，无需恢复旧模块或重新求解 |
| 历史判断的可追溯性 | `deepresearch/`、`foundations_normalization_review/`、`author_implementation_search_20260913/`；其旧 pending 状态以本文明确完成记录更新 |

当前证据建立了可追溯的失败与修复链：公式核验、有限输入接受、共同 basis 对照、几何选择、源图自检和明确物理差异。完整复现尚未成立，作者缺参也未被确认为唯一剩余原因。后续结论需要同时评估允许区域、阈下形状、遗漏波和代表稳定性；一条更接近的 P1 曲线不足以替代这些检查。


**编号注释与来源清单**

1. **论文原式与图。** He–Kruczenski，*Bootstrapping gauge theories*，[2309.12402v3](https://arxiv.org/pdf/2309.12402v3)：第 7–10 页 (2.2)、(2.6–2.12)、(2.17–2.18)；第 19–25 页 (2.54–2.56)、(3.58–3.75)；第 27–38 页 (4.79)、Fig.3–11。正文链接保留逐页定位。
2. **输入口径。** [参数审计](../deepresearch/PARAMETER_AUDIT.json)与[综合源文研究](../deepresearch/REPORT_ZH.md)：区分原文明确值、声明范数与历史输入；不把后续约定追认为 2309。
3. **归一化独立控制。** [归一化报告](../foundations_normalization_review/REPORT_ZH.md)、[原始角积分](../foundations_M50_angle_check/report.json)：恒等式、数值积分与区间证据分别标注。
4. **有限空间身份。** [basis 比较](../IR_UV_BASIS_COMPARISON.json)、[坐标等价证明](../subtraction_coordinate_equivalence_20260913/REPORT_ZH.md)：完整坐标等价不自动覆盖重新截断的子空间。
5. **精度与失败终态。** [失败/重算](../L12_PRECISION_FAILURE_AND_RESTART.json)、[完成验收](../FIRST_SOURCE_UV_L12.json)：保存相同输入；求解器 gap 不冒充独立严格对偶界。
6. **几何选择。** [冻结计划](../IR_REFERENCE_GEOMETRY_PLAN.json)、[选择收据](../IR_L12_GEOMETRIC_SELECTION/report.json)：只比较两个截面端点；此前 upper 相位已知。
7. **完成的同 basis 对照。** [主对照](../SOURCE_L12_PAPER_STYLE_REFERENCE/report.json)、[区域几何](../REFERENCE_REGION_COMPARISON/report.json)：有限状态比较；完整三代表链仍缺项。
8. **截断反例。** [L10](../source_UV_first_omitted_waves/report.json)、[L12](../source_UV_L12_first_omitted_waves/report.json)：原生能量上的首遗漏波；积分一致不等于幺正通过。
9. **源图自检。** [C4 修订](../C4_SOURCE_ACCEPTANCE_AMENDMENT.json)、[C1–C8 自审计](../paper_acceptance_self_audit_20260913/PAPER_SELF_AUDIT.json)：10° 为操作预算；无公开 η 不造数。
10. **阈下覆盖。** [补评与控制](../subthreshold_completion_20260913/IMPLEMENTATION_ZH.md)：C3 的 8% 比较同 ε 论文曲线，不是 Weinberg 线性门槛。
11. **作者公开实现范围。** [固定 README](https://github.com/hyfysics/gauge-theory-bootstrap/blob/801684d9ece3de2918a20145178f569459081098/README.md#L85)、[检索档案](../author_implementation_search_20260913/REPORT_ZH.md)；同期 [CERN 幻灯](https://indico.cern.ch/event/1331655/attachments/2739524/4765108/bootstrapQCD_CERN.pdf)第 60、71、74 页。
12. **运行成本。** [资源核验](../runtime_resource_review/REPORT_ZH.md)、[217 项测试原文](../PREPARED_MASK_FINAL_TESTS.txt)：单机与完成/超时计时分开。
13. **完整幅度交付。** [导出说明](../canonical_amplitude_export_20260913/README_ZH.md)、[Mathematica 实读](../canonical_amplitude_export_20260913/mma_readin_20260913/report.json)：精确数据表示及两项独立投影，不是新全局证书。
14. **旧报告来源隔离。** [独立反例与关闭验证](../legacy_report_retirement_20260913/VALIDATION.json)：阻止空输入产生旧 B/Clarabel 结论，原 producer 字节保留。

15. **新名义与相邻容差结果。** [UV tip](../FIRST_NOMINAL_SOURCE_UV_TIP.json)、[IR χ=.001 tip](../FIRST_ADJACENT_CHI_001_IR_TIP.json)、[PMP复用身份](../NOMINAL_L10_OLD_REF_NEW_TIP_INPUT_COMPARISON.json)、[电流诊断](../nominal_source_UV_tip_currents/report.json)。
16. **黑点见证。** [完整y组合核验](../chiral_convex_witness_20260913/REPORT_ZH.md)、[机器记录](../chiral_convex_witness_20260913/WITNESS.json)：只评投影和八个χ残差。
17. **有界fπ校准。** [邻域几何与成本选择](../chiral_tolerance_calibration_design_20260913/DESIGN_ZH.md)、[冻结端点计划](../FPI_CALIBRATED_IR_PAIR_PLAN.json)：.00021为本次校准，不是恢复作者参数。

18. **校准IR完成态。** [两端及完整分析](../FIRST_FPI_CALIBRATED_IR_PAIR.json)、[只改变两个χ块的核验](../CALIBRATED_IR_ONLY_CHI_CHANGE.json)、[独立角积分](../FPI_CALIBRATED_IR_SELECTED_ANGLES/report.json)、[换支不变误差](../FPI_CALIBRATED_IR_SELECTED_ANALYSIS/BRANCH_INVARIANT_PHASE_CHECK.json)。
19. **最近距离条件界。** [凸包几何推导](../calibrated_IR_nearest_distance_bound_20260913/REPORT_ZH.md)、[源Arb包络与数值支撑输入](../calibrated_IR_nearest_distance_bound_20260913/report.json)：0.8023%是模型内距离夹区宽度，不是相位误差。
20. **UV邻点与统一交付。** [API和36项控制](../uv_selection_validation_20260913/API_AND_SCOPE_ZH.md)、[28项CLI/交付控制](../uv_selection_validation_20260913/CLI_DELIVERY_VALIDATION.json)、[固定输入UV计划](../FPI_CALIBRATED_UV_MAINLINE_PLAN.json)、[实际IR图表验证](../FPI_CALIBRATED_IR_FIGURES_FINAL/VALIDATION.json)。

21. **prepared复用与便携依赖。** [mask内容一致性修复](../prepared_mask_identity_fix_20260913/REPORT_ZH.md)、[36+28项兼容控制](../uv_selection_validation_20260913/mask_guard_compatible/FINAL_VALIDATION.json)、[完整PMP搬移核验](../reproduction_package_20260913/PACKAGE_DEPENDENCY_VALIDATION_ZH.md)：补齐原mask/MMA资料，目标重建一致。当前新增接口属于版本升级，旧快照mask缺件单独保留红/绿证据。

22. **实际SDPB初始化复用。** [完成记录](../FIRST_FPI_CALIBRATED_UV_NEAR_WARM.json)、[官方SDPB3.1.0用法](https://github.com/davidsd/sdpb/blob/3.1.0/docs/Usage.md#running-sdpb)：仅改变固定截面，完整source重新验收；不宣称多节点或成对冷启动加速比。

23. **剩余参数与计算优先级。** [独立决策与包含关系](../remaining_mainline_decision_20260913/REPORT_ZH.md)：已有见证在常见范数下的范围、SVD嵌套单调性、C1/C2/C3/C8缺项；不把最小ε优化增列为论文验收前提。

24. **校准C5上下截面。** [完成比较](../FPI_CALIBRATED_C5_SECTION/report.json)、[原输入续算](../FIRST_FPI_CALIBRATED_C5_LOWER_RESUMED.json)：两侧均收缩，方向与原文Fig.8相反；数值支持区间和原生验收不冒充全边界或严格对偶。

25. **有限离散化解释范围更正。** [源文及认证代码审查](../finite_discretization_scope_audit_20260913/REPORT_ZH.md)、[更正说明](../FINITE_DISCRETIZATION_SCOPE_CORRECTION_ZH.md)：区分精确有限完成与配点近似，不由节点残量单独否定后者；数值错误及物理失败不撤销。
