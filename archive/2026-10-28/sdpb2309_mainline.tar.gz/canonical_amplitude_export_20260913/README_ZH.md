# Mathematica读取及本地打包的完整振幅精确导出

两份已完成、选定用于本地打包的上点均已导出，每份含3876个原密度坐标系数。没有读取仍运行的tip结果，也没有改写任何原运行数据。

| 源幅度 | 完整y数 | 原basis形状 | 导出时间 |
|---|---:|---|---:|
| `UV_M50_L12_source_ref_p320` | 2189 | 3876×1989 | 6.85秒 |
| `IR_M50_L12_ref`（源`IR_M50_L12_shared_basis/ref`） | 1989 | 3876×1989 | 6.69秒 |

每个子目录有四个文件：

- `amplitude.json`：完整spec、来源哈希、变量布局、精确有理数振幅分块、原文数字形式的电流变量及转换范围。
- `amplitude.wl`：只有一个纯数据Association，数值为精确有理数，没有赋值、外部调用或求解动作。可直接在Mathematica用 `d = Get["amplitude.wl"]` 读取；只有调用者自己的这条命令会给d赋值，文件本身不修改全局状态。
- `canonical_y.txt`：与原SDPB完整文本逐字节相同。
- `report.json`：交付文件哈希、源报告哈希、生产代码哈希、计时及认证范围。

`amplitude.wl`的直接数据键包括 `T0`、`sigma1`、`sigma2`、`rho1_row_major`（已经是M×M行数组）、`rho2_upper_unscaled`，以及方便直接计算的 `rho2_full_symmetric`。UV文件另含按S0/P1分组的 `ImF`、`rho_hat` 精确有理数。这里的散射双密度rho1/rho2与电流谱密度rho不是同一个变量。

JSON中的有理数使用十进制整数字符串或 `分子/分母` 字符串，避免JSON数字读取器悄悄降为机器精度。ρ2上三角顺序为零基索引 `(0,0),(0,1),...,(0,M-1),(1,1),...`，包括对角线；对称展开时直接赋同一个值，没有2或√2因子。索引对也逐项写入JSON。若只需要数值近似，可在Mathematica读取精确数据之后再显式调用 `N[d["sigma1"],80]`；80位表示计算显示精度，并不意味着原解物理精确到80位。

## 精确性与来源检查

原SDPB十进制y文本先转成精确Fraction。每个保存的binary64 basis元素用 `float.as_integer_ratio()`取得精确二进制有理数；逐行取公共二次幂分母，与具有公共分母的y做整数点积，最后约分。因此相对于保存的有限输入，导出表示误差严格为0。整个basis不提升成庞大的有理矩阵，只通过binary64内存映射读取，并保留一行整数比值。

`solution.npz`的SHA与y/a/ImF/rho_hat拷贝用于身份检查；已舍入的c仅检查数组形状，不参与系数计算。完整y必须与源报告的求解时 `y_sha256` 相符；旧缺hash叶默认拒绝，没有把fresh hash或binary64对照伪称成求解时的完整文本认证。

源报告必须完成、SDPB退出码为0，`sdpb_process.json`必须终态且退出码为0；超时、maxRuntime/maxIterations、非零退出、未完成或相互冲突的终止原因均拒绝。PMP/basis/NPZ/y完整哈希、维数、源布局与节点producer身份都核验，导出后还复查输入哈希未变。

默认限额为5000万个basis元素、每个数字token最多4096字符、十进制指数绝对值最多10000；运行预算600秒，在basis行之间检查。实际两份basis均为7,709,364个元素。配置、内存策略和限额随数据保存。

精确转换没有恢复被SVD截断的方向，也没有提高求解器精度、改变输入、寻找新幅度或证明全局幺正性／物理复现完成。导出的只是那一份已经保存的有限幅度的另一种数据表示。

## 作者无需SVD即可恢复本次具名解析族

这两份源幅度均记录为 `sine-cardinal`。原密度系数已完整恢复，作者无需知道1989维的SVD坐标。其原生节点按零基j为：

\[
\phi_j=\frac{\pi(2j+1)}{2M},\qquad s_j=\frac8{1+\cos\phi_j},\quad j=0,\ldots,M-1.
\]

s以mπ=1计；本代码的能量换算为E=(140/1000)√s GeV。导出没有按参考图的139.57 MeV绘图轴重缩放。

按随源报告保存的 `sine.py` 定义，

\[
D_{nj}=\frac{2-\delta_{nM}}M\sin\frac{\pi n(2j+1)}{2M},\qquad
g_j(z)=\sum_{n=1}^M D_{nj}\big[z^n-(-1)^n\big].
\]

阈下实s使用z=(2−√(4−s))/(2+√(4−s))；物理上沿s>4使用z=(2+i√(s−4))/(2−i√(s−4))。记g(s)为以上行向量，则

\[
A(s,t,u)=T_0+g(s)\sigma_1+[g(t)+g(u)]\sigma_2
+g(s)\rho_1[g(t)+g(u)]^T+g(t)\rho_2g(u)^T.
\]

这声明的是本次源报告的有限插值族，不是声称恢复作者未公开的插值实现。完整原始source哈希映射随JSON保留，节点/布局当前producer哈希另记。

UV电流保持原完整文本ImF、rho_hat，并明确 `rho=k² rho_hat`。S0的k²=3√(1−4/s)/(256π⁵)，P1的k²=(s−4)√(1−4/s)/(384π⁵)。ReF=1+K ImF、F(0)=1和K的离散公式也写入JSON；没有从相移反推S或F。

## 验证与统一入口

`VALIDATION.json`记录24项控制：独立Fraction点积、1e16消减压力、binary64的0.1与十进制0.1的区别、subnormal、y低于binary64分辨率的尾数、分块顺序、FF原文数字、Wolfram纯literal Association及正常引号/反斜杠转义、来源篡改与非终态拒绝、限额/时限和禁止solver调用等。

此外，以每份导出的完整有理数c重新计算f00(3)、f11(3)，四个结果均与各自**原报告已经保存的Arb包络**相容；没有检查tip、没有重做全分波或dual replay，也不把这个局部兼容性控制扩大成新的可行性证书。

只新增 `src/smatrix_bootstrap/sdp/amplitude_export.py`，本子任务不修改其他核心模块或三个活动测试文件。实现入口为 `export_amplitude(source_report,outdir,timeout=600,max_entries=50000000)`；root负责合并统一CLI：

```text
python -m smatrix_bootstrap.run sdp amplitude-export \
  --source-report LEAF/report.json --out FRESH
```

生产代码原字节保存为 `amplitude_export.py.txt`，独立控制代码保存为 `control_producer.txt`。现有结果、原预登记和物理输入均未改动。


## Mathematica实际读入与独立投影复核

已通过统一 `scripts/mma/wolfram.sh`，在新建、离线且单独CID管理的Mathematica 15.0.0容器中实际执行UV导出的 `Get`。证据为 [mma_readin_20260913/report.json](mma_readin_20260913/report.json)、[readin.json](mma_readin_20260913/readin.json) 和 [mma.log](mma_readin_20260913/mma.log)；检查脚本原字节保存为 `check_script.txt`。退出码0，整体耗时56.05秒，整体硬上限18000秒；没有操作科学计算容器。

实际检查确认Association成立，3876个原密度打包坐标全部为精确Integer/Rational，未混入机器或任意精度Real；sigma长度、rho1/rho2的50×50维数、rho2精确对称及上三角顺序、S0/P1电流各50个变量均正确。这里的3876是完整密度坐标槽位数，不是另行证明SVD方向的秩。Mathematica自身计算的输入文件SHA256也与导出清单一致。

另以70位工作精度、32位精度/准确度目标，直接对原密度振幅作两项独立角积分。f00(3)≈0.07332139057293464004930825594757711940974，f11(3)≈−0.0021364191137845979306857865559308726655364；两项数值结果均位于原报告保存的Arb包络内，并通过预设1e−25的一致性条件。积分分别耗时1.03秒和0.36秒，每项单独限时90秒。这是Mathematica数值交叉核对，不是新的严格区间证书。

开头用语已更正为“已完成、选定用于本地打包”。本记录不表示已经获得公开、外发或联系作者的授权，也没有执行这些操作。修改前README原字节保存在 `mma_readin_20260913/README.before.txt`。

## 名义tip与相邻χ试验的新增导出

已通过统一CLI追加 `UV_M50_L10_nominal_tip/` 和 `IR_M50_L12_chi001_tip/`，两者均为完成态、完整y求解时哈希相符的3876系数精确导出。前者为名义M50/L10 χ=.002 UVtip，后者为同L12 basis的χ=.001 IRtip。它们不与原L12 ref自动合并为同合同三代表；每份独立spec及哈希保留。当前χ=.00021校准端点仍运行，未导出临时解。
