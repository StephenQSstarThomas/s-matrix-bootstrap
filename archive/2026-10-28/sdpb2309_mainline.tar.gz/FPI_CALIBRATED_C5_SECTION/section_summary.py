"""Report algebra on accepted saved scalar supports; no amplitude evaluation."""
from pathlib import Path
import json,hashlib,csv,re,datetime,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;B=ROOT.parent
plan=json.loads((B/'FPI_CALIBRATED_C5_SECTION_ANALYSIS_PLAN.json').read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
records={};inputs={};rows=[];common=None;basis=None
for name,path in plan['sources'].items():
 p=B/path;r=json.loads(p.read_text());assert r['status']=='numerically_accepted' and r['accepted'] and r['convergence']['solver_optimal'] and r['verification']['primal_feasible'],(name,r['status'])
 assert sha(p.parent/'out/y.txt')==r['y_sha256'];assert sha(p.parent/'basis.npy')==r['basis']['sha256']
 if basis is None:basis=r['basis']['sha256']
 assert basis==r['basis']['sha256'];inputs[path]=sha(p)
 s={k:v for k,v in r['spec'].items() if k not in ('uv','uv_parts','sr_caliber','eps_ff','m_q','ff_frozen_at_s0','tag','disk_mask')}
 if common is None:common=s
 assert common==s and s['M']==50 and s['L']==12 and s['eps_chi']==.00021
 assert abs(r['fix_f00']-.07332139057293464)<1e-15
 sign=1 if name.endswith('upper') else -1;assert r['direction']==[0.,float(sign)]
 lo,hi=r['convergence']['candidate_lower'],r['convergence']['candidate_upper'];assert lo<=hi
 interval=[lo,hi] if sign==1 else [-hi,-lo]
 y=r['verification']['f11_3'];assert interval[0]-1e-14<=y<=interval[1]+1e-14
 records[name]={'y':y,'numerical_support_interval':interval,'gap':r['convergence']['absolute_gap'],'seconds':r['seconds'],'source_hash':inputs[path]}
 rows.append([name,r['verification']['f00_3'],y,*interval,path,'SDPB numerical support; not strictdual'])
def subtract(a,b):return [a[0]-b[1],a[1]-b[0]]
def I(name):return records[name]['numerical_support_interval']
u=subtract(I('IR_upper'),I('UV_upper'));l=subtract(I('UV_lower'),I('IR_lower'));assert u[0]>0 and l[0]>0
ratio=[u[0]/l[1],u[1]/l[0]]
uc=records['IR_upper']['y']-records['UV_upper']['y'];lc=records['UV_lower']['y']-records['IR_lower']['y']
source=json.loads((B/'paper_acceptance_self_audit_20260913/PAPER_SELF_AUDIT.json').read_text())['C5']
r=json.loads((B/plan['sources']['UV_lower']).read_text());origin=json.loads((B/'UV_M50_L12_fpi_calibrated_eps00021_lower_warm/report.json').read_text());log=(B/plan['sources']['UV_lower']).parent/'sdpb.log'
assert r['exact_input_source']['checkpoint_loaded'] and 'Loading binary checkpoint from' in log.read_text()
assert r['pmp']['sha256']==origin['pmp']['sha256'] and r['basis']['sha256']==origin['basis']['sha256']
assert {k:v for k,v in r['settings'].items() if k!='timeout'}=={k:v for k,v in origin['settings'].items() if k!='timeout'}
assert r['warm_start']['mode']=='same-input-resume'
result={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_report_hashes':inputs,'basis_sha256':basis,'spec':common,'rows':records,
 'upper_shrink':{'candidate':uc,'numerical_interval':u},'lower_shrink':{'candidate':lc,'numerical_interval':l},'ratio':{'candidate':uc/lc,'numerical_interval':ratio},
 'source_paper_section':source,'directional_C5_asymmetry_pass':bool(ratio[0]>1),
 'finding':'Both calibrated sections shrink; lower moves more than upper, opposite the Fig8 direction. Not completeC5 boundary reproduction.',
 'resume':{'checkpoint_loaded':True,'same_pmp':True,'only_timeout_changed':True,'source_failed_attempt_seconds':origin['seconds'],'additional_seconds':r['seconds'],'additional_solver_seconds':r['sdpb']['seconds'],'main_iterations':len(re.findall(r'^\d+\s+\d+\s+',log.read_text(),re.M))},
 'numerical_scope':plan['limitation'],'lower_phase_data_used':False,'full_Fig8_complete':False}
(ROOT/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
with (ROOT/'section_data.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['endpoint','xref','candidate_y','numerical_lo','numerical_hi','source','scope']);w.writerows(rows)
 for group,v in source['branches'].items():
  for side in ('upper','lower'):w.writerow(['paper_'+group+'_'+side,source['xref'],v[side],'','', 'figure8_boundary.csv','linear interpolation of digitized source branch; no solverinterval'])
fig,axes=plt.subplots(1,2,figsize=(9,4.1),sharey=True)
for ax,which in zip(axes,['paper','calibrated']):
 for side,color in [('upper','#b2182b'),('lower','#2166ac')]:
  if which=='paper':vals=[source['branches'][g][side] for g in ('chiral_only_green','gauge_cyan')];ax.plot([0,1],vals,'o-',color=color,label=side)
  else:
   rec=[records[g+'_'+side] for g in ('IR','UV')];vals=[v['y'] for v in rec];err=[[v['y']-v['numerical_support_interval'][0] for v in rec],[v['numerical_support_interval'][1]-v['y'] for v in rec]]
   ax.errorbar([0,1],vals,yerr=err,fmt='o-',color=color,capsize=4,label=side)
 ax.set(xticks=[0,1],xticklabels=['IR','UV'],xlim=(-.18,1.18),ylabel=r'$f_1^1(3)$',title='Paper Fig.8: interpolated source' if which=='paper' else r'Calibrated $\epsilon_\chi=0.00021$, M50/L12');ax.grid(alpha=.2);ax.legend(frameon=False)
axes[0].text(.03,.25,f'upper / lower change = {source["ratio"]:.2f}',transform=axes[0].transAxes,fontsize=9)
axes[1].text(.03,.25,f'upper / lower change = {uc/lc:.3f}\nnumerical interval [{ratio[0]:.3f}, {ratio[1]:.3f}]',transform=axes[1].transAxes,fontsize=9)
fig.suptitle('Same physical x reference; conditional section comparison, not full regions',fontsize=11);fig.tight_layout();fig.savefig(ROOT/'sections.pdf');fig.savefig(ROOT/'sections.png',dpi=180);plt.close(fig)
print(json.dumps({k:result[k] for k in ['upper_shrink','lower_shrink','ratio','resume']}))
