"""Read emitted inputs only: prove the fixed-M smaller-L PMP is a subset."""
from pathlib import Path
import json,hashlib,time
from smatrix_bootstrap.sdp.dual import _stream_pmp
D=Path(__file__).resolve().parent;B=D.parent;OLD=B/'UV_M50_L12_fpi_calibrated_eps00021_tip/tip';NEW=B/'UV_M50_L10_fpi_calibrated_shared_basis_tip/tip';start=time.monotonic()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def keys(L):
 out=[]
 for I in [0,1,2]:
  for k in range(L):
   ell=2*k+(I==1)
   if (I,ell) in [(0,0),(1,1)]:continue
   out += [('disk',I,ell,j) for j in range(50)]
 return out+[('common_tail',j) for j in range(224)]
a=json.loads((OLD/'report.json').read_text());b=json.loads((NEW/'report.json').read_text());assert b['status'] in ('pmp2sdp','solving','numerically_accepted','not_accepted','solver_failed','readback_failed');assert a['accepted'];assert a['pmp']['n_blocks']==1924 and b['pmp']['n_blocks']==1624
assert {k:v for k,v in a['spec'].items() if k!='L'}=={k:v for k,v in b['spec'].items() if k!='L'}
assert sha(OLD/'basis.npy')==sha(NEW/'basis.npy')==a['basis']['sha256'];assert a['pmp']['n_a']==b['pmp']['n_a']==1989
stream_old=_stream_pmp(OLD/'pmp.json');stream_new=_stream_pmp(NEW/'pmp.json');assert next(stream_old)==next(stream_new)
old_keys=keys(12);new_keys=keys(10);hashes={};count_old=0
for k,block in zip(old_keys,stream_old,strict=True):hashes[k]=hashlib.sha256(json.dumps(block,sort_keys=True,separators=(',',':')).encode()).hexdigest();count_old+=1
changed=[];count=0
for k,block in zip(new_keys,stream_new,strict=True):
 digest=hashlib.sha256(json.dumps(block,sort_keys=True,separators=(',',':')).encode()).hexdigest();count+=1
 if digest!=hashes[k]:changed.append(k)
removed=[k for k in old_keys if k not in set(new_keys)];assert len(removed)==300
assert {k[1:3] for k in removed}=={(0,20),(0,22),(1,21),(1,23),(2,20),(2,22)}
r={'passed':not changed,'baseline_PMP_sha256':sha(OLD/'pmp.json'),'target_PMP_sha256':sha(NEW/'pmp.json'),'basis_sha256':sha(NEW/'basis.npy'),'baseline_blocks':count_old,'target_blocks':count,'changed_common_keys':changed,'removed_disk_count':len(removed),'removed_waves':sorted({k[1:3] for k in removed}),'same_objective_normalization':True,'source_old_tip_x':a['verification']['f00_3'],'target_solver_outputs_read':False,'seconds':time.monotonic()-start,'scope':'Exactcoefficient subsetafterphysicalrowreindexing inthesame1989dimensionalcoordinate space. Old acceptednumericalwitness suppliesbaseline lowercandidate; notstrictdualcertificate orglobalamplitudeidentityclaim.'};(D/'M50_L10_INPUT_SUBSET.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
