"""Write-only smoke of the face PMP from an accepted M=50 leaf; cross-check the objective row
against the P1 node-38 Gram block rows already present in the source PMP."""
import json, sys, time
import numpy as np
from pathlib import Path
from flint import arb
from smatrix_bootstrap.sdp.pmp import Pmp
from smatrix_bootstrap.sdp.dual import _stream_pmp

SRC = '/playpen1/shiqiu/sdpb_regularised_20260913/uv_SRa_section_hi/report.json'
OUT = Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
src = json.loads(Path(SRC).read_text())
face = {'direction': src['direction'], 'value': src['verification']['objective_recomputed'], 'margin': 2e-6}
func = {'kind': 'ImKH', 'wave': 'P1', 'node': 38, 'sense': 'max'}
t0 = time.time()
w = Pmp.from_saved(SRC, tuple(src['direction']), src['fix_f00'], face, func)
print('restored in', round(time.time()-t0, 1), 's; n_a', w.n_a, 'n_vars', w.n_vars, 'face', w.face, 'functional', w.functional, flush=True)
info = w.write(str(OUT/'pmp.json'))
print('written', info['n_blocks'], 'blocks', info['block_sizes'], round(time.time()-t0, 1), 's', flush=True)
obj = np.array([float(v) for v in json.load(open(OUT/'pmp.json'))['objective']]) if False else None
# stream: header (objective), then find the P1 node-38 Gram block (3x3, entry (2,2) = unit rho at i_rho+M+38) and the last two blocks
blocks = _stream_pmp(OUT/'pmp.json'); head = next(blocks)
obj = np.array([float(v) for v in head['objective']])
M = w.spec.M; rho_slot = w.i_rho + M + 38
gram = None; last = []
for b in blocks:
    poly = b['polynomials']
    if len(poly) == 3:
        e22 = [float(v[0]) for v in poly[2][2]]
        if e22[rho_slot] == 1.0 and sum(x != 0 for x in e22) == 1:
            gram = poly
    last = (last + [b])[-3:]
e00 = np.array([float(v[0]) for v in gram[0][0]])       # 2 - im_row . a
e01 = np.array([float(v[0]) for v in gram[0][1]])       # re_row . a
print('objective nonzeros', np.count_nonzero(obj), 'obj[0]', obj[0])
print('gram(0,0)[0] =', e00[0], '| max|obj + e00| on a-slots =', np.max(np.abs(obj[1:1+w.n_a] + e00[1:1+w.n_a])),
      '| scale', np.max(np.abs(obj[1:1+w.n_a])))
face_row = np.array([float(v[0]) for v in last[-1]['polynomials'][0][0]])
sec_row = np.array([float(v[0]) for v in last[-2]['polynomials'][0][0]])
print('face block: const', face_row[0], 'expected', -(face['value']-2e-6), '| nonzero a-slots', np.count_nonzero(face_row[1:1+w.n_a]))
f11 = np.array([float(v) for v in w.f11])
print('face a-slots == f11 row:', np.allclose(face_row[1:1+w.n_a], f11, rtol=1e-12, atol=0))
print('section block const', sec_row[0], 'fix_f00', src['fix_f00'])
print('sizes', {k: v for k, v in info['block_sizes'].items()}, 'source n_blocks', src['pmp']['n_blocks'])
