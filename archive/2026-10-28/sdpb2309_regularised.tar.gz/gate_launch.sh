#!/usr/bin/env bash
# Launch one gate run.  Usage: gate_launch.sh MREG
set -euo pipefail
cd /home/shiqiu/s-matrix-bootstrap
export PYTHONPATH=src OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4
MREG=$1
exec /home/shiqiu/miniconda3/bin/python -m smatrix_bootstrap.run sdp solve \
  --workdir /playpen1/shiqiu/sdpb_regularised_20260913/gate_tip_linf_$MREG \
  --M 50 --L 10 --chiral --chi chi-b --eps-chi 0.002 \
  --scattering-prescription mixed-pv --reduce-basis \
  --reg-norm linf --reg-bound $MREG \
  --operator-dps 40 --digits 30 --precision 192 \
  --nproc 8 --duality-gap 1e-6 --primal-error 1e-10 --dual-error 1e-10 --timeout 7200 \
  --points tip --mma-reference /playpen1/shiqiu/sdpb_mainline_20260912/IR_M50_source_ref/mma/report.json
