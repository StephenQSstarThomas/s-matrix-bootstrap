#!/usr/bin/env bash
# Four Watson (unitarity-saturation) iteration chains, 5 rounds each, in parallel.  Pre-registered 2026-09-17 18:40Z.
set -euo pipefail
R=/playpen1/shiqiu/sdpb_regularised_20260913; cd /home/shiqiu/s-matrix-bootstrap
export PYTHONPATH=src OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4
PY=/home/shiqiu/miniconda3/bin/python
run() { name=$1; start=$2; shift 2
  setsid nohup $PY scripts/sdp/watson_iterate.py --start $start --out $R/$name --rounds 5 --tol 0.02 "$@" > $R/$name.driver.log 2>&1 < /dev/null &
  echo "$(date -u +%FT%TZ) operator-18: launched $name from $start $*" >> $R/queue.log; sleep 20; }
run watson_tip        $R/uv_SRa_tip/tip/report.json
run watson_ref        $R/uv_SRa_section_hi/report.json
run watson_mid        $R/uv_SRa_section_xp001_hi/report.json
run watson_tip_keepsec $R/uv_SRa_tip/tip/report.json --keep-section
