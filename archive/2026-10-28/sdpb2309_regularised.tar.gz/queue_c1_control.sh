#!/usr/bin/env bash
# Wait for the Mreg=1e4 pure tip, then queue the -x, +y, -y supports from it (C1 regulariser-sensitivity annotation).
R=/playpen1/shiqiu/sdpb_regularised_20260913; SRC=$R/fig3_pure_linf_1e4_tip_v2/tip/report.json
until python3 -c "import json,sys; r=json.load(open('$SRC')); sys.exit(0 if r.get('accepted') else 1)" 2>/dev/null; do sleep 60; done
pre='cd /home/shiqiu/s-matrix-bootstrap && PYTHONPATH=src OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4 /home/shiqiu/miniconda3/bin/python -m smatrix_bootstrap.run sdp support'
flock $R/queue.lock bash -c "for d in '-1.0 0.0:12' '0.0 1.0:06' '0.0 -1.0:18'; do dir=\${d%%:*}; k=\${d##*:}; echo \"$pre --source-report $SRC --direction \$dir --out $R/fig3_1e4_dir\$k\" >> $R/queue.txt; done"
echo "$(date -u +%FT%TZ) operator-18: Mreg=1e4 tip accepted; queued fig3_1e4_dir12/06/18 supports" >> $R/queue.log
pgrep -F $R/queue_runner.pid >/dev/null 2>&1 || (cd $R && MAXJOBS=5 setsid nohup ./queue_runner.sh > $R/queue_runner.out 2>&1 < /dev/null &)
