"""Pre-registered evaluation (GATE_LOG 2026-10-01 15:40Z) of the C5 lower-boundary test with the sum rules removed."""
import json, sys
import numpy as np
sys.path.insert(0, "/home/shiqiu/s-matrix-bootstrap/src")
from smatrix_bootstrap.sdp import constraints as C
from smatrix_bootstrap.sdp.formfactor import kinematic_factor
from smatrix_bootstrap.sdp.grid import S0, s_nodes

R = "/playpen1/shiqiu/sdpb_regularised_20260913"
CHI_HI, CHI_LO = -0.004372515663060449, -0.005134310611347067
PAPER = {"upper": 2.324e-4, "lower": 3.687e-05}


def leaf(name):
    rep = json.load(open(f"{R}/{name}/report.json"))
    t = list(rep["reports"].values())[0] if "reports" in rep else rep
    import os
    f = f"{R}/{name}/solution.npz"
    return t, np.load(f if os.path.exists(f) else f"{R}/{name}/support/solution.npz", allow_pickle=True)


out = {}
for side in ("hi", "lo"):
    t, sol = leaf(f"c5_noSR_section_{side}")
    res = t["sdpb_result"]
    obj = res["primalObjective"]
    y = obj if side == "hi" else -obj
    M, s = 50, s_nodes(50)
    raw = {}
    for e, wave in ((0, "S0"), (1, "P1")):
        rho = kinematic_factor(e, s) ** 2 * sol["rho_hat"][e]
        for n in C.MOMENTS[e]:
            raw[(wave, n)] = float(C.moment_row(M, n) @ rho)
    targets = C.printed_targets()
    norm_dev = {f"{w} n={n}": raw[(w, n)] / S0 ** (n + 2) - targets[(w, n)] / S0 ** (n + 2) for (w, n) in raw}
    out[side] = {"terminate": res.get("terminateReason"), "f11": y, "accepted": t.get("accepted"),
                 "verification": {k: v for k, v in t.get("verification", {}).get("constraint_checks", {}).items()},
                 "normalised_moment_minus_target": norm_dev,
                 "normalised_reading_satisfied": all(abs(v) <= 2e-3 for v in norm_dev.values()),
                 "raw_moment_over_target": {f"{w} n={n}": raw[(w, n)] / targets[(w, n)] for (w, n) in raw}}
up = CHI_HI - out["hi"]["f11"]
lo = out["lo"]["f11"] - CHI_LO
rule = "R1" if lo <= 1e-4 else ("R2" if lo >= 2e-4 else "R3")
out["readings"] = {"upper_shrink": up, "lower_rise": lo, "ratio": up / lo if lo else None, "rule": rule,
                   "C5_thresholds": {"upper_in_band": abs(up - PAPER["upper"]) <= 0.25 * PAPER["upper"],
                                     "lower_le_1e-4": lo <= 1e-4, "ratio_ge_4": (up / lo >= 4) if lo > 0 else None},
                   "paper": PAPER}
json.dump(out, open(f"{R}/C5_NOSR_RESULT.json", "w"), indent=1, default=str)
print(json.dumps(out["readings"], indent=1, default=str))
print({s: (out[s]["accepted"], out[s]["normalised_reading_satisfied"]) for s in ("hi", "lo")})
