import pytest

flint=pytest.importorskip('flint')
from flint import arb_mat,fmpq_mat

from smatrix_bootstrap.imaginary_rank_residual import ImaginaryRankResidual


def fixture(reciprocal=False,nonorthogonal=False):
    M=7;T=fmpq_mat(M,M,[int(i==j)+(int(j==i+1) if nonorthogonal else 0) for i in range(M) for j in range(M)])
    blocks=[];selectors=[]
    for j in range(M):
        indices=[0 if reciprocal and j==1 else (j+1)%M,(j+2)%M,(j+3)%M]
        W=fmpq_mat(M,3,[int(i==indices[k]) for i in range(M) for k in range(3)])
        blocks.append(T.transpose()*W);selectors.append(indices)
    return ImaginaryRankResidual(blocks,T,1,selectors)


def full_IS7_matrix(op):
    M,e,o=op.M,op.e,op.o;unknowns=M*(2*e+o);columns=[]
    for index in range(unknowns):
        node,local=divmod(index,2*e+o);P=fmpq_mat(M,M);Q=fmpq_mat(M,M);R=fmpq_mat(M,M)
        matrix,basis,coordinate=(P,op.E[node],local) if local<e else (
            (Q,op.E[node],local-e) if local<2*e else (R,op.O[node],local-2*e))
        for i in range(M):matrix[i,node]=basis[i,coordinate]
        A=3*P.transpose()+Q+R;H=(Q-R+(Q-R).transpose())/2
        columns.append([A[i,j] for j in range(M) for i in range(M)]+[H[i,j] for i in range(M) for j in range(i,M)])
    return fmpq_mat(op.rows,unknowns,[columns[j][i] for i in range(op.rows) for j in range(unknowns)])


@pytest.mark.parametrize('reciprocal,rank',[(False,7),(True,6)])
def test_complete_residual_kernel_matches_original_IS7(reciprocal,rank):
    op=fixture(reciprocal);F=op.matrix();original=full_IS7_matrix(op)
    assert (op.rows,op.columns)==(77,7) and F.rank()==rank
    assert original.ncols()-original.rank()==op.columns-F.rank()
    assert len(op.exact_zero_rows)==21
    assert all(F[i,j]==0 for i in op.exact_zero_rows for j in range(op.columns))
    active=[i for i in range(op.rows) if i not in op.exact_zero_rows]
    assert op.matrix(active).rank()==rank
    assert 35+F.rank()==(41 if reciprocal else 42)


def test_skew_kernel_reconstructs_all_original_coefficients():
    op=fixture(True);alpha=fmpq_mat(7,1,[1,-1,0,0,0,0,0]);r=op.recover(alpha)
    assert op.matrix()*alpha==r['residual_vector']==fmpq_mat(op.rows,1)
    assert r['Q']==3*r['P'] and r['R']==fmpq_mat(7,7)
    assert r['P']+r['P'].transpose()==fmpq_mat(7,7) and r['P']!=fmpq_mat(7,7)


def test_nonorthogonal_phase_transform_keeps_ordinary_transpose_and_all_rows():
    op=fixture(True,True);alpha=fmpq_mat(7,1,[1,2,-1,3,0,-2,1]);r=op.recover(alpha)
    assert op.matrix()*alpha==r['residual_vector']
    assert 3*r['P'].transpose()+r['Q']+r['R']==3*op.TinvT*r['membership']
    assert r['symmetry']==(r['Q']-r['R']+(r['Q']-r['R']).transpose())/2
    assert op.matrix().rank()==6


def test_exact_left_inverse_choice_and_dyadic_conditioning_preserve_kernel():
    T=fmpq_mat(3,3,[1,0,0,0,1,0,0,0,1]);J=fmpq_mat([[1,0],[1,1],[0,1]])
    a=ImaginaryRankResidual([J]*3,T,1,[[0,2]]*3)
    b=ImaginaryRankResidual([J]*3,T,1,[[0,1]]*3)
    c=ImaginaryRankResidual([J]*3,T,1,[[0,2]]*3,[[7,-4]]*3)
    A,B=a.matrix(),b.matrix()
    joined=fmpq_mat(A.nrows()+B.nrows(),A.ncols(),list(A.entries())+list(B.entries()))
    assert A.rank()==B.rank()==joined.rank()
    assert A==c.matrix()
    with pytest.raises(ValueError,match='distinct'):
        ImaginaryRankResidual([J]*3,T,1,[[0,0]]*3)


def test_Arb_backend_encloses_exact_small_residual_operator():
    exact=fixture(True);T=arb_mat(exact.T.tolist());blocks=[arb_mat(J.tolist()) for J in exact.J]
    enclosed=ImaginaryRankResidual(blocks,T,1,exact.selectors)
    F=exact.matrix();B=enclosed.matrix()
    assert all(B[i,j].contains(F[i,j]) for i in range(F.nrows()) for j in range(F.ncols()))
    assert all(B[i,j].is_zero() for i in enclosed.exact_zero_rows for j in range(enclosed.columns))
