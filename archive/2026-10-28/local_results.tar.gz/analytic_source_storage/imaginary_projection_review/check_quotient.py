"""Small exact quotient reconstruction and Neumann norm counterexamples."""
from fractions import Fraction as F
import hashlib,importlib.util,json
from pathlib import Path
from flint import fmpq_mat

path=Path('/home/shiqiu/s-matrix-bootstrap/tests/test_imaginary_adjoint_inverse.py')
spec=importlib.util.spec_from_file_location('source_inverse_fixture',path)
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
model=fixture.fixture(True);op=model.op;M=model.M;n=model.coefficient_count
full=op.matrix();free=[i for i in range(op.rows) if i not in set(op.exact_zero_rows)|set(model.selected)]

def qapply(r):
    at=1;ra=fmpq_mat(M,1,[r[at+i,0] for i in range(M)]);at+=M
    rb=fmpq_mat(M,1,[r[at+i,0] for i in range(M)]);at+=M
    rB=fmpq_mat(M,M,[r[at+i,0] for i in range(M*M)]);at+=M*M
    rC=fmpq_mat(M,M)
    for i in range(M):
        for j in range(i,M):rC[i,j]=rC[j,i]=r[at,0];at+=1
    a0=2*op.TinvT*ra/3;b0=op.TinvT*rb
    P0=fmpq_mat(M,M,[model.W0[i,j]*a0[j,0] for i in range(M) for j in range(M)])
    Q0=fmpq_mat(M,M,[model.W0[i,j]*b0[j,0] for i in range(M) for j in range(M)])
    A=op.TinvT*rB*model.Tinv/2-3*P0.transpose()-Q0
    H=op.TinvT*rC*model.Tinv/2-(Q0+Q0.transpose())/2
    mem=[];signed=fmpq_mat(M,M)
    for j in range(M):
        column=fmpq_mat(M,1,[A[i,j] for i in range(M)])
        value=op.membership[j]*column/3;mem.extend(value[i,0] for i in range(M))
        value=op.signed[j]*column
        for i in range(M):signed[i,j]=value[i,0]
    H-= (signed+signed.transpose())/2
    b=fmpq_mat(op.rows,1,mem+[H[i,j] for i,j in op.sym_pairs])
    alpha=model.U*fmpq_mat(op.columns,1,[b[i,0] for i in model.selected])
    e=b-full*alpha
    assert all(e[i,0]==0 for i in set(op.exact_zero_rows)|set(model.selected))
    return fmpq_mat(1+len(free),1,[r[0,0]]+[e[i,0] for i in free])

def reconstruct(q):
    e=[0]*op.rows
    for k,i in enumerate(free):e[i]=q[k+1,0]
    mem=fmpq_mat(M,M,[e[j*M+i] for i in range(M) for j in range(M)])
    H=fmpq_mat(M,M)
    for k,(i,j) in enumerate(op.sym_pairs):H[i,j]=H[j,i]=e[M*M+k]
    B=6*mem*op.T;C=2*op.TT*H*op.T
    return fmpq_mat(n,1,[q[0,0]]+[0]*(2*M)+[B[i,j] for i in range(M) for j in range(M)]
                    +[C[i,j] for i in range(M) for j in range(i,M)])

qsize=1+len(free)
Q=fixture.columns_from_apply(qapply,n,qsize)
Z=fixture.columns_from_apply(reconstruct,qsize,n)
I=fixture.independent_original_imaginary_matrix(model)
L=fixture.columns_from_apply(model.left_apply,n,model.row_count)
eye=fmpq_mat(n,n,[int(i==j) for i in range(n) for j in range(n)])
assert Z*Q==eye-I.transpose()*L
assert Q*Z==fmpq_mat(qsize,qsize,[int(i==j) for i in range(qsize) for j in range(qsize)])
assert Q*I.transpose()==fmpq_mat(qsize,model.row_count)
assert qsize==50 and qsize==n-model.row_count
delta=F(1,100);large=F(1000)
# R0=diag(1,K), B=[[1,-delta],[0,1/K]], v=e0.
# Left residual has normdelta, yet transpose error from R0^T v isKdelta.
wrong=delta/(1-delta);actual=large*delta;correct=large*delta/(1-delta)
assert wrong<actual<=correct
# Center-zero uncertain RHS: midpoint-only tail0 would lose the true endpoint.
input_radius=F(1);full_tail=delta/(1-delta)*input_radius
assert 1+full_tail==1/(1-delta)>1
out=dict(schema='smatrix-small-projection-quotient-review-v1',physical_data_used=False,
    M=M,nonorthogonal_T=True,nonunit_physical_scales=True,input_dimension=n,imaginary_rows=model.row_count,
    quotient_dimension=qsize,reconstruction_composition_equals_projector=True,
    quotient_after_reconstruction_is_identity=True,all_imaginary_rows_annihilated_exactly=True,
    transpose_counterexample=dict(delta=str(delta),right_residual_infinity=str(large*delta),
        actual_transpose_error=str(actual),wrong_forward_style_bound=str(wrong),valid_one_norm_bound=str(correct)),
    interval_rhs_counterexample=dict(midpoint_only_tail='0',required_full_magnitude_tail=str(full_tail)),
    large_matrix_jobs=0,optimizer_runs=0,source_fixture_path=str(path),source_fixture_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
    script_source_utf8=Path(__file__).read_text())
output=Path('/tmp/imaginary_projection_review/check_quotient.json');assert not output.exists()
output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='script_source_utf8'},indent=2))
