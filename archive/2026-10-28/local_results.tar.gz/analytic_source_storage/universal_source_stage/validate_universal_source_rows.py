"""Two predeclared source-energy controls; no retries, optimization or rank claim."""
import argparse
from fractions import Fraction as F
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

PLANS={0:dict(working_bits=4096,tolerance_digits=750),49:dict(working_bits=2048,tolerance_digits=350)}
EXPORT_BITS=1536

def worker(args):
    sys.path.insert(0,args.arb_path)
    import flint
    from flint import arb,acb,ctx
    from smatrix_bootstrap.amplitudes import basis_labels,allowed_waves
    from smatrix_bootstrap.universal_partial_wave_masters import evaluate_K_family,source_rows_from_K,enclosing_export_row,ball_fraction,scalar_record
    started=time.monotonic();deadline=started+175;plan=PLANS[args.node];ctx.prec=plan['working_bits']
    M=N=50;maxspin=19;angle=F(2*args.node+1,4*M);cosine=ball_fraction(angle).cos_pi()
    s=4/(cosine*cosine);p=2/cosine;k=(p-2)/(p+2)
    phases=[acb(ball_fraction(F((2*args.node+1)*n,2*M)).cos_pi(),ball_fraction(F((2*args.node+1)*n,2*M)).sin_pi()) for n in range(N+1)]
    assert phases[50].real.is_zero() and abs(phases[50].imag)==1
    C=3+8*(s+4)/(s-4)+4*(s+12)/(s-4);T=32/(s-4);previous=arb(1);current=1+2*T;largest=current
    for ell in range(1,maxspin):
        previous,current=current,((2*ell+1)*(1+2*T)*current+ell*previous)/(ell+1)
        if current>largest:largest=current
    laurent=largest*(arb(2)**N);gain=10*laurent*C**98
    reports=[];last=dict(completed_K_integrals=0);status='completed';error=None
    def progress(done,total,counts):
        last.update(completed_K_integrals=done,counts=dict(counts))
        if done%20==0 or done==total:print(json.dumps(dict(stage='K',done=done,total=total,elapsed_seconds=time.monotonic()-started)),flush=True)
    out=dict(schema='smatrix-universal-source-endpoint-v1',M=M,N=N,node_zero_based=args.node,maximum_spin=maxspin,
        allowed_source_wave_count=30,coefficient_count=len(basis_labels(N)),working_precision_bits=plan['working_bits'],
        export_precision_bits=EXPORT_BITS,tolerance_digits=plan['tolerance_digits'],absolute_tolerance='1e-'+str(plan['tolerance_digits']),
        relative_tolerance='1e-'+str(plan['tolerance_digits']),source_energy=scalar_record(s),compact_energy_k=scalar_record(k),
        source_cos_pi_argument=str(angle),K_indices=list(range(-38,51)),exact_Nyquist_real_zero=True,
        Nyquist_imaginary=str(phases[50].imag.mid().fmpq()),python_flint_version=flint.__version__,quadrature_retries=0,
        automatic_precision_changes=0,no_optimization_performed=True,no_rank_claim=True,
        error_budget=dict(border_recurrence_factor=scalar_record(C**98),Laurent_binomial_factor=scalar_record(laurent),
            combined_including_assembly_factor10=scalar_record(gain),log10_combined=scalar_record(gain.log()/arb(10).log()),
            uniform_K1_modulus_bound=scalar_record(k/2*((1-k)**-38)),
            qualification='Budget for propagated quadrature error only; actual interval radii decide final accuracy.'))
    rows_path=Path(str(args.prefix)+'.rows.json.gz')
    try:
        K0,K1,info=evaluate_K_family(s,k,N,maxspin,tolerance_digits=plan['tolerance_digits'],deadline=deadline,progress=progress)
        out['K_family']=info;out['K_elapsed_seconds']=time.monotonic()-started;waves=list(allowed_waves(10))
        with gzip.open(rows_path,'wt',compresslevel=1) as stream:
            header=dict(schema='smatrix-enclosing-source-rows-v1',M=M,N=N,node_zero_based=args.node,
                working_precision_bits=plan['working_bits'],export_precision_bits=EXPORT_BITS,
                exact_source_energy='4/cos_pi('+str(angle)+')^2',canonical_wave_order=[list(v) for v in waves],
                source_basis_labels=[list(v) for v in basis_labels(N)],
                scalar_encoding='null is exact zero; otherwise [[hex_midpoint_integer,binary_exponent],[hex_radius_integer,binary_exponent]]',
                complex_encoding='[real_ball,imaginary_ball]')
            stream.write(json.dumps(header,separators=(',',':'))[:-1]+',"rows":[');first=True
            for I,ell,row,border in source_rows_from_K(K0,K1,s,phases,N,maxspin):
                if time.monotonic()>=deadline:raise ValueError('Whole-worker deadline reached during row generation')
                encoded,accuracy=enclosing_export_row(row,EXPORT_BITS)
                item=dict(isospin=I,ell=ell,canonical_wave_index=waves.index((I,ell)),coefficients=encoded)
                if not first:stream.write(',')
                first=False;stream.write(json.dumps(item,separators=(',',':')))
                reports.append(dict(isospin=I,ell=ell,canonical_wave_index=item['canonical_wave_index'],
                    coefficient_count=len(row),border=border,accuracy=accuracy))
            stream.write(']}')
        out.update(rows_path=str(rows_path),rows_sha256=hashlib.sha256(rows_path.read_bytes()).hexdigest(),rows_bytes=rows_path.stat().st_size)
    except (ValueError,ArithmeticError,ZeroDivisionError) as exc:status='deadline_or_unresolved';error=str(exc)
    out.update(status=status,error=error,completed_source_rows=len(reports),rows=reports,last_progress=last,
        all30rows_enclosed=len(reports)==30 and status=='completed',
        all_exported_absolute_1e_minus_80_goals_met=len(reports)==30 and all(row['accuracy'][part]['absolute_1e_minus_80_goal_met'] for row in reports for part in ['exported_real','exported_imaginary']),
        elapsed_seconds=time.monotonic()-started,
        scope='One exact source energy, all source spins and all N50 columns. No full-grid operator, inverse or analytic-rank certificate.')
    Path(str(args.prefix)+'.json').write_text(json.dumps(out,indent=2)+'\n')

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--node',type=int,choices=sorted(PLANS),required=True)
    parser.add_argument('--output-prefix',type=Path);parser.add_argument('--arb-path',default='/tmp/collocation_arb')
    parser.add_argument('--worker',action='store_true',help=argparse.SUPPRESS);args=parser.parse_args()
    args.prefix=args.output_prefix or Path('results/universal_source_N50_j'+str(args.node))
    metadata=Path(str(args.prefix)+'.json');rows=Path(str(args.prefix)+'.rows.json.gz')
    if metadata.exists() or rows.exists():raise FileExistsError('Use a new immutable output prefix')
    if args.worker:worker(args);return
    paths=[Path(__file__),Path('src/smatrix_bootstrap/universal_partial_wave_masters.py'),Path('src/smatrix_bootstrap/partial_wave_master_prototype.py'),Path('src/smatrix_bootstrap/rational_partial_wave.py'),Path('src/smatrix_bootstrap/amplitudes.py')]
    sources={str(p):p.read_text() for p in paths};started=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='universal_source_rows_') as tmp:
        child=Path(tmp)/'endpoint';cmd=[sys.executable,str(Path(__file__).resolve()),'--worker','--node',str(args.node),'--output-prefix',str(child),'--arb-path',args.arb_path]
        try:
            proc=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
            childmeta=Path(str(child)+'.json');childrows=Path(str(child)+'.rows.json.gz')
            if proc.returncode==0 and childmeta.exists():
                out=json.loads(childmeta.read_text())
                if out.get('all30rows_enclosed'):
                    shutil.copyfile(childrows,rows);out['rows_path']=str(rows)
                    assert hashlib.sha256(rows.read_bytes()).hexdigest()==out['rows_sha256']
            else:out=dict(status='worker_error',all30rows_enclosed=False,error=proc.stderr[-4000:])
            out['worker_stdout']=proc.stdout;out['worker_stderr']=proc.stderr
        except subprocess.TimeoutExpired as exc:
            out=dict(status='hard_time_limit',all30rows_enclosed=False,error='One predeclared180-second worker terminated; no completed operator claimed',worker_stdout=(exc.stdout or b'').decode(errors='replace') if isinstance(exc.stdout,bytes) else exc.stdout)
    out.update(node_zero_based=args.node,predeclared_plan=PLANS[args.node],hard_worker_time_limit_seconds=180,
        supervisor_elapsed_seconds=time.monotonic()-started,source_snapshot_utf8=sources,
        source_sha256={p:hashlib.sha256(t.encode()).hexdigest() for p,t in sources.items()},
        source_files_changed_during_run=[p for p,t in sources.items() if Path(p).read_text()!=t],command_argv=sys.argv)
    metadata.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({key:out.get(key) for key in ['status','node_zero_based','all30rows_enclosed','all_exported_absolute_1e_minus_80_goals_met','rows_bytes','supervisor_elapsed_seconds']}))

if __name__=='__main__':main()
