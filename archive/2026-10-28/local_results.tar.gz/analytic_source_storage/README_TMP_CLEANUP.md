# /tmp 分段目录的归档说明（2026-09-18）

`results/*.json` 中出现的 `/tmp/<stage>` 路径是 2026-09-05/06 算子推导时的原始暂存位置。2026-09-18 逐字节比对（`diff -rq`）后确认下列目录与本目录同名子目录完全一致，随后删除了 /tmp 中的副本：

| 原路径 | 归档位置 |
|---|---|
| `/tmp/source_full_grid_stage` | `source_full_grid_stage/` |
| `/tmp/source_imaginary_rank_stage/physical_4096_attempt01` | `physical_4096_attempt01/` |
| `/tmp/source_imaginary_rank_stage/{minor_4096_attempt01, minor_residual_1024_2048_attempt01, reduction_preparation.json, test_imaginary_rank_residual.py}` | `source_imaginary_rank_stage/` |
| `/tmp/universal_source_stage` | `universal_source_stage/`（`validate_universal_source_rows.py` 此次补入） |
| `/tmp/source_subthreshold_gauss_stage` | `source_subthreshold_gauss_stage/`（三个 `.py` 此次补入） |
| `/tmp/smatrix_threshold_source_stage`, `/tmp/source_subthreshold_stage`, `/tmp/analytic_source_registry_stage`, `/tmp/source_local_block_stage`, `/tmp/source_integer_residual_audit_stage`, `/tmp/smatrix_source_operator_bundle` | 同名子目录 |
| `/tmp/canonical_seed_reduced.json`（`verification_full_analytic_rank.json` 等引用的 Clarabel 锥形式导出） | `canonical_seed_reduced.json` |
| `/tmp/collocation_arb`（python-flint 0.9.0 的临时安装） | 不归档；同版本已在 miniconda 环境中，`REPRODUCTION_GUIDE_ZH.md` 已改 |

本目录被 `.git/info/exclude` 排除在 git 之外，只存在于工作树。
