"""One fixed Gauss rule and five independently enclosed subthreshold operators."""
import argparse
from collections import Counter
from decimal import Decimal,localcontext
from fractions import Fraction as F
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

REPO=Path('/home/shiqiu/s-matrix-bootstrap')
ENERGIES=[F(1,2),F(1),F(3,2),F(2),F(3)]
WAVES=[(0,0),(1,1),(2,0)]


def digest(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def write_new(path,value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())


def decimal(value):
    with localcontext() as ctx:
        ctx.prec=20;return str(Decimal(value.numerator)/Decimal(value.denominator))


def exact_endpoints(value):
    if value is None:return F(0),F(0)
    m=F(int(value[0][0],16))*F(2)**value[0][1]
    r=F(int(value[1][0],16))*F(2)**value[1][1]
    if r<0:raise ArithmeticError('Negative serialized radius')
    return m-r,m+r


def compare_K(args,node,rows_payload):
    source_path=args.K_stage/f'node_{node}.json'
    plan,_=load_plan(args);expected=plan['K_inputs'][node]
    if digest(source_path)!=expected['summary_sha256']:raise ValueError('Frozen K summary hash mismatch')
    source=json.loads(source_path.read_text());rows_path=Path(source['rows_path'])
    if source['exact_energy']!=str(ENERGIES[node]) or not source['all3_rows_enclosed']:
        raise ValueError('K operator identity or completeness mismatch')
    if digest(rows_path)!=source['rows_sha256'] or source['rows_sha256']!=expected['rows_sha256']:
        raise ValueError('K row archive hash mismatch')
    with gzip.open(rows_path,'rt') as stream:other=json.load(stream)
    if other['source_basis_labels']!=rows_payload['source_basis_labels']:
        raise ValueError('The independent source basis labels differ')
    if other['exact_energy']!=rows_payload['exact_energy']:raise ValueError('Exact energies differ')
    K_rows={(r['isospin'],r['ell']):r for r in other['rows']}
    counts=Counter();details=[];misses=[]
    for row in rows_payload['rows']:
        identity=row['isospin'],row['ell'];K=K_rows[identity]
        if not len(row['coefficients'])==len(K['coefficients'])==3876:raise ValueError('Wrong coefficient count')
        row_counts=Counter();maximum_radius=maximum_midpoint=F(0);zeros=0
        for index,(a,b) in enumerate(zip(row['coefficients'],K['coefficients'])):
            if a[1] is not None or b[1] is not None:raise ArithmeticError('Imaginary subthreshold coefficient is not exact zero')
            g0,g1=exact_endpoints(a[0]);k0,k1=exact_endpoints(b[0])
            lo,hi=max(g0,k0),min(g1,k1)
            if lo>hi:
                misses.append(dict(isospin=identity[0],ell=identity[1],coefficient=index))
                continue
            if (g0,g1)==(k0,k1):relation='equal_intervals'
            elif g0<=k0 and k1<=g1:relation='Gauss_contains_K'
            elif k0<=g0 and g1<=k1:relation='K_contains_Gauss'
            else:relation='overlapping_neither_contains'
            row_counts[relation]+=1
            maximum_radius=max(maximum_radius,(hi-lo)/2)
            maximum_midpoint=max(maximum_midpoint,abs((hi+lo)/2))
            zeros+=int(lo==hi==0)
        counts.update(row_counts)
        ratio=maximum_radius/maximum_midpoint
        details.append(dict(isospin=identity[0],ell=identity[1],counts=dict(row_counts),exact_zero_intersections=zeros,
            maximum_intersection_radius=str(maximum_radius),maximum_intersection_radius_decimal=decimal(maximum_radius),
            maximum_absolute_intersection_midpoint=str(maximum_midpoint),
            intersection_radius_over_midpoint=str(ratio),intersection_radius_over_midpoint_decimal=decimal(ratio)))
    return dict(K_summary=str(source_path),K_summary_sha256=digest(source_path),K_rows=str(rows_path),K_rows_sha256=source['rows_sha256'],
        real_coefficients_checked=3*3876,all_imaginary_components_exact_zero=True,
        all_exact_intersections_nonempty=not misses,comparison_counts=dict(counts),disjoint_intervals=misses,
        rows=details,arithmetic='Exact rational midpoint/radius endpoint comparisons, no Float64 decisions',
        intersection_row_archive_written=False)


def load_plan(args):
    path=args.stage/'plan.json';plan=json.loads(path.read_text())
    for name,want in plan['source_sha256'].items():
        if digest(name)!=want:raise ValueError('Source changed after predeclared plan: '+name)
    return plan,digest(path)


def rule_worker(args):
    from flint import arb,ctx
    from smatrix_bootstrap.subthreshold_gauss_moments import positive_gauss_rule,encode,record
    plan,plan_hash=load_plan(args);ctx.prec=1024;started=time.monotonic();deadline=started+175
    def progress(done,total):
        if done%100==0:print(json.dumps(dict(stage='positive_rule',done=done,total=total,elapsed_seconds=time.monotonic()-started)),flush=True)
    nodes,weights=positive_gauss_rule(1200,deadline=deadline,progress=progress)
    out=dict(schema='smatrix-subthreshold-positive-Gauss-rule-v1',order=1200,precision_bits=1024,
        positive_nodes_generated=600,negative_nodes_generated=0,negative_rule_by_exact_reflection=True,
        nodes=[encode(n) for n in nodes],weights=[encode(w) for w in weights],
        positive_weight_sum=record(sum(weights,arb(0))),all_nodes_positive_and_separated=True,
        maximum_node_radius=record(max(n.rad() for n in nodes)),maximum_weight_radius=record(max(w.rad() for w in weights)),
        predeclared_plan_sha256=plan_hash,source_sha256=plan['source_sha256'],
        elapsed_seconds=time.monotonic()-started,precision_changes=0,rule_retries=0,status='completed')
    write_new(args.stage/'rule.json',out)


def node_worker(args):
    from flint import ctx
    from smatrix_bootstrap.amplitudes import basis_labels
    from smatrix_bootstrap.subthreshold_gauss_moments import (decode,encode,record,conformal_moments,
        independent_three_wave_rows,row_diagnostics)
    plan,plan_hash=load_plan(args);ctx.prec=1024;started=time.monotonic();deadline=started+175
    node=args.node;s=ENERGIES[node];rule_path=args.stage/'rule.json';rule=json.loads(rule_path.read_text())
    if rule['predeclared_plan_sha256']!=plan_hash or rule['status']!='completed':raise ValueError('Rule provenance mismatch')
    if rule['order']!=1200 or rule['precision_bits']!=1024:raise ValueError('Rule budget changed')
    nodes=[decode(v) for v in rule['nodes']];weights=[decode(v) for v in rule['weights']]
    matrices,proof=conformal_moments(s,50,nodes,weights,rho=F(3,2),deadline=deadline)
    rows,zs=independent_three_wave_rows(matrices,s,50)
    print(json.dumps(dict(stage='node_rows',node=node,elapsed_seconds=time.monotonic()-started)),flush=True)
    rows_payload=dict(schema='smatrix-enclosing-subthreshold-rows-v1',N=50,exact_energy=str(s),
        canonical_wave_order=[list(w) for w in WAVES],source_basis_labels=[list(v) for v in basis_labels(50)],
        export_precision_bits=1024,encoding='Exact dyadic midpoint/radius hex pairs; null is exact zero.',
        rows=[dict(isospin=I,ell=ell,canonical_wave_index=index,coefficients=[[encode(v),None] for v in row])
              for index,((I,ell),row) in enumerate(zip(WAVES,rows))])
    path=args.stage/f'node_{node}.rows.json.gz'
    with path.open('xb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=1,mtime=0) as stream:
            stream.write(json.dumps(rows_payload,separators=(',',':')).encode())
        raw.flush();os.fsync(raw.fileno())
    diagnostics=[dict(isospin=I,ell=ell,**row_diagnostics(row)) for (I,ell),row in zip(WAVES,rows)]
    comparison=compare_K(args,node,rows_payload)
    if time.monotonic()>=deadline:raise TimeoutError('Node reached fixed 175-second deadline')
    out=dict(schema='smatrix-independent-subthreshold-Gauss-node-v1',node_index=node,N=50,exact_energy=str(s),
        order=1200,precision_bits=1024,rho='3/2',proof=proof,direct_channel_z=record(zs),
        all3_rows_enclosed=True,all_imaginary_entries_exactly_zero=True,
        actual_absolute_radius_goal_met=all(d['actual_absolute_1e_minus_180_goal_met'] for d in diagnostics),
        rows=diagnostics,rows_path=str(path),rows_sha256=digest(path),rows_bytes=path.stat().st_size,
        independent_K_comparison=comparison,rule_path=str(rule_path),rule_sha256=digest(rule_path),
        predeclared_plan_sha256=plan_hash,source_sha256=plan['source_sha256'],
        elapsed_seconds=time.monotonic()-started,precision_changes=0,quadrature_retries=0,
        status='completed',scope='Independent fixed-energy source rows and exact interval comparison; no rank or optimization claim')
    write_new(args.stage/f'node_{node}.json',out)


def supervise(args,kind,node=None):
    stem='rule' if kind=='rule' else f'node_{node}'
    if (args.stage/(stem+'.attempt.json')).exists():raise FileExistsError('An existing scientific attempt is never retried')
    write_new(args.stage/(stem+'.attempt.json'),dict(kind=kind,node=node,hard_cap_seconds=180,retries=0))
    command=[sys.executable,str(Path(__file__).resolve()),'--worker',kind,'--stage',str(args.stage),
             '--K-stage',str(args.K_stage),'--arb-path',args.arb_path]
    if node is not None:command.extend(['--node',str(node)])
    started=time.monotonic();timed_out=False
    with (args.stage/(stem+'.stdout')).open('x') as stdout,(args.stage/(stem+'.stderr')).open('x') as stderr:
        process=subprocess.Popen(command,stdout=stdout,stderr=stderr,cwd=REPO)
        try:process.wait(timeout=180)
        except subprocess.TimeoutExpired:process.kill();process.wait();timed_out=True
    metadata=args.stage/(stem+'.json')
    result=dict(kind=kind,node=node,worker_exit_code=process.returncode,hard_time_limit=timed_out,
        elapsed_seconds=time.monotonic()-started,metadata_path=str(metadata),
        metadata_sha256=digest(metadata) if metadata.exists() else None,
        status='completed' if process.returncode==0 and metadata.exists() and not timed_out else 'unresolved',
        command_argv=command,scientific_partial_outputs_preserved=True,retries=0)
    write_new(args.stage/(stem+'.status.json'),result)
    print(json.dumps(result),flush=True)
    return result


def run(args):
    args.stage.mkdir(mode=0o700,parents=True,exist_ok=True)
    if args.stage.stat().st_mode&0o077:raise ValueError('Scientific staging directory must be private')
    if (args.stage/'plan.json').exists():raise FileExistsError('Do not overwrite the predeclared scientific plan')
    if shutil.disk_usage(args.stage).free<100*1024**2:raise OSError('Insufficient private staging space')
    sources=[Path(__file__).resolve(),REPO/'src/smatrix_bootstrap/subthreshold_gauss_moments.py',
             REPO/'src/smatrix_bootstrap/amplitudes.py']
    K_coverage=args.K_stage/'coverage.json';K=json.loads(K_coverage.read_text())
    if not K['all_five_complete_and_accepted']:raise ValueError('The five comparison K operators are incomplete')
    K_inputs=[]
    for node in range(5):
        path=args.K_stage/f'node_{node}.json';source=json.loads(path.read_text())
        if digest(source['rows_path'])!=source['rows_sha256']:raise ValueError('K input hash mismatch')
        K_inputs.append(dict(summary_path=str(path),summary_sha256=digest(path),
            rows_path=source['rows_path'],rows_sha256=source['rows_sha256']))
    plan=dict(schema='smatrix-subthreshold-independent-Gauss-plan-v1',energies=list(map(str,ENERGIES)),
        degree=50,order=1200,precision_bits=1024,rho='3/2',positive_nodes_generated=600,
        rule_worker_cap_seconds=180,per_energy_cap_seconds=180,callback_deadline_seconds=175,
        automatic_precision_changes=0,automatic_retries=0,
        K_coverage_path=str(K_coverage),K_coverage_sha256=digest(K_coverage),K_inputs=K_inputs,
        source_sha256={str(p):digest(p) for p in sources},source_snapshot_utf8={str(p):p.read_text() for p in sources})
    write_new(args.stage/'plan.json',plan)
    rule=supervise(args,'rule');nodes=[]
    if rule['status']=='completed':
        for node in range(5):nodes.append(supervise(args,'node',node))
    completed=[];counts=Counter();misses=[]
    for status in nodes:
        if status['status']=='completed':
            report=json.loads(Path(status['metadata_path']).read_text())
            completed.append(report)
            counts.update(report['independent_K_comparison']['comparison_counts'])
            misses.extend(dict(node=report['node_index'],**item) for item in report['independent_K_comparison']['disjoint_intervals'])
    complete=len(completed)==5
    coverage=dict(schema='smatrix-subthreshold-independent-Gauss-coverage-v1',
        plan_path=str(args.stage/'plan.json'),plan_sha256=digest(args.stage/'plan.json'),
        rule_status=rule,node_statuses=nodes,all_five_Gauss_operators_enclosed=complete,
        all_exported_absolute_radius_goals_met=complete and all(r['actual_absolute_radius_goal_met'] for r in completed),
        real_coefficients_compared=len(completed)*3*3876,all_imaginary_components_exact_zero=complete,
        all_exact_Gauss_K_intersections_nonempty=complete and not misses,comparison_counts=dict(counts),
        disjoint_intervals=misses,rows=[dict(node_index=r['node_index'],exact_energy=r['exact_energy'],
            rows_path=r['rows_path'],rows_sha256=r['rows_sha256'],rows_bytes=r['rows_bytes'],
            diagnostics=r['rows'],comparison=r['independent_K_comparison']) for r in completed],
        source_files_changed_during_run=[name for name,want in plan['source_sha256'].items() if digest(name)!=want],
        precision_changes=0,retries=0,optimization_runs=0,
        scope='Independent direct Gauss enclosures of five subthreshold source operators. No global rank claim.')
    write_new(args.stage/'coverage.json',coverage)
    print(json.dumps({k:v for k,v in coverage.items() if k in ['all_five_Gauss_operators_enclosed',
        'all_exported_absolute_radius_goals_met','real_coefficients_compared',
        'all_exact_Gauss_K_intersections_nonempty','comparison_counts']}),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage',type=Path,default=Path('/tmp/source_subthreshold_gauss_stage'))
    parser.add_argument('--K-stage',dest='K_stage',type=Path,default=Path('/tmp/source_subthreshold_stage'))
    parser.add_argument('--arb-path',default='/tmp/collocation_arb')
    parser.add_argument('--worker',choices=['rule','node'],help=argparse.SUPPRESS)
    parser.add_argument('--node',type=int,choices=range(5),help=argparse.SUPPRESS)
    args=parser.parse_args();args.stage=args.stage.resolve();args.K_stage=args.K_stage.resolve()
    sys.path.insert(0,args.arb_path);sys.path.insert(0,str(REPO/'src'))
    if args.worker=='rule':rule_worker(args)
    elif args.worker=='node':node_worker(args)
    else:run(args)


if __name__=='__main__':main()
