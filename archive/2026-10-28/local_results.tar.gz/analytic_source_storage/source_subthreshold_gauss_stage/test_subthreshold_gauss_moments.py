"""Independent analytic controls for the direct subthreshold Gauss method."""
from fractions import Fraction as F
from math import factorial
import numpy as np
import pytest

pytest.importorskip('flint')
from flint import arb,ctx
from smatrix_bootstrap.subthreshold_gauss_moments import (
    positive_gauss_rule,reflected_moment_matrix,ellipse_tail,conformal_moments,
    independent_three_wave_rows,ball,encode,decode)


@pytest.fixture(autouse=True)
def fixed_precision():
    old=ctx.prec;ctx.prec=256
    yield
    ctx.prec=old


def test_positive_rule_reflection_integrates_every_low_polynomial_exactly():
    nodes,weights=positive_gauss_rule(8)
    assert len(nodes)==4 and all(n>0 and w>0 for n,w in zip(nodes,weights))
    for degree in range(16):
        integral=sum((w*(n**degree+(-n)**degree) for n,w in zip(nodes,weights)),arb(0))
        expected=arb(0) if degree%2 else arb(2)/(degree+1)
        assert integral.contains(expected)


def test_native_reflected_matrix_matches_exact_beta_moments_and_odd_sign():
    nodes,weights=positive_gauss_rule(8);degree=4
    xp=[[(1-n)**p/arb(2)**p for p in range(degree+1)] for n in nodes]
    yp=[[(1+n)**p/arb(2)**p for p in range(degree+1)] for n in nodes]
    for ell in [0,1]:
        M=reflected_moment_matrix(xp,yp,nodes,weights,ell)
        for n in range(degree+1):
            for m in range(degree+1):
                value=F(factorial(n)*factorial(m),2*factorial(n+m+1))
                if ell:value*=F(m-n,n+m+2)
                assert M[n,m].contains(ball(value)),(ell,n,m)
        if ell:assert M[1,0]<0 and M[0,1]>0


@pytest.mark.parametrize('s',[F(1,2),F(3)])
def test_three_independent_assembled_rows_match_direct_source_basis_projection(s):
    from smatrix_bootstrap.amplitudes import amplitude_basis
    from numpy.polynomial.legendre import leggauss
    nodes,weights=positive_gauss_rule(64);degree=3
    matrices,proof=conformal_moments(s,degree,nodes,weights)
    rows,zs=independent_three_wave_rows(matrices,s,degree)
    assert proof['maximum_crossed_real_part']==str((4-s)*F(25,24))
    assert matrices[0][0][0]==arb(1)/2
    assert all(matrices[1][n][n].is_zero() for n in range(degree+1))
    x,w=leggauss(100);t=(4-float(s))*(1-x)/2;u=(4-float(s))*(1+x)/2
    A=amplitude_basis(float(s),t,u,degree)
    B=amplitude_basis(t,float(s),u,degree)
    C=amplitude_basis(u,t,float(s),degree)
    expected=[(w/4)@(3*A+B+C),(w*x/4)@(B-C),(w/4)@(B+C)]
    for row,want in zip(rows,expected):
        actual=np.array([float(v.mid()) for v in row])
        assert np.max(np.abs(actual-want))<3e-14
    assert rows[0][0]==arb(5)/2 and rows[1][0].is_zero() and rows[2][0]==1
    assert 0<zs<1


def test_tail_requires_admissible_ellipse_and_even_positive_rule():
    error,crossed=ellipse_tail(F(1,2),1200,1)
    assert crossed==F(175,48) and error==6*F(3,2)**-2399
    with pytest.raises(ValueError,match='cut'):ellipse_tail(F(1,100),8,0)
    with pytest.raises(ValueError,match='even'):positive_gauss_rule(7)
    with pytest.raises(TimeoutError):positive_gauss_rule(8,deadline=0)


def test_serialization_preserves_exact_zero_and_encloses_original_ball():
    values=[arb(0),arb(1)/3,arb((1,-2000),(1,-2500))]
    assert encode(values[0]) is None
    for value in values:assert decode(encode(value)).contains(value)
