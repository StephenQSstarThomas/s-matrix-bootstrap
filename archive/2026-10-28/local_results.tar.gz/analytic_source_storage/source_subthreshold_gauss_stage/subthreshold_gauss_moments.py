"""Independent validated subthreshold angular moments using native Arb.

No universal K moments or crossed-moment recurrence is used. Reflection
restores the complete Gauss rule. Explicit ellipse tails precede assembly.
"""
from fractions import Fraction as F
import time
from .amplitudes import basis_labels


def ball(value):
    from flint import arb
    value=F(str(value));return arb(value.numerator)/value.denominator


def record(value):
    if not value.is_finite():raise ArithmeticError('Nonfinite real enclosure')
    return dict(ball=value.str(35),lower_rational=str(value.lower().fmpq()),
                upper_rational=str(value.upper().fmpq()))


def encode(value):
    if value.is_zero():return None
    if not value.is_finite():raise ArithmeticError('Nonfinite serialized enclosure')
    m,e=value.mid().man_exp();r,re=value.rad().man_exp()
    return [[hex(int(m)),int(e)],[hex(int(r)),int(re)]]


def decode(value):
    from flint import arb
    if value is None:return arb(0)
    return arb((int(value[0][0],16),value[0][1]),(int(value[1][0],16),value[1][1]))


def check_deadline(deadline):
    if deadline is not None and time.monotonic()>=deadline:
        raise TimeoutError('Predeclared Gauss worker deadline reached')


def positive_gauss_rule(order,*,deadline=None,progress=None):
    """Enclose only the positive half of an even-order Legendre rule."""
    from flint import arb
    if not isinstance(order,int) or order<2 or order%2:
        raise ValueError('A positive even Gauss-Legendre order is required')
    nodes=[];weights=[]
    for index in range(order//2):
        check_deadline(deadline)
        node,weight=arb.legendre_p_root(order,index,weight=True)
        if not (0<node<1 and weight>0):raise ArithmeticError('Positive Gauss node or weight unresolved')
        if nodes and not nodes[-1]>node:raise ArithmeticError('Distinct decreasing roots unresolved')
        nodes.append(node);weights.append(weight)
        if progress is not None:progress(index+1,order//2)
    if not sum(weights,arb(0)).contains(1):raise ArithmeticError('Half-rule weights do not enclose one')
    return nodes,weights


def ellipse_tail(s,order,ell,rho=F(3,2)):
    """Exact full moment error for an admissible subthreshold ellipse."""
    s,rho=F(str(s)),F(str(rho))
    if not 0<s<4 or rho<=1:raise ValueError('A fixed0<s<4 and rho>1 are required')
    if not isinstance(order,int) or order<2 or order%2:raise ValueError('Positive even Gauss order required')
    if ell not in (0,1):raise ValueError('This control covers ell=0,1')
    semiaxis=(rho+1/rho)/2;crossed_maximum=(4-s)*(1+semiaxis)/2
    if crossed_maximum>=4:raise ValueError('The ellipse reaches a crossed conformal cut')
    return 2*rho**(ell-2*order)/(1-1/rho),crossed_maximum


def reflected_moment_matrix(xpowers,ypowers,nodes,weights,ell):
    """Native X^T diag(w P_l/4) Y plus signed transpose, before tail.

    The power arrays have one row per positive node. Reflection must exchange
    X and Y; this also permits independent polynomial toy tests.
    """
    from flint import arb_mat
    if ell not in (0,1) or not nodes or len(nodes)!=len(weights):
        raise ValueError('Matching positive-half rule and ell=0,1 required')
    if len(xpowers)!=len(nodes) or len(ypowers)!=len(nodes):
        raise ValueError('Power-matrix rows must match the positive rule')
    size=len(xpowers[0])
    if not size or any(len(row)!=size for row in xpowers+ypowers):
        raise ValueError('Matching rectangular power matrices required')
    factors=[w*(x if ell else 1)/4 for x,w in zip(nodes,weights)]
    weighted_y=[[factor*v for v in row] for factor,row in zip(factors,ypowers)]
    B=arb_mat(xpowers).transpose()*arb_mat(weighted_y)
    return B+B.transpose() if ell==0 else B-B.transpose()


def conformal_moments(s,degree,nodes,weights,*,rho=F(3,2),deadline=None):
    """Direct M0/M1 matrices with the proved complete-rule error added.

    Nodes/weights must be the enclosing half-rule from positive_gauss_rule,
    or an authenticated lossless serialization of that rule.
    """
    from flint import arb
    s=F(str(s))
    if not isinstance(degree,int) or degree<1:raise ValueError('A positive full amplitude degree required')
    order=2*len(nodes);tails=[ellipse_tail(s,order,ell,rho) for ell in [0,1]]
    sb=ball(s);xpowers=[];ypowers=[]
    for node in nodes:
        check_deadline(deadline)
        t=(4-sb)*(1-node)/2;u=(4-sb)*(1+node)/2
        rt,ru=(4-t).sqrt(),(4-u).sqrt()
        if not rt>0 or not ru>0:raise ArithmeticError('Real crossed square-root branch unresolved')
        X,Y=(2-rt)/(2+rt),(2-ru)/(2+ru)
        if not (0<X<1 and 0<Y<1):raise ArithmeticError('Crossed conformal value outside(0,1)')
        px=[arb(1)];py=[arb(1)]
        for _ in range(degree):px.append(px[-1]*X);py.append(py[-1]*Y)
        xpowers.append(px);ypowers.append(py)
    matrices=[]
    for ell in [0,1]:
        check_deadline(deadline)
        quadrature=reflected_moment_matrix(xpowers,ypowers,nodes,weights,ell)
        error=arb(0,ball(tails[ell][0]).upper())
        matrix=[[arb(0) for _ in range(degree+1)] for _ in range(degree+1)]
        for n in range(degree+1):
            for m in range(n+1):
                value=quadrature[n,m]+error
                if ell and n==m:
                    if not value.contains(0):raise ArithmeticError('Odd diagonal does not enclose zero')
                    value=arb(0)
                elif n==m==0:
                    if not value.contains(arb(1)/2):raise ArithmeticError('Constant moment misses one half')
                    value=arb(1)/2
                matrix[n][m]=value;matrix[m][n]=-value if ell else value
        matrices.append(matrix)
    return matrices,dict(order=order,positive_node_count=len(nodes),rho=str(rho),
        ellipse_semiaxis=str((F(rho)+1/F(rho))/2),maximum_crossed_real_part=str(tails[0][1]),
        moment_error_bounds=[str(v[0]) for v in tails],
        construction='Native half-rule matrix products, exact reflection, proved quadrature tails; no K or mixed recurrence')


def independent_three_wave_rows(matrices,s,degree):
    """Independent assembly of I0S/I1P/I2S from the source monomials."""
    from flint import arb
    M0,M1=matrices
    if any(len(M)!=degree+1 or any(len(row)!=degree+1 for row in M) for M in matrices):
        raise ValueError('Complete moment matrices matching the degree required')
    root=(4-ball(s)).sqrt();zs=(2-root)/(2+root);powers=[arb(1)]
    for _ in range(degree):powers.append(powers[-1]*zs)
    rows=[[],[],[]]
    for kind,n,m in basis_labels(degree):
        if kind=='constant':values=[arb(5)/2,arb(0),arb(1)]
        elif kind=='single_s':values=[3*powers[n]/2+2*M0[n][0],2*M1[n][0],2*M0[n][0]]
        elif kind=='single_tu':values=[powers[n]+8*M0[n][0],-2*M1[n][0],powers[n]+2*M0[n][0]]
        elif kind=='double_s_tu':
            values=[6*powers[n]*M0[m][0]+2*powers[m]*M0[n][0]+2*M0[n][m],
                    2*powers[m]*M1[n][0]+2*M1[n][m],2*powers[m]*M0[n][0]+2*M0[n][m]]
        elif kind=='double_tu':
            term=powers[n]*M0[m][0]+powers[m]*M0[n][0]
            values=[3*M0[n][m]+term,-(powers[n]*M1[m][0]+powers[m]*M1[n][0]),term]
        else:raise ValueError('Unknown source amplitude basis label')
        for row,value in zip(rows,values):
            if not value.is_finite():raise ArithmeticError('Nonfinite source coefficient')
            row.append(value)
    return rows,zs


def row_diagnostics(row):
    """Compare exact midpoint/radius maxima without Float64 underflow."""
    from flint import arb
    radius=max((v.rad() for v in row),default=arb(0))
    midpoint=max((abs(v.mid()) for v in row),default=arb(0))
    if midpoint==0 and radius!=0:raise ArithmeticError('Row midpoint scale unresolved')
    ratio=radius/midpoint if midpoint>0 else arb(0)
    return dict(maximum_radius=record(radius),maximum_midpoint=record(midpoint),radius_over_midpoint=record(ratio),
        exact_zero_entries=sum(v.is_zero() for v in row),actual_absolute_1e_minus_180_goal_met=bool(radius<ball(F(1,10**180))))
