# B8 — Scoping a V2 dual certificate for the 2309.12402 reproduction (read-only, 2026-10-01)

Scope: no source edits, no solver runs. Paths are relative to `/home/shiqiu/s-matrix-bootstrap` unless they start with
`/playpen1`. The leaf root is `R=/playpen1/shiqiu/sdpb_regularised_20260913`. Numbers marked "float est." come from a
2-minute binary64 evaluation of `sdp.assembly.Operators(50,10)`. They give the order of magnitude only and are not interval results.

## 0. Bottom line
- The PMPs are high-precision. Source rows are rebuilt in Arb at 40 digits and written as 30-digit decimal strings.
  `dual_bound` (gtb/dual.py:53-108) can be fed directly from them.
- Only one leaf solves the full problem: `R/full_M50_L10_linf_1e2_tip/tip`, the C2 chiral tip. It can be certified now without a solve.
- Every other key leaf uses the SVD-reduced basis (c = V a, 1779 of 3876 coordinates). That is a restriction of the
  stated finite problem, so a V2 bound on its emitted PMP cannot certify exclusions of the full problem: faces, SR-1, and the UV tip below the paper.
- The 14 UV variables ρ̂ above s0 have no a-priori bound. They must be eliminated by relaxing those Gram blocks to their 2x2 minor, as 2403 does in §12 B5.

## 1. How the 2309 SDP is assembled (Q1)
- Entry: `sdp/sdpb.py:141-164`, `run_once`. It builds `Pmp(spec, direction, fix_f00, digits=30, …)`. Sections, faces and
  functionals go through `Pmp.from_saved` → `precision_pmp.restore` (17-89) and `write_prepared` (92-135). These copy the
  source leaf's blocks verbatim and append only the section/slab blocks and the new objective.
- Spec: `sdp/spec.py:11-46`. Mainline settings: M=50, L=10, chi-b with ε^χ=0.002, mixed-pv, cone_scaling=rownorm, `reg_norm='linf'`,
  `reg_bound=Mreg=100`, operator_dps=40, reduce_basis=True, basis_tol=1e-12.
- Variables: `pmp.py:193-209` has layout `y0 | a | ImF[2M] | ρ̂[2M] | aux`; aux is 0 for linf. The amplitude layout is in
  `sdp/projector.py:53-64`: T0 (1), σ1 (50), σ2 (50), ρ1 (2500), ρ2 symmetric (1275). That gives n_a=3876 and n_ρ=3775.
  The full space has n_vars=3877 (chiral only) or 4077 (UV). The reduced basis uses a=1779 SVD coordinates (`assembly.build_basis` 125-140;
  `basis.npy` is 3876x1779 binary64), so n_vars=1780 or 1980. This is the "1980/3877" in the spec.
- Blocks are built in `pmp.py:236-352`:
  - Unitarity disks, 3x3, `[[2R·c, P_re·c, P_im·c],[·,y0,0],[·,0,y0]]` (245-249). There are 1500, or 1400 in UV, where the S0/P1 disks are
    replaced by Gram blocks (167-170).
  - chi-b: one 9x9 arrow over the 8 chiral residuals (252-265; `_arrow` 397-404).
  - Regulariser `_regulariser_blocks` (354-395). linf gives two 1x1 blocks `1 ∓ ρ_i/Mreg ≥ 0` per ρ value (380-385), 7550 blocks in all.
    In the reduced basis the row is `V[i]/Mreg` (376-377), so the box acts on (V a)_i.
  - UV (286-342): Gram 3x3 per node and current (100); FF 3x3 at nodes 43-49 above s0 (14); ρ̂≥0 as 1x1 (100); FESR 1x1 boxes on
    S0 n=0,1 and P1 n=−1,0 (8; SR-d uses arrows instead).
  - Section f00=x: two 1x1 blocks (345-348). Face slab: one 1x1 block (351-352, `face_row` 462-467).
  - Objective: 470-475; `functional_row`: 444-460.
- Totals: chiral only, 9051 = 1500·3x3 + 1·9x9 + 7550·1x1. UV, 9173 = 1514·3x3 + 1·9x9 + 7658·1x1. A section adds 2 blocks, a face slab adds 1, and SR-1 has 9171.
- Arb path: yes. `precision_pmp.populate` (138-195) takes rows from `PrecisionRows.rows` (precision.py:51) at 183 working bits.
  It projects them in Arb through V, converted exactly from binary64 (155, 165). The cone scale λ² is the binary64 rownorm (183-185).
  The full-space projection took 35 s; reduced took 195-426 s.
- Coefficients are 30-digit decimal strings of the Arb midpoints (`_num`, pmp.py:122-130; `report.pmp.digits=30`). Float-valued
  entries (y0 constants, 1/Mreg=0.01, zeros) are written by `repr`, so "0.01" is exact. They are not doubles. The only
  binary64 ingredient is the coordinate matrix V.
- Existing checks:
  - `sdp/arbaudit.py` (`ArbAudit.audit` 123), called from `precision_pmp.verify` (198-319), is a V1-style Arb re-evaluation of a given y with 1e-8 tolerances.
  - `sdp/dual.py:59-103` reads `out/x_j.txt`→Z (79-89) and certifies only if the residual is exactly zero (91-92, 101). Its PSD test enumerates minors only for n≤12 (45-46).
  - That test exists only as a 1x1 toy in `tests/sdp/test_sdp_constraints.py:60-72`.
  - `convergence.independent_dual_certified` is false in every leaf report inspected.

## 2. Key leaves and their files (Q2)
All leaves are at 192 bit, with 8 ranks, gap 1e-6, and status numerically_accepted. "cand. upper" is SDPB's primalObjective, the Z side.

| claim | leaf (under R) | space | n_vars/blocks | SDPB s | cand. upper | V2 must show |
|---|---|---|---|---|---|---|
| C2 tip ε=.002 | `gate_tip_linf_1e2_unit/tip` | reduced | 1780/9051 | 3161 | 0.0827577 | (C2 ladder value) |
| C2 tip, full | `full_M50_L10_linf_1e2_tip/tip` | **full** | 3877/9051 | 12438 | 0.0827775 | ≤ paper+5% (0.08257) |
| C2 x_ref width | `fig4_eps002_section_hi`, `_lo` (f00=0.0733214, dir (0,±1)) | reduced | 1780/9053 | 3842 | −0.0043718 / … | two-sided band (needs V1 too) |
| UV tip (C5/C6 source) | `uv_SRa_tip/tip` | reduced | 1980/9173 | 4150 | 0.0760138 | < paper 0.0811249 (6.3%) |
| SR-1 | `srmom_SRb_free_S0n0_min/support` (min S0 n=0 moment, SR-b, box freed) | reduced | 1980/9171 | 4714 | −0.0037444 | ≤ −1.1·0.0023851 = −0.0026236 (43%) |
| F1 (elastic) | `face_SRa_tip_ImKH_P1_38_max` | reduced | 1980/9174 | 5743 | 1.49350 | < 1.5 (**0.4%**) |
| F3′ tip | `face_SRa_tip_ImKH_P1_39_max` | reduced | 1980/9174 | – | 0.6346 | < 1 |
| F6 tip | `face_SRa_tip_ImS_P1_38_max` | reduced | 1980/9174 | – | −0.2760 | < 0 |
| F1′ / F3′ x_ref | `face_SRa_xrefhi_ImKH_P1_38_max`, `_39_max` | reduced | 1980/9176 | – | 0.9356 / 0.7010 | < 1 (6.4% / 30%) |
| F1′ / F3′ ffs0 | `face_SRa_ffs0_tip_ImKH_P1_38_max`, `_39_max` | reduced | 1980/9174 | – | 0.3250 / 0.6452 | < 1 |
| C1 (Fig.3) | `fig3_dir00..23` (Mreg=1e3) | reduced | 1780/9050 | – | – | below paper extremes (15-23%) |

- The face sources are `uv_SRa_tip/tip`, `uv_SRa_section_hi`, and `uv_SRa_ffs0_tip/tip`. Each face slab floor is the recorded
  absolute value v*−2e-6, taken from the reduced source.
- The `*_min`, `ImKH_S0_38` and `ImF_P1_38` face leaves are ranges (F2/F4/F5). They need V1, not V2.
- Every leaf above has `pmp.json` (0.86-0.98 GB) and `report.json`. All but the full leaf also have `basis.npy` and `disk_mask.npy`.
  Each has `out/{x_0..x_{nb−1}.txt, y.txt, out.txt}`, plus `solution.npz`, `sdp/` and `sdp.ck/`. The full leaf takes 4.8 GB, of which `sdp.ck` is 3.5 GB.
- No `X_matrix_*.txt` exists anywhere. SDPB ran without `--writeSolution`, which defaults to x,y.
- For a degree-0 PMP, x_j is the column-major upper triangle of Z_j with off-diagonal entries doubled (dual.py:85-89).
  I spot-checked `gate_tip…/tip/out/x_0.txt`:
  - The col-major, halved reading gives a PSD 3x3 with Z00·Z11≈Z01², which is near rank-1 as expected for an active disk.
  - The row-major reading gives Z11<0.
  - The overall scale (bilinear-basis normalisation) is still unverified. P0 covers it.
- The reduced basis is a numerical truncation (`report.basis.scope`: "floating-point SVD truncation, not an exact rank
  certificate"; assembly.py:126-130). The reduced feasible set is a subset of the full one. On the chiral tip the full optimum is
  +2.0e-5 (+0.024%) higher than the reduced one, and the regulariser is active on 44% of ρ slots in full space versus 20% reduced.

## 3. A-priori bounds |y_n| ≤ ȳ_n for 2309 (Q3; analogue of DERIVATION_ZH §12)
- **B0 ρ**: |ρ_i| ≤ Mreg. This is exact and comes from the 1x1 blocks. No aux variables appear for linf.
- **B2 σ**: the prescription is nodal, i.e. Im C[f](s_k+i0)=f_k (projector.py:93-99). With 0.25·T (projector.py:122-148) this gives:
  - Im f^2_0(s_k)=σ2_k+ρ-terms and Im f^0_0(s_k)=(3/2)σ1_k+σ2_k+ρ-terms. All other σ coefficients in these rows are exactly 0 (checked).
  - Since h=κf and 0≤Im h≤2 (from the disk, or from the Gram 2x2 minor in UV leaves): σ̄2_k=(2+β_k)/κ_k and σ̄1_k=(2+σ̄2_k+β′_k)/(1.5κ_k), with
    β=Mreg·Σ|ρ-coef|.
  - Float est. (Mreg=100): κ_k runs 0.049…3.14, β runs 34…1706, σ̄2 ∈ [213, 731], σ̄1 ∈ [497, 1665].
- **B3 T0**: from the I=2, ℓ=0 Re row and |Re h|≤1, |T0| ≤ min_k[1+Σ|a_σ|σ̄+Mreg Σ|a_ρ|]/coef. Float est. 1336 (node 49).
  This is consistent with `c_norm_inf`=548 at the full tip.
- **UV ρ̂, nodes 0-42 (≤s0)**: the FESR moment rows are positive there, so ρ̂_i ≤ min_n (T_n+ε_n)/w_{n,i}. This holds for SR-a; SR-b,
  SR-d and the SR-1 leaf work the same way with their remaining boxes. Float est.: S0 2.2 (node 42) … 1.8e6 (node 0); P1 13 … 4.8e10.
- **ImF**: below s0, the Gram 2x2 minor (rows 2,3) gives 2F_im² ≤ (1−S_re)ρ̂ ≤ 2ρ̂, so |ImF_i| ≤ √ρ̄̂_i. Above s0, the FF block gives |F_i| ≤ cap,
  about 0.072 for S0 and 0.13-0.20 for P1.
- **ρ̂ at nodes 43-49 (14 variables): no bound exists.** These nodes have zero moment weight. The variables appear only in the Gram (3,3) entry and in ρ̂≥0;
  the solver puts about 1e13 there (REPORT_SDPB_2309_ZH §4.0). Exact feasibility would need Z_gram33 = z_i = 0, which an interior Z never has.
  - Fix: certify the relaxation in which those 14 Gram blocks are replaced by their leading 2x2 (|S|≤1), and drop the 14 variables and their 1x1 blocks.
  - In Z, drop row and column 3. This is a tiny change, since |Z13| ≤ √(Z11 Z33), and the Gram repair absorbs it.
  - The relaxation's maximum is ≥ the original, so its bound is valid.
- **τ_j**: the generic `trace_bounds` (gtb/dual.py:191-202) works with these ȳ. It only matters if a PSD shift is needed.
- For the reduced problem only: |a| ≤ ‖c̄‖₂ ≈ 6e3, because V is orthonormal. That makes the machinery runnable there, but it certifies only the restricted problem.

## 4. Minimal plan per leaf and compute (Q4)
Pieces to write go in one new file. Do not edit existing `sdp/*` modules: they are hash-checked by `restore`/`load_saved_basis`.
Do not edit `gtb/dual.py` either: five `gtb solve` drivers are running and import gtb.
- (a) A Z reader for `out/x_j.txt`. `read_dual_matrices` expects `X_matrix_{2j}.txt`.
- (b) Blocks, by one of two routes:
  - Parse `pmp.json` (exact decimals) with `sdp/dual._stream_pmp`. This certifies the emitted PMP. The transfer term to the Arb
    problem is ≤ Σ_j‖Z_j‖₁·δ·(1+Σȳ), with δ ≈ 1e-30 relative.
  - Or rebuild the forms in Arb via the precise `Pmp(spec, …)._blocks()` path (35 s in full space). Convert float entries with `arb(repr(x))`.
    Then cross-check against `pmp.json` to 30 digits.
- (c) A `ybar_2309` implementing §3, in Arb, from the same rows.
- (d) The UV ρ̂>s0 elimination.
- (e) `dual_bound` unchanged, with the objective from `Pmp.objective`/`functional_row`/`face_row`.

Cost per leaf, with no SDPB: about 16.6k (chiral) or 16.9k (UV) forms carrying 17-20 M nonzero coefficients. `dual_bound` densifies each form
(gtb/dual.py:65-70), which means about 64 M Arb conversions and 3-6 GB RAM. The float Gram is 3876²; each Arb residual pass takes about 20-40 s, and there are 9 passes.
The LDL on 9k blocks of size ≤9 takes seconds. Total: about 0.5-1 h on one core.

Steps:
1. **P0 (minutes).** On `full_M50_L10_linf_1e2_tip/tip`, check the x→Z mapping and scale. Expect b0+Σ⟨Z,C⟩ ≈ primalObjective 0.08277754525
   and residual ≈ 1e-47 (`out.txt` primalError 1.0e-47).
2. **P1 (≤1 h, no solve).** Run V2 on the full leaf. This gives the first rigorous 2309 bound: C2 tip, Mreg=100, ε^χ=0.002. Expect about 0.0827776,
   against paper 0.0825728.
3. **P2 calibration (≤1 h, no solve).** Load the reduced `gate_tip_linf_1e2_unit` Z, which has the same 9051-block order, into the
   full-space blocks of P1, run the Gram repair over the full span, and compare with P1.
   - The penalty must be ≥2.0e-5, the full−reduced gap.
   - Heuristic scale: Mreg·Σ|w| ≈ d opt/d ln Mreg, which is about 5e-4 for the chiral tip (Mreg 1e2→1e3: 0.08276→0.08396) and about 3e-4 for the UV tip
     (+0.92%). That is 0.4-0.7% of the objective, plus possible σ̄/T0 terms.
   - If P2 lands at ≲1%, the same route (UV variant with (d)) certifies every big-margin claim with no re-solve: SR-1 (43%),
     UV tip vs paper (6.3%), F3′×3, F6, F1′ x_ref (6.4%), F1′ ffs0, and the C1 FAIL extremes. That is about 12 leaves at ≤1 h CPU each.
4. **P3 full-space re-solves**, only where P2 fails or the margin is tight:
   - F1 elastic (0.4%). In full space the recorded absolute slab floor sits about 10x deeper below the optimum (2e-5 vs 2e-6), so 1.5 may be crossed.
     Re-anchor the floor on a full-space source.
   - C2 sections hi/lo, which any two-sided band needs anyway.
   - The face sources.
   - Measured cost: chiral full 12438 s, versus 3161 s reduced (×3.9). Estimates: UV tip and SR-1 about 4.5 h each; faces about 6 h each.
     All 13 (2 sections + UV tip + SR-1 + 7 faces + 2 more sources) would take about 68 h serial at 8 ranks and 192 bit.
   - Disk: about 4.8 GB per leaf. `/playpen1` has 71 GB free (98% used), so delete `sdp.ck/` and `sdp/` after acceptance.
     Run one solve at a time, in its own workdir. Five gtb SDPB jobs (6 ranks each) are running now.
- Lower bounds (V1, strictly feasible points) for two-sided bands are outside this scope. `arbaudit` verifies feasibility only to 1e-8.

## 5. Recommendation
Do P0 → P1 → P2 first. They are all solver-free, about 3 h of CPU in total, and need one new file importing `gtb.dual.dual_bound`.
P1 gives a rigorous 2309 number on an existing leaf. P2 shows whether the reduced leaves' multipliers already certify the
large-margin exclusions (SR-1, UV tip, F1′/F3′/F6) of the full finite problem. Queue full-space re-solves only for what P2 cannot carry,
starting with F1 elastic, whose margin is 0.4%, and the C2 sections. Treat the ρ̂-above-s0 elimination as a declared relaxation, not a tuning choice.
