"""Validate an authors_M* kernel export (Task A4 step 4). Independent of the writer.

usage: python authors_validate.py EXPORT_DIR [NOTEBOOK_PATH]
Checks: manifest fields; per matrix gz integrity, sha256, line count == prod(shape),
40-digit line format, decimal parse/re-emit round trip, deterministic re-gzip;
shapes from (M, L, n0); n0 recomputed from x <= (2000/139.57)^2; x, xp, K0, Lam,
Lambda3 recomputed with mpmath; B-spline partition of unity; SVZSR vs the
published 12-digit values to 10 significant digits.
"""
import gzip, hashlib, json, re, subprocess, sys
from decimal import Decimal, getcontext
from pathlib import Path
import mpmath as mp

getcontext().prec = 60
mp.mp.dps = 60
LINE = re.compile(r"^(0|-?[1-9][0-9]{39}e-?[0-9]+)$")
SVZ_REF = [3.11259180672e-7, 2.07506120448e-7, 1.55629590336e-7, 5.61716677265e-5,
           2.80858338632e-5, 1.87238892422e-5, 5.13358746336e-5, 2.56679373168e-5, 1.71119582112e-5]
fails = []


def check(cond, msg):
    print(("ok   " if cond else "FAIL ") + msg)
    if not cond:
        fails.append(msg)


def emit(d: Decimal) -> str:
    if d == 0:
        return "0"
    sign, digits, exp = d.as_tuple()
    m = "".join(map(str, digits))
    return ("-" if sign else "") + m + "e" + str(exp)


def load(dirp, man, name):
    ent = man["matrices"][name]
    raw = (dirp / ent["file"]).read_bytes()
    check(hashlib.sha256(raw).hexdigest() == ent["sha256"], f"{name}: sha256 matches manifest")
    text = gzip.decompress(raw)
    redo = subprocess.run(["gzip", "-n", "-6", "-c"], input=text, capture_output=True).stdout
    lines = text.decode("ascii").splitlines()
    n = 1
    for s in ent["shape"]:
        n *= s
    check(len(lines) == n, f"{name}: {len(lines)} lines == prod{tuple(ent['shape'])}")
    bad = [l for l in lines if not LINE.match(l)]
    check(not bad, f"{name}: all lines match <40-digit mantissa>e<exp> or 0" + (f" (first bad {bad[0]!r})" if bad else ""))
    vals = [Decimal(l) for l in lines]
    check(all(emit(v) == l for v, l in zip(vals, lines)), f"{name}: decimal parse/re-emit round trip exact")
    return vals, redo == raw


def main():
    dirp = Path(sys.argv[1])
    man = json.loads((dirp / "manifest.json").read_text())
    M, L = man["M"], man["L"]
    for k, v in {"L": 20, "nu0": -20, "digits": 40, "precision": 100, "generator": "authors"}.items():
        check(man[k] == v, f"manifest {k} = {man[k]!r}")
    check(man["source"]["commit"] == "801684d9ece3de2918a20145178f569459081098", "manifest source commit")
    if len(sys.argv) > 2:
        h = hashlib.sha256(Path(sys.argv[2]).read_bytes()).hexdigest()
        check(man["source"]["sha256"] == h, f"manifest source sha256 == sha256 of {sys.argv[2]}")
    names = ["x", "xp", "K", "K0", "Lam", "Re_sig", "Im_sig", "Re_rho", "Im_rho", "fchi_sig", "fchi_rho",
             "fF_sig", "fF_rho", "Lambda3", "KFF3", "BSpline3", "intS0", "intP1", "intD0", "SVZSR"]
    check(sorted(man["matrices"]) == sorted(names), "manifest lists exactly the 20 matrices")
    data, regz = {}, {}
    for nm in names:
        data[nm], regz[nm] = load(dirp, man, nm)
    check(all(regz.values()), "host gzip -n -6 re-compression reproduces every .gz byte-for-byte"
          + ("" if all(regz.values()) else f" (differs: {[k for k, v in regz.items() if not v]})"))

    # grid recomputed independently
    nu0 = mp.mpf(-20)
    phi = [(j - mp.mpf(1) / 2) * mp.pi / M for j in range(1, M + 1)]
    x = [nu0 + (8 - 2 * nu0) / (1 + mp.cos(f)) for f in phi]
    xp = [(8 - 2 * nu0) * mp.sin(f) / (1 + mp.cos(f)) ** 2 for f in phi]
    rel = lambda a, b: abs(mp.mpf(str(a)) - b) / abs(b)
    check(max(rel(a, b) for a, b in zip(data["x"], x)) < mp.mpf("1e-38"), "x matches -20+48/(1+cos phi_j) to 1e-38")
    check(max(rel(a, b) for a, b in zip(data["xp"], xp)) < mp.mpf("1e-38"), "xp matches dx/dphi to 1e-38")
    s0 = (mp.mpf(2000) / mp.mpf("139.57")) ** 2
    n0 = sum(1 for v in data["x"] if mp.mpf(str(v)) <= s0)
    check(n0 == man["n0"], f"n0 from exported x <= (2000/139.57)^2: {n0} == manifest n0 {man['n0']}")
    D = mp.pi / M
    k0 = [D / mp.pi * xp[i] * nu0 / (x[i] * (x[i] - nu0)) for i in range(M)]
    check(max(rel(a, b) for a, b in zip(data["K0"], k0)) < mp.mpf("1e-38"), "K0 recomputed to 1e-38")
    lam = lambda s, l: mp.sqrt(((mp.sqrt(s) - 2) / (mp.sqrt(s) + 2)) ** l)
    lamI = [lam(x[i], 2 * l) for l in range(L // 2) for i in range(M)] * 2 + \
           [lam(x[i], 2 * l + 1) for l in range(L // 2) for i in range(M)]
    check(max(rel(a, b) for a, b in zip(data["Lam"], lamI)) < mp.mpf("1e-38"), "Lam recomputed to 1e-38")
    l3 = [lam(x[i], l) for l in range(3) for i in range(n0)]
    check(max(rel(a, b) for a, b in zip(data["Lambda3"], l3)) < mp.mpf("1e-38"), "Lambda3 recomputed to 1e-38")

    mrho, rows = M * M + M * (M + 1) // 2, 3 * M * L // 2
    expect = {"x": [M], "xp": [M], "K": [M, M], "K0": [M], "Lam": [rows], "Re_sig": [rows, 2 * M + 1],
              "Im_sig": [rows, 2 * M + 1], "Re_rho": [rows, mrho], "Im_rho": [rows, mrho],
              "fchi_sig": [3 * (L // 2) * 4, 2 * M + 1], "fchi_rho": [3 * (L // 2) * 4, mrho],
              "fF_sig": [3 * L // 2, 2 * M + 1], "fF_rho": [3 * L // 2, mrho], "Lambda3": [3 * n0],
              "KFF3": [3 * M, 3 * M], "BSpline3": [3 * n0, 120], "intS0": [3, n0], "intP1": [3, n0],
              "intD0": [3, n0], "SVZSR": [9]}
    badshape = {k: (man["matrices"][k]["shape"], v) for k, v in expect.items() if man["matrices"][k]["shape"] != v}
    check(not badshape, "shapes as stated" + (f" (mismatch {badshape})" if badshape else ""))

    bs = data["BSpline3"]
    sums = [sum(bs[r * 120:(r + 1) * 120]) for r in range(3 * n0)]
    check(max(abs(s - 1) for s in sums) < Decimal("1e-35"), "BSpline3 rows sum to 1 (partition of unity) to 1e-35")
    svz = [float(v) for v in data["SVZSR"]]
    check(all(abs(a - b) <= 5e-11 * abs(b) for a, b in zip(svz, SVZ_REF)),
          "SVZSR equals the reference list to 10 significant digits: " + ", ".join(f"{v:.11e}" for v in svz))
    print("\nRESULT:", "PASS" if not fails else f"{len(fails)} FAIL(S)")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
