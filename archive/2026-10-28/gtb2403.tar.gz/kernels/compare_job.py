import sys, json; sys.path.insert(0, '/home/shiqiu/s-matrix-bootstrap/src')
from smatrix_bootstrap.gtb.compare import compare_exports
K = '/playpen1/shiqiu/gtb2403_runs/kernels'
a, b = sys.argv[1], sys.argv[2]
r = compare_exports(f'{K}/{a}', f'{K}/{b}')
json.dump(r, open(f'{K}/G1_{a}_vs_{b}.json', 'w'), indent=1)
print(json.dumps({n: (v.get('max_rel'), v.get('zero_mismatch')) for n, v in r.items()}))
