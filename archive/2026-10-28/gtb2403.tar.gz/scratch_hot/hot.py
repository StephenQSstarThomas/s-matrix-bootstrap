"""Hot-start experiment (M=10): cold ni=46, cold ni=44, hot ni=44 from the ni=46 final checkpoint."""
import json, shutil, sys, time
from dataclasses import replace
from pathlib import Path
from smatrix_bootstrap.gtb import kernels, pmpwriter
from smatrix_bootstrap.gtb.program import Program
from smatrix_bootstrap.gtb.solve import run_leaf
from smatrix_bootstrap.gtb.spec import GtbSpec
from smatrix_bootstrap.sdp.sdpb import execute, read_out

KS = Path("/playpen1/shiqiu/gtb2403_runs/kernels/ours_M10"); W = Path("/playpen1/shiqiu/gtb2403_runs/scratch_hot")
kw = dict(precision=128, nproc=4, timeout=3600)
def iters(d): return sum(1 for l in (d / "sdpb.log").read_text().splitlines() if l.strip()[:1].isdigit())
res = {}
for ni in (46, 44):
    d = W / f"cold{ni}"
    if not (d / "report.json").exists():
        run_leaf(GtbSpec(M=10, f0_ni=ni), KS, d, **kw)
    r = json.loads((d / "report.json").read_text())
    res[f"cold{ni}"] = (r["sdpb_result"].get("terminateReason"), r["sdpb_result"].get("primalObjective"), iters(d), r["seconds_total"])
d = W / "hot44"; shutil.rmtree(d, ignore_errors=True); d.mkdir()
ks = kernels.load(KS); prog = Program(GtbSpec(M=10, f0_ni=44), ks)
pmpwriter.write(prog.blocks(), prog.objective(), d / "pmp.json", prog.n_vars)
shutil.copytree(W / "cold46/sdp.ck", d / "init.ck")
cfg = pmpwriter._Cfg(4, 3600)
t = time.time()
execute(d, "pmp2sdp", ["pmp2sdp", "--precision=128", "--input=pmp.json", "--output=sdp"], cfg)
args = ["sdpb", "--precision=128", "-s", "sdp", "-o", "out", "-i", "init.ck", "-c", "sdp.ck", "--maxIterations=500",
        "--dualityGapThreshold=1e-06", "--primalErrorThreshold=1e-10", "--dualErrorThreshold=1e-10",
        "--writeSolution=x,y"]
execute(d, "sdpb", args, cfg, mpi=True)
o = read_out(d / "out/out.txt")
res["hot44"] = (o.get("terminateReason"), o.get("primalObjective"), iters(d), time.time() - t)
print(json.dumps(res, indent=1))
