# GATE_LOG — arXiv:2403.10772 reproduction (branch sdpb-2403-gtb)

## 2026-10-01 19:55Z  Pre-registration frozen before any 2403 solve
- docs/gtb2403/PREREGISTRATION.md sha256 f4beaf37d585bb12ed6407bef26d256eeb70f85f35680e1a259fc0b4bf6f96e6 (committed in the same step).
- Spec PLAN_SDPB_2403_ZH.md (4104967), plan docs/superpowers/plans/2026-10-01-gtb2403-phase-a.md (971e338).
- Authors' code: submodule third_party/gauge-theory-bootstrap @ 801684d (3cff16b), reference only.
- commit b51caae

## 2026-10-01 20:15Z  G1 (kernel three-way agreement): partial, all comparisons so far exact
- Ours (mma/gtb2403/GTBKernels.wl @3268273, 120-digit, build 90 s + export 270 s at M=50) vs independent Arb rebuild
  (src/smatrix_bootstrap/gtb/arbkernels.py; cot_pi, hypgeom_2f1, own B-splines): M=10 and M=50 identical in all 40
  exported digits for all 20 matrices (11.5 M entries at M=50; G1_ours_M50_vs_arb_M50.json).
- Ours vs the authors' notebook evaluated headless and unchanged (authors_M10): identical in all 40 digits for every
  matrix except SVZSR (max rel 2.7e-16): the authors' alpha_s and quark masses are machine numbers; ours are the same
  decimals taken exactly. Documented, not a discrepancy of formulas.
- Pending: authors_M50 (dense M^2 x M^2 products at 100 digits; background run).

## 2026-10-01 20:24Z  A10 trial launched (M=50, ni=46, 192 bit, 16 ranks each, pre-Watson F1max)
- relax_full: |rho_i| <= 3.775e5 (upper bound on the exact l4 optimum); relax_reduced: same with SVD basis tol 1e-12;
  inner_full: |rho_i| <= 3.775e5/3775^(1/4) (lower bound). Purpose: cost per encoding and the width of the l4 bracket.
  These are not G3 verdicts (G3 rule frozen in PREREGISTRATION.md: verdict only from exact l4 or a deciding bracket).

## 2026-10-01 20:40Z  A10: relax_reduced stopped (machine oversubscribed)
- Load ~137 on 80 cores (other users ~58 runnable threads); 3 trials x 16 ranks + C5 2 x 8 made MPI ranks busy-wait.
  relax_reduced (a speed comparison only) stopped after 9 iterations (~65 s/iteration); relax_full and inner_full
  continue. Reduced-basis timing to be re-measured when the machine is quieter.
- 20:43Z PREREGISTRATION amendment 1 committed (d5605f7, sha256 3be9a38d4c5ed32c), before any analysis evaluation

## 2026-10-01 20:52Z  A10/A11: inner_full stopped; reduced-basis 128-bit leaves launched
- inner_full stopped (iteration ~5): the G3 lower bounds come from reduced-basis l-inf-inner leaves, which are
  l4-feasible by construction and V1-certifiable; the full space is needed only for V2 (relax_full continues).
- Launched (6 ranks each, 128 bit, SVD basis tol 1e-12): inner44r, inner46r, inner48r (G3 lower bounds) and relax46r
  (G2: reduced vs full and 128 vs 192 bit against relax_full).
- 20:55Z PREREGISTRATION amendment 2 committed (9916128) before any 2403 phase result
- 20:56Z PREREGISTRATION amendment 3 committed (e69e48a), before any 2403 phase result

## 2026-10-01 21:00Z  A4: authors' notebook reference exports
- authors_reference.wls (ca0dff5) evaluates GTB_numerics.nb unchanged (only SetDirectory and Export
  skipped); M=10: 27.6 s + 7.4 s export; M=20: 167.7 s + 37.4 s; M=50 running unmodified (single thread, dense
  M^2 x M^2 products at 100 digits scale ~M^5.2; one cell 1989 s), expected ~19:00-19:45 EDT. Our package: 90 s + 270 s.
- Quirk: LegendreQ type 3 returns complex numbers with zero imaginary part; the real part is exported (counted in the
  manifest). Lowest exported precision 89.8 digits.
- 21:11Z PREREGISTRATION amendment 4 committed (67f43d6), before any C2 solve

## 2026-10-01 21:55Z  Phase B infrastructure while the G3 leaves run (no 2403 M=50 result used)
- MATLAB orientation of the notebook's 1-D exports: Wolfram writes a 1-entry MAT5 dims array (byte-checked); Octave's
  reader (and MATLAB) take it as an N x 1 column, so `ImFF./Lambda3` and `fesr - qcdfesr` are elementwise, as our
  program assumes. A row reading would broadcast silently to 9x9 and target every moment at SVZSR(1).
- B7: between-node unitarity scan (|S| halfway in angle between nodes) and Watson fixed-point residuals in `gtb analyze`
  (40b7403, 30ac71c); M=10 leaf: |S| up to 1.35 between nodes although every node has |S| <= 1.
- B6: n_SR = 4, 5 kernels (GTBKernels nsr argument; upward moments, same O(alpha_s) identity SVZ); building M=50 NSR4/5.
- B6: `gtb solve` now takes M, L, N_B from the export manifest (Program refuses a mismatch) and `--set FIELD=VALUE`.
  Before this, L=24/N_B=46 kernels would have been indexed with L=20/N_B=40 silently (no such leaf was run).
- Hot start (`--hot-start LEAF`, SDPB -i from the neighbour's final checkpoint): M=10 ni=44 from ni=46 in 25 instead
  of 64 iterations, F1 -0.02524984 vs cold -0.02524937 (duality gap 1e-6).
- 22:57Z PREREGISTRATION amendment 5 committed (718e119, sha256 6a6451f7b36d320c) before any M=50 certificate, omitted-wave eta or phase result; unconverged inner iterates (~1e-3 above the paper) had been seen

## 2026-10-01 23:07Z  G1 PASS (kernel three-way agreement, complete)
- authors_M50 (their notebook evaluated unchanged: 8064 s evaluate + 441 s export) vs ours_M50: identical in all 40
  exported digits for all 20 matrices except SVZSR (max rel 2.69e-16: their machine-precision alpha_s, m_u, m_d).
  With ours = Arb at M=10/50 and ours = authors at M=10/20 the kernel layer is settled (G1_ours_M50_vs_authors_M50.json).

## 2026-10-01 23:25Z  G3 = C1 FAIL (certified from below, amendment 5)
- inner44r/46r/48r (l-inf inner |rho_i| <= R/3775^(1/4), reduced basis, 128 bit, 6 ranks, ~8000 s each), V1 in Arb:
  every family certified feasible, ||rho||_4 = 2.89e5 < R = 3.775e5 certified. F1 = -0.0257596 / -0.0271602 / -0.0285865
  vs paper -0.027229 / -0.028770 / -0.030397: +1.47e-3 / +1.61e-3 / +1.81e-3. C1_RESULT.json (one-sided, upper None).
- relax46r (|rho_i| <= R): F1 = -0.0254627 (V1 feasible for its own problem, ||rho||_4 = 2.23e6 = 5.9 R).
  So the authors' l4 optimum at ni 46 is in [-0.02716, -0.02546] (upper end pending V2/full space).
- Diagnosis (no tuning): the regulariser binds (relax - inner = 1.7e-3 at ni 46); omitted waves l = 20..23 (from the
  L=24 export) violate unitarity: eta_max 2.14 (inner46r), 2.83 (relax46r), at node 47. OMITTED_WAVES_trial.json.
  As in 2309, the published maxima lie below the exact optimum of the stated finite problem.
- Amendment 6 committed (79a1019, sha256 a0fc0ed6f0010c95) before any further ladder rung.

## 2026-10-01 23:40Z  Phase B launched; first diagnostics on the initial (pre-Watson) inner leaves
- Queues phaseB/queue1.txt (ladder M_reg 30/10/3/1/0.3, Watson from inner44r/46r/48r, relax44r/48r hot-started) and
  phaseB/queue2.txt (C2 scan chains, inner, hot-started; tree dot). Runner fixes: python-driver count (the bash -c
  wrapper doubled it), first --workdir for chained lines (one chain line was lost and re-queued), BLAS threads 4.
- inner44r analysis: P1 90-deg crossing 811 MeV, S0 663, D0 952 (pre-Watson); between-node |S| up to 1.14 (P1),
  1.10 (S0); D-wave threshold fits unstable (a22 interp -0.0103, node control +0.0231): float vs exact-Arb amplitude
  agree to 8 digits at the threshold nodes, so this is the discrete model, not round-off (Re f/k^4 not smooth at the
  first nodes). Reported as pre-registered (interp mainline, node control), noted as ill-determined at M = 50.

## 2026-10-01 23:55Z  C1 gap attribution by shadow prices (envelope theorem, `gtb sensitivity`; nothing tuned)
- dF1 for a +10 % change of each tolerance at ni 46 (inner representative / relax control):
  eps_chi +5.6e-4 / +4.4e-4; r11 (P1 FF cap) +1.3e-4 / +6.1e-5; M_reg +6.8e-5 / +8.8e-5; eps_SR(P1) +4.9e-5 / +2.3e-5;
  eps_SR(S0, D0), r00, r02 < 2e-9. dF1/dF0 = -0.216 (the paper's dots sit 8.5e-5 higher in F0: -1.8e-5 in F1).
- The 1.6e-3 gap would need eps_chi ~30 % tighter or a far stronger regulariser; no tolerance-level slack of a
  double-precision solver on the stated constraints explains it. The M_reg ladder (variant B) measures the latter.

## 2026-10-02 00:20Z  G2 decision and V2 at M = 50
- relax_full (full space N 4128, 192 bit, 16 ranks, 12190 s, 76 iterations): F1 = -0.02528982; V1 all families
  certified, V2 upper -0.0252893034 (residual repaired to 8e-41, no PSD shift, 12 min, 8.6 GB). Certified bracket of
  the relax problem: width 5.2e-7.
- ni 46 authors' l4 optimum: certified in [-0.0271602 (inner, reduced, V1), -0.0252893 (relax, full, V2)];
  the paper's -0.028770 lies 1.6e-3 below the lower end.
- G2: reduced basis (N 2220, 128 bit, 6 ranks, ~8000 s) loses 1.7e-4 against full space at relax46 (-0.0254627 vs
  -0.0252898): reduced maxima are conservative lower bounds, fine for V1-certified representatives and the C2 scan
  (amendment 4). Full space + V2 only where an upper bound or an infeasibility certificate is needed. Exact E1 not run
  (ledgered: 30-100 h). Production encoding: inner (A representative), relax (A control, B ladder).

## 2026-10-02 02:05Z  Variant B ladder, first rungs (amendments 5-6)
- ni 46 F1max, l-inf relax, reduced: M_reg 100 -> F1 -0.0254627, eta_max 2.83; M_reg 30 -> -0.0265097, eta_max 2.69.
  The omitted-wave violation (node 47, l = 22/23) is rho-driven (h_sigma ~ 0.01, h_rho ~ -2.1..-2.8). In 2309 units
  (selected box |rho| <= 100) the equivalent rung is M_reg ~ 0.03 (R = M_reg * 3775). Rungs 0.3, 0.1, 0.03, 0.01
  queued at top priority per amendment 6 (10, 3, 1 finishing).
- 02:15Z ladder so far (F1 at ni 46 / omitted-wave eta_max): M_reg 100: -0.0254627 / 2.83; 30: -0.0265097 / 2.69;
  10: -0.0273204 / 1.91; 3: -0.0279333 / 1.42; 1: -0.0282349 / 1.48 (non-monotone). No rung passes eta <= 1.02;
  0.3, 0.1, 0.03, 0.01 running/queued. ladder/LADDER_partial.json.

## 2026-10-02 02:25Z  Variant A, ni 44 (blue) after the Watson step (watson44i, reduced, inner, 128 bit, 7800 s)
- V1: every family certified, l4 certified (||rho||_4 = 3.00e5 < 3.775e5). F0 released: 0.14354 -> 0.14104.
- Saturation like the paper: min eta S0 1.000, P1 0.986, D0 1.000. Watson residual vs its seed 0.01-0.32 (one step).
- Against the paper's blue curves (phaseB/A/fig4_watson44i.png): S0 and P1 close (P1 90-deg crossing 807 vs 839 MeV;
  BW rho 802/94 MeV, GS 810/104), S2 agrees below 0.6 GeV then stays less negative (-11 vs -24 deg at 1.4 GeV),
  D0 rises at 0.9 GeV (90-deg crossing 950 MeV) where the paper's f2 rises at 1.3 GeV (crossing 1352 MeV).
  l-bar_1,2 = 11.1, -5.4 (paper 0.96, 4.5); no rho pole in the acceptance window (zero at 922 - 1001i MeV).
- Between-node |S| up to 1.31 (S0), omitted waves eta up to 1.65.
- Reading (provisional, one point): the exact optimum of the stated problem keeps the rho and sigma physics but moves
  the f2 structure ~400 MeV down; the published f2 depends on the double-precision stopping point.
- D0 before/after Watson at ni 44 (paper Fig. 20 vs ours): paper before: delta 61/94/108 deg at 0.95/1.1/1.3 GeV with
  eta 0.60/0.49/0.39 (early, inelastic); paper after: 10/19/77 deg, eta 1 (f2 pushed to 1.3 GeV). Ours: 90/135/148
  deg with eta 1.000 already before Watson, unchanged after. Our initial optimum is elastic in D0, so the Watson
  step has nothing to move. Reading: the D0 phase is not fixed by F1max (degenerate optimal face); SDPB's interior
  point and MOSEK's stopping point differ on that face. Testable by a slab-face run (max/min of delta^0_2 at 1.1 GeV
  subject to F1 >= F1max - 1e-6), queued as an extension after the claims.
- 04:00Z amendment 7 (d923e63): text-reading control (||rho||_4 <= 100) inner/relax at ni 46 queued at top priority
- 04:17Z amendment 8 / WELLPOSED_ZH.md committed (94b3dd3, doc sha256 4c12ec437ae94228) before any P_W computation

## 2026-10-02 04:45Z  P_W (WELLPOSED_ZH.md, amendment 8) started
- Kernels ours_M50_W40 (L = 40, FESR normalised at x_b = 189.16): V0 PASS (every l < 20 row identical to ours_M50,
  W1 moments = authors' x (x_n0/x_b)^(n+n_l) to 7e-40, all other matrices identical; kernels/V0_W40.json).
- Gate W-G1 solve 1: ni 46, L_u = 40, full space, l-inf relax (R = 3.775e5), 128 bit, 12 ranks
  (wellposed/W40_46_relax). Queue caps lowered (queue1 5, queue2 4) so P_W keeps priority.
- 04:55Z midpoint export kernels/mid_M50_l20 (1470 rows: 3 isospins x 10 waves x 49 phi-midpoints; 2.8 min Arb):
  agrees with the stored between-node analysis of watson44i to <= 7e-11. Over ALL 49 midpoints (not only below
  s0, as the earlier scan) the certified variant-A Watson solution has |S| up to 13.4 (S0), 10.2 (S2), 8.5 (P1);
  461 of 1470 rows violate: at high energy the node values alternate (Nyquist mode of the discrete K) and the
  amplitude between nodes is far from unitary. Ruling (within amendment 8, W3): impose all 1470 midpoint cones from
  the start instead of generating them (the solved problem is then P_W itself; no generation rounds). The first
  W40 launch (no midpoints, 4 min old, pmp2sdp stage) was stopped and relaunched with --mid-rows all.
- 05:00Z ladder: M_reg 0.3 -> F1 -0.0283852, eta 1.30; 0.1 -> -0.0284520, eta 1.11 (still > 1.02); 0.03, 0.01 running.
  F1 approaches ~ -0.0285 as the box tightens (paper -0.028770); ladder/LADDER.json.
- 05:10Z P_W solves failed at SDPB start: MPI shared window 16.9 GB > the container's 16 GB /dev/shm (12160 blocks). Relaunched W40 and W60 at ni 46 with SDPB_SHM=40g (launcher option; machine has ~150 GB free)
- V0 PASS for ours_M50_W60, ours_M50_W80 (verification rows l < 80) and ours_M50_W20 (L=20 with W1, for attributing W1 alone): kernels/V0_W60.json, V0_W80.json, V0_W20.json
- 05:55Z P_W iterating: W40 ~360 s/iteration, W60 slower (12 ranks each, 12160 / ~16700 blocks) -> 8-10 h.
  Reduced P_W basis with every node and midpoint row in the SVD: rank 2622 (L 40) / 2832 (L 60) of 3876.
  Queued at the head of queue1: W40_46_relax_red (reduced P_W at ni 46: must match the full gate solve before the
  production uses the reduced basis), attrib_W1_46 (L 20 + W1 only) and attrib_W1W3_46 (L 20 + W1 + W3) to
  attribute the changes.

## 2026-10-02 08:00Z  Text-normalisation control (amendment 7) and the ladder
- Text reading ||rho||_4 <= 100 (no /Mrho), ni 46, reduced 128 bit: inner F1 = -0.0285156 (V1 all families, l4
  certified), relax -0.0284870 (V1 for its own box; outside the l4 ball). Paper -0.028770 is 2.5e-4 below the
  certified lower end: per the wording fixed in amendment 7, "neither the code's nor the text's normalisation
  reproduces the published point".
- Ladder (variant B): 0.03 -> F1 -0.0284848, eta 1.026 (fails); 0.01 -> -0.0285009, eta 1.0093 (first rung with
  eta <= 1.02). The L = 24 re-solve at M_reg 0.01 (rule's second condition) is queued first.
  F1 converges to ~ -0.0285 as the box tightens; every reading so far has its certified optimum >= 2.5e-4 above
  the published -0.028770.
- C2 scan point k = 6: V1 fails strictly by 4 unitarity rows at slack -1.3e-12 (inside SDPB's 1e-10 tolerance);
  reported as "feasible up to 1.3e-12" (C2 tolerance 3e-4). Disk freed to 60 GB (seed checkpoints, aborted trials).
- 10:00Z C2 V1: 9 of 11 hot-started scan points miss strict V1 by 1e-12..6e-12 (unitarity/gram/chiral slack), cold k22/k38 pass; values used as 'feasible up to 6e-12'. Added --psd-margin (41a67d8) for P_W production

## 2026-10-02 13:00Z  Variant B selected; variant A point set complete; first P_W gate solve
- Variant B (amendments 5-6): M_reg* = 0.01 (largest rung with omitted-wave eta <= 1.02: 1.0093; L = 24 re-solve
  -0.0285035 vs -0.0285009, rel 9e-5 <= 2 %). ladder/LADDER.json. Queued: init44b/48b + watson44b/46b/48b
  (l-inf relax box R = 0.01 x 3775, reduced, 128 bit, --psd-margin 1e-8).
- Variant A complete: inner44r/46r/48r, watson44i/46i/48i, relax44r/46r/48r (relax44r/48r hot-started, ~50 min).
- P_W gate (ni 46, full space): W40 F1max = -0.0278941 (l4 2.6e6, |rho|_inf = R: the box is touched).
  Attribution at L 20 (reduced): W1 alone -0.0254406 (vs code reduced -0.0254627), W1+W3 -0.0254968:
  W1 and W3 hardly move F1max; W2 (unitarity of l = 20..39) lowers it by 2.6e-3. L60 control converging at ~-0.02830
  (|dF1| ~ 4e-4 > 1e-4 -> per amendment 8 P_W becomes L_u = 60). W4 under test (shadow price of R).

## 2026-10-02 14:40Z  P_W gate W-G1 decided
- ni 46 F1max (full space, relax): L_u 20 -0.0252898 | 40 -0.0278941 | 60 -0.0283476. |dF1(40->60)| = 4.5e-4 > 1e-4
  -> P_W is L_u = 60 (amendment 8 rule; differences shrink by ~0.17 per step, tail ~1e-4 reported, not chased).
- Reduced P_W (every node + midpoint row in the SVD, rank 2622) vs full at L 40: -0.0279226 vs -0.0278941 (2.9e-5):
  Ruling: P_W production (ni 44/48 maxima, the three Watson steps) in the reduced basis, L_u 60, psd-margin 1e-8;
  ni 46 keeps the full-space two-sided certificate.
- V2 of W40 was inf because of an export-format bug (python fmt stripped trailing zeros; certify.ball read '1e0'
  as 1 +- 1, so every exact midpoint coefficient was NaN). Fixed (fixed-width 40 digits), midpoint export rebuilt
  (float values identical; running solves unaffected), V2 and shadow prices of W40/W60 rerunning.
- W40 V1 (before the fix, valid but with loose midpoint radii): all families certified; midpoint max |S| <= 1.0;
  waves l = 40..79 reach |S| 2.25 (I=0, l=78, node 48, sqrt(s) ~ 30 GeV): unitarity at the top nodes needs far
  more partial waves than any finite L_u.
- P_W production queue wellposed/queueW.txt: init44w -> watson44w, init48w -> watson48w, watson46w (from W60 full).
- 15:10Z P_W certificates (export bug fixed): W40 [V1 -0.02789407, V2 -0.02789340], W60 [V1 -0.02834760,
  V2 -0.02834697] for the relax encoding (no PSD shift). Midpoints certified |S| <= 1.0 (W3 holds); waves beyond
  L_u: max |S| 2.25 (L 40) -> 1.14 (L 60), both at I=0 l=78, nodes 47-48. W4 narrowly fails: relax optimum outside
  the l4 ball, dF1(+10 % R) = 6.9e-6 at L 60 (3.2e-5 at L 40; criterion 1e-6). Shadow prices at L 60 (+10 %):
  eps_chi 8.4e-4, r11 2.1e-4, eps_SR(P1) 8.2e-5. Launched prod/inner46w (L 60, inner box, reduced) for the l4-feasible
  lower bound.
