"""Experiment: V2 upper bound for the FULL-space problem from a REDUCED-basis leaf's multipliers Z.
Weak duality only needs Z_j >= 0 on the full block list; the reduced solve's Z satisfies the dual equalities only in
the kept directions, the Gram correction of dual_bound repairs the rest (or fails with a large shift)."""
import json, sys, time
from dataclasses import fields
from pathlib import Path
import numpy as np
from smatrix_bootstrap.gtb.dual import (ExactKernels, dual_bound, free_variable_bounds, read_dual_matrices,
                                        trace_bounds)
from smatrix_bootstrap.gtb.kernels import load
from smatrix_bootstrap.gtb.program import Program
from smatrix_bootstrap.gtb.spec import GtbSpec

leaf, kdir = Path(sys.argv[1]), sys.argv[2]
rep = json.loads((leaf / "report.json").read_text())
spec = GtbSpec(**{f.name: (tuple(rep["spec"][f.name]) if isinstance(rep["spec"][f.name], list) else rep["spec"][f.name])
                  for f in fields(GtbSpec)})
t = time.time()
prog = Program(spec, ExactKernels(load(kdir)), reg=rep["regulariser"])      # full space, same block list
blocks = prog.blocks()
Z = read_dual_matrices(leaf / "out", [b.size for b in blocks])
ybar = free_variable_bounds(prog)
print("built", round(time.time() - t), "s; blocks", len(blocks), "n", prog.n_vars, flush=True)
res = dual_bound(blocks, list(prog.objective()), Z, trace_bounds(blocks, ybar), ybar, refine=int(sys.argv[3]) if len(sys.argv) > 3 else 8)
ub = res["bound"]
out = {"leaf": str(leaf), "upper": ub.upper().str(30, radius=False) if ub.is_finite() else "inf",
       "residual_history": res.get("residual_history"), "max_shift": res.get("max_shift"),
       "failed_blocks": res.get("failed_blocks"), "seconds": time.time() - t}
print(json.dumps(out, indent=1, default=str))
(leaf.parent / f"v2_from_reduced_{leaf.name}_r{sys.argv[3] if len(sys.argv) > 3 else 8}.json").write_text(json.dumps(out, indent=1, default=str))
